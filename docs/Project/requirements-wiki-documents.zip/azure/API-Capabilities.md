# API Capabilities Reference

Load this file when you need endpoint details, protocol information, or workspace resolution rules.

## Protocols

- **REST API**: All `/mcpserver/*` endpoints (requires `X-Api-Key` header). Full OpenAPI spec at `GET /swagger/v1/swagger.json`. Interactive Swagger UI at `/swagger`.
- **MCP Streamable HTTP**: `POST /mcp-transport` - Model Context Protocol transport for tool-calling agents. No API key required.
- **Health Check**: `GET /health` - liveness. Observed payload keys: `status`, `version`, `checks`, `nonce`, `storage`. A caller `nonce` query is echoed exactly. `storage` is `reachable` or `unreachable`. No API key required.

## Workspace Resolution

All workspaces share a single server port. Resolution priority:

1. **`X-Workspace-Path` header** (highest priority): explicitly targets a workspace.
2. **API key reverse lookup**: `X-Api-Key` is unique per workspace - the server resolves automatically.
3. **Default workspace**: if neither header nor key is present, the primary workspace is used.

For most agents, including `X-Api-Key` from the marker file is sufficient.

## Stale Marker Detection

To detect a stale marker without auth:

1. `GET /server-startup-utc` - compare `serverStartedAtUtc` to marker's value. If different, re-read the marker.
2. `GET /marker-file-timestamp?repoPath=<workspacePath>` - compare `lastWriteTimeUtc` to marker's `markerWrittenAtUtc`. If newer, re-read.
3. If both match, the marker is current.

## Available Endpoints

- **Context Search**: `POST /mcpserver/context/search` - semantic + full-text hybrid search over indexed project documents
- **Context Pack**: `POST /mcpserver/context/pack` - retrieve ordered context chunks for a topic
- **Context Sources**: `GET /mcpserver/context/sources` - list all indexed document sources
- **Website Ingestion**: `POST /mcpserver/context/ingest-website` - ingest one URL (optionally bounded same-host crawl) directly into context store with SSRF and byte/page limits
- **Todo Management**: `GET/POST/PUT/DELETE /mcpserver/todo` - query, create, update, delete project tasks
- **Repo Files**: `GET /mcpserver/repo/file`, `POST /mcpserver/repo/file`, `GET /mcpserver/repo/list` - read, write, and list repository files
- **GitHub Integration**: `/mcpserver/gh/issues`, `/mcpserver/gh/pulls`, `/mcpserver/gh/labels` - issue, PR, and label management
- **Tool Registry**: `GET /mcpserver/tools/search` - discover available tools; `GET/POST /mcpserver/tools` - manage tool definitions
- **Session Log**: `POST /mcpserver/sessionlog`, `GET /mcpserver/sessionlog` - session logging; `PATCH` (additive merge) / `PUT` (replace turn or section) / `DELETE` (remove turn, section, item, or session) under `/{agent}/{sessionId}/{requestId}` - see [session-log-workflow-api.md](session-log-workflow-api.md#replacing-and-removing-data-patch--put--delete)
- **Federation**: `GET /mcpserver/federation/status` - role, hub URL, proxy id, queue depth, fanout depth, stale-read status, conflicts; `/mcpserver/federation/proxies`, `/workspaces`, `/queue`, `/conflicts`, `/adapters`, `/operations`, `/envelopes`, and `/sync` support hub-spoke enrollment, signed operation replay, diagnostics, and fanout
- **MCP Protocol**: `/mcp-transport` - Model Context Protocol streamable HTTP transport endpoint
- **Memory**: `GET/POST/PUT/DELETE /mcpserver/memory`, `POST /mcpserver/memory/remember|recall|explore|consolidate|promote`, `GET /mcpserver/memory/{id}/versions`, `POST /mcpserver/memory/{id}/revert`. STDIO tools `memory_*`. First-party UI at `/memory/`. See [memory.md](memory.md).

## Server Health

Before making API calls, verify the server is running: `GET /health` returns liveness with payload keys `status`, `version`, `checks`, `nonce`, and `storage`.
