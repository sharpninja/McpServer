# Functional Requirements (QBrain.AI)

## FR-HANDOFF-001 Ingest workspace-scoped handoff documents

Ingest workspace-scoped handoff documents from a contained file path, caller-supplied content, or MCP artifact reference.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Supports Markdown, text, JSON, and YAML inputs. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Rejects missing, unsupported, oversized, traversal, external, and reparse-escaping paths. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Maximum decoded input is 8 MiB. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-HANDOFF-002 Extract structured MCP TODO drafts via one-shot agents

Use the existing one-shot agent system to extract a structured MCP TODO draft.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Extraction uses a versioned prompt and strict JSON contract. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Malformed output produces diagnostics and never creates a TODO. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Unknown or missing source information is not silently discarded. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-HANDOFF-003 Validate and normalize generated TODO drafts

Validate and normalize generated TODO drafts.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Validate ID, title, section, priority, estimate, description, technical details, implementation tasks, dependencies, and requirement links. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Invalid or conflicting values produce field-specific diagnostics. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-HANDOFF-004 Support DraftOnly, RequireReview, and CreateWhenConfident modes

Support DraftOnly, RequireReview, and CreateWhenConfident modes.
Scope: layer-1+
**Acceptance Criteria:**
- [x] DraftOnly is the default and never mutates TODO state. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] RequireReview persists an approvable run without creating a TODO. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] CreateWhenConfident creates only when confidence is at least 0.75 and no error diagnostic exists. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-HANDOFF-005 Persist approved TODOs exclusively through the TODO service

Persist approved TODOs exclusively through the existing TODO service.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Successful creation produces exactly one TODO. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Replay of the same workspace, content hash, and prompt version returns the existing receipt. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] ID collisions require review and are never silently renamed. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-HANDOFF-006 Preserve auditable provenance and diagnostics

Preserve auditable provenance and diagnostics for every run.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Retain run ID, source kind and locator, SHA-256 content hash, extraction time, prompt/template version, agent, model, confidence, mode, review state, diagnostics, and created TODO ID. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Raw credentials or source content are not copied into logs. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-HANDOFF-007 Provide equivalent public handoff surfaces

Provide behaviorally equivalent API, client, REPL, Director, MCP-tool, and plugin-skill entrypoints.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Every surface delegates to the same service, returns the same result contract, applies workspace isolation, and exposes ingest, inspect, and approval workflows. (evidence: tests/McpServer.Client.Tests/HandoffClientTests.cs; tests/Build.Tests/HandoffD3D5OverlayTests.cs; overlay G3 D5 AGREE + G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-LOC-001 Localization Support

Localization and internationalization support for the MCP server. *(Planned - implementation scope TBD.)*
Scope: layer-1+

## FR-MCP-001 Configurable workspace root and paths

The server shall support configurable `RepoRoot`, `TodoFilePath`, `DataDirectory`, and index paths.

**Covered by:** `IngestionOptions`, `IOptions`
Scope: layer-1+

## FR-MCP-002 TODO management API

The server shall provide CRUD/query operations for TODO items over REST and STDIO.

**Covered by:** `TodoController`, `TodoService`, `SqliteTodoService`
Scope: layer-1+

## FR-MCP-003 Session log ingestion and query

The server shall ingest session logs and support searchable queries.

**Covered by:** `SessionLogController`, `SessionLogService`
Scope: layer-1+

## FR-MCP-004 Hybrid context search

The server shall support FTS and vector search over indexed content.

**Covered by:** `HybridSearchService`, `Fts5SearchService`, `VectorIndexService`, `EmbeddingService`
Scope: layer-1+

## FR-MCP-005 GitHub issue sync

The server shall support GitHub issue lifecycle integration and ISSUE-* TODO synchronization.

**Covered by:** `GitHubController`, `GitHubCliService`, `IssueTodoSyncService`
Scope: layer-1+

## FR-MCP-006 Multi-source ingestion

The server shall ingest repository files, session logs, external docs, and issue content.

**Covered by:** `IngestionCoordinator`, `RepoIngestor`, `SessionLogIngestor`, `ExternalDocsIngestor`, `GitHubIngestor`, `IssueIngestor`
Scope: layer-1+

## FR-MCP-007 Dual transport

The server shall support HTTP and STDIO MCP transports.

**Covered by:** `Program.cs`, `McpServerMcpTools`, `McpStdioHost`
Scope: layer-1+

## FR-MCP-008 Containerized deployment

The server shall support containerized deployment and packaged distribution.

**Covered by:** `Dockerfile`, `docker-compose.mcp.yml`
Scope: layer-1+

## FR-MCP-009 Workspace Management

The server shall support dynamic workspace registration, configuration, and lifecycle management - replacing static instance configuration - with directory scaffolding and Base64URL-encoded path keys. All workspaces are served on a single port via `X-Workspace-Path` header resolution (see FR-MCP-043).

**Covered by:** `WorkspaceController`, `WorkspaceService`, `WorkspaceConfigEntry`
Scope: layer-1+

## FR-MCP-011 Workspace Process Orchestration

The server shall manage workspace lifecycle via marker files: write `AGENTS-README-FIRST.yaml` on start, remove on stop. All workspaces share the single host process and port. Automatic startup of all registered workspaces writes markers on service start.

**Covered by:** `WorkspaceProcessManager`, `IWorkspaceProcessManager`, `MarkerFileService`
Scope: layer-1+

## FR-MCP-012 Tool Registry

Agents shall be able to discover tools by keyword search across global and workspace-scoped tool definitions, and install tool definitions from GitHub-backed bucket repositories.

**Covered by:** `ToolRegistryController`, `ToolRegistryService`, `ToolBucketService`
Scope: layer-1+

## FR-MCP-013 Per-Workspace Auth Tokens

The server shall protect all `/mcpserver/*` API endpoints with per-workspace cryptographic tokens that rotate on each service restart. Tokens are discoverable via the `AGENTS-README-FIRST.yaml` marker file, checked via the `X-Api-Key` header or `api_key` query parameter, and enforced by `WorkspaceAuthMiddleware`. Workspace resolution uses a three-tier chain: `X-Workspace-Path` header → API key reverse lookup → default workspace (see FR-MCP-043).

**Covered by:** `WorkspaceAuthMiddleware`, `WorkspaceTokenService`, `WorkspaceResolutionMiddleware`, `MarkerFileService`
Scope: layer-1+

## FR-MCP-014 Pairing Web UI

*Moved to [Requirements-WebUI.md](Requirements-WebUI.md#fr-mcp-014-pairing-web-ui)*
Scope: layer-1+

## FR-MCP-015 Tunnel Providers

The server shall expose its HTTP interface to the internet via pluggable tunnel providers (ngrok, Cloudflare, FRP) configured through a strategy pattern and registered as hosted services.

**Covered by:** `NgrokTunnelProvider`, `CloudflareTunnelProvider`, `FrpTunnelProvider`
Scope: layer-1+

## FR-MCP-016 MCP Streamable HTTP Transport

The server shall expose a native MCP protocol endpoint at `/mcp-transport` coexisting with the REST API on the same port, enabling standard MCP client connections via `ModelContextProtocol.AspNetCore`.

**Covered by:** `Program.cs` (MapMcp), `ModelContextProtocol.AspNetCore`
Scope: layer-1+

## FR-MCP-017 Windows Service

The server shall run as a Windows service with automatic startup, failure recovery (restart on failure with 60 s delay), and PowerShell-based install/update/uninstall management.

**Covered by:** `Program.cs` (UseWindowsService), `Manage-McpService.ps1`
Scope: layer-1+

## FR-MCP-018 Marker File Agent Discovery

When a workspace is started, the server shall write an `AGENTS-README-FIRST.yaml` marker file to the workspace root containing the shared host port, all endpoint paths, a machine-readable prompt, and PID. All markers point to the same port; workspace identity is resolved via the `X-Workspace-Path` header. The marker shall be removed when the workspace is stopped.

**Covered by:** `MarkerFileService`, `WorkspaceProcessManager`
Scope: layer-1+

## FR-MCP-019 Workspace Host Controller Isolation

*Obsolete - replaced by single-app multi-tenant model (FR-MCP-043).* All controllers are available on the single host. Workspace lifecycle management endpoints on `WorkspaceController` remain admin-only.
Scope: layer-1+

## FR-MCP-020 Workspace Auto-Start on Service Startup

On service startup, the server shall automatically write marker files for all workspaces already registered, restoring agent discoverability without manual intervention. All workspaces share the single host port.

**Covered by:** `WorkspaceProcessManager` (IHostedService.StartAsync)
Scope: layer-1+

## FR-MCP-021 Workspace Auto-Init and Auto-Start on Creation

When a new workspace is registered, the server shall automatically initialize the workspace directory scaffold (todo.yaml, mcp.db, docs structure) and write its marker file, so the workspace is immediately operational on the shared port.

**Covered by:** `WorkspaceController` POST, `WorkspaceService.InitAsync`
Scope: layer-1+

## FR-MCP-022 Tool Registry Default Bucket Seeding

On first startup, the server shall seed default tool buckets from configuration (`Mcp:ToolRegistry:DefaultBuckets`) if they are not already registered, ensuring new installations have the primary tool repository available without manual setup.

**Covered by:** `ToolRegistryOptions`, `Program.cs`
Scope: layer-1+

## FR-MCP-023 AI-Assisted Requirements Analysis

The server shall provide a requirements analysis capability that invokes the Copilot CLI to examine a TODO item's title, description, and technical details, identify matching existing FR/TR IDs from the project docs, create new FR/TR entries for unaddressed functionality, and persist the assigned IDs back to the TODO item.

**Covered by:** `RequirementsService`, `IRequirementsService`, `ICopilotClient`
Scope: layer-1+

## FR-MCP-024 Markdown Session Log Ingestion

The ingestion pipeline shall parse legacy Markdown session log files (matching a `# Session Log - {title}` header pattern) into the unified session log schema alongside JSON session logs, enabling retroactive indexing of pre-existing agent session records.

**Covered by:** `MarkdownSessionLogParser`, `SessionLogIngestor`
Scope: layer-1+

## FR-MCP-025 Primary Workspace Detection and Deduplication

One workspace is designated as the **primary** workspace - served by the host process directly with no child `WebApplication` spun up. Only a marker file is written. Resolution order: (1) first enabled workspace with `IsPrimary = true` and lowest port; (2) enabled workspace with lowest port if none marked primary; (3) no primary if no workspaces enabled.

**Status:** ✅ Complete

**Covered by:** `WorkspaceProcessManager`, `WorkspaceConfigEntry`, `Program.cs` primary-workspace resolution block
Scope: layer-1+

## FR-MCP-026 OIDC Authentication

The server shall support standards-based OIDC JWT Bearer authentication for management endpoints using a configurable open-source .NET OIDC provider. Optional external identity federation (for example, GitHub) may be configured through that provider. Management endpoints (agent mutations) require JWT; read endpoints use existing API key auth.

**Covered by:** `OidcAuthOptions`, `Program.cs`, `AgentController`, `Setup-McpKeycloak.ps1`, `setup-mcp-keycloak.sh`
Scope: layer-1+

## FR-MCP-027 Agent Definition Management

The server shall provide CRUD operations for agent type definitions with built-in defaults for well-known AI coding agents (copilot, cline, cursor, windsurf, claude-code, aider, continue). Built-in definitions are seeded on first run and cannot be deleted.

**Covered by:** `AgentController`, `AgentService`, `AgentDefaults`, `AgentDefinitionEntity`
Scope: layer-1+

## FR-MCP-028 Per-Workspace Agent Configuration

The server shall support per-workspace agent configuration with overrides for launch command, models, branch strategy, seed prompt, instruction files, isolation strategy, restart policy, and marker additions. Agents can be banned per-workspace or globally with optional PR-gated unbanning. All agent lifecycle events (add, launch, exit, ban, unban, delete, merge, init) are logged for audit.

**Covered by:** `AgentController`, `AgentService`, `AgentWorkspaceEntity`, `AgentEventLogEntity`, `AgentHealthMonitorService`
Scope: layer-1+

## FR-MCP-029 CQRS Framework

A standalone CQRS framework (`McpServer.Cqrs`) shall provide async command/query dispatch with a Result monad, decimal correlation IDs (`baseId.counter`), pipeline behaviors, and an `ILoggerProvider` implementation that auto-enriches structured logs with decomposed correlation context. The Dispatcher shall automatically log Result outcomes (success at Debug, errors at Error/Warning).

**Status:** ✅ Complete

**Covered by:** `McpServer.Cqrs` project (`Dispatcher`, `CallContext`, `CorrelationId`, `Result<T>`, `IPipelineBehavior`), `McpServer.Cqrs.Mvvm` (IViewModelRegistry, ViewModelRegistryExtensions). Workspace and policy view-models moved to the separate `McpServerManager` repository (former `McpServer.UI.Core` / `WorkspaceListViewModel` / `WorkspacePolicyViewModel` / `AddUiCore` DI extension).

**Implementation:** 37 unit tests passing. Provides `ICommand<T>`/`IQuery<T>` message types, `ICommandHandler<,>`/`IQueryHandler<,>` handlers, `Dispatcher` with pipeline behavior chain, `CallContext` with `CorrelationId` for structured logging, and `Result<T>` monad with success/error paths. MVVM layer adds `IViewModelRegistry` for CLI exec command support.
Scope: layer-1+

## FR-MCP-030 Director CLI

*Moved to [Requirements-Director.md](Requirements-Director.md#fr-mcp-030-director-cli)*
Scope: layer-1+

## FR-MCP-031 McpServer Management Web UI

*Moved to [Requirements-WebUI.md](Requirements-WebUI.md#fr-mcp-031-mcpserver-management-web-ui)*
Scope: layer-1+

## FR-MCP-032 Enhanced GitHub Integration

Enhanced GitHub integration capabilities including GitHub federation through the configured OIDC provider for user authentication, and GitHub OAuth for agent workspace management and PR workflows. *(Planned - tracked as high-priority TODO.)*
Scope: layer-1+

## FR-MCP-033 Natural Language Policy Management

A Copilot-integrated prompt tool that accepts natural language policy directives (e.g. "Ban chinese sources from all workspaces") and translates them into workspace configuration changes across all or targeted workspaces. Each policy change is session-logged per affected workspace with action type `policy_change`.

**Covered by:** `WorkspaceController` (`POST /mcpserver/workspace/policy`), `WorkspacePolicyService`, `WorkspacePolicyDirectiveParser`, `McpServerMcpTools.workspace_policy_apply`
Scope: layer-1+

## FR-MCP-034 Workspace Compliance Configuration

Per-workspace compliance configuration supporting four ban lists: `BannedLicenses` (SPDX identifiers), `BannedCountriesOfOrigin` (ISO 3166-1 alpha-2 codes), `BannedOrganizations`, and `BannedIndividuals`. Ban lists are conditionally rendered into the AGENTS-README-FIRST.yaml marker prompt via Handlebars templates. Agents must verify compliance before adding dependencies and log violations.

**Covered by:** `WorkspaceDto`, `WorkspaceCreateRequest`, `WorkspaceUpdateRequest`, `MarkerFileService`
Scope: layer-1+

## FR-MCP-035 Agent Values and Conduct Enforcement

The marker prompt shall include mandatory sections for: absolute honesty, correctness above speed, complete decision documentation, professional representation and audit trail (commits, PRs, issues logged in full), and source attribution (web references logged). These are non-configurable and always present.

**Covered by:** `templates/prompt-templates.yaml` (default-marker-prompt)
Scope: layer-1+

## FR-MCP-036 Audited Copilot Interactions

Every server-initiated Copilot interaction must be session-logged in every affected workspace. An `AuditedCopilotClient` decorator wraps `ICopilotClient` to create session log entries before and after each call, with action type `copilot_invocation`.

**Covered by:** `AuditedCopilotClient`, `Program.cs` DI registration, `McpStdioHost` DI registration, `CopilotServiceCollectionExtensions`
Scope: layer-1+

## FR-MCP-037 Director CLI Exec Command

*Moved to [Requirements-Director.md](Requirements-Director.md#fr-mcp-037-director-cli-exec-command)*
Scope: layer-1+

## FR-MCP-038 Session Continuity Protocol

Agents must follow a session continuity protocol: at session start, read the marker file, query recent session logs (limit=5), query current TODOs, and read Requirements-Matrix.md. During long sessions, post updated session logs every ~10 interactions. Requirements and design decisions must be captured as they emerge, not deferred.

**Covered by:** `templates/prompt-templates.yaml` (default-marker-prompt)
Scope: layer-1+

## FR-MCP-039 MCP Context Indexing for New Projects

Repo-local source files from McpServer.Cqrs and McpServer.Cqrs.Mvvm shall be indexed into the MCP context store for semantic search. McpServer.UI.Core and McpServer.Director have moved to the separate McpServerManager repository and must not be advertised as indexed capabilities in this repository marker.
Scope: layer-1+

## FR-MCP-040 Requirements Document CRUD Management

The server shall support CRUD operations for Functional Requirements (FR), Technical Requirements (TR), Testing Requirements (TEST), and FR-to-TR mapping rows backed by the canonical project requirements Markdown files.

**Covered by:** `RequirementsController`, `RequirementsDocumentService`, `IRequirementsRepository`
Scope: layer-1+

## FR-MCP-041 Requirements Document Generation

The server shall expose a requirements document generation endpoint that renders any canonical requirements document as Markdown, including the `Requirements-Matrix.md` traceability matrix, and exports all canonical documents directly to the workspace with canonical filenames.

**Status:** ✅ Complete

**Covered by:** `RequirementsController` (`POST /mcpserver/requirements/generate`), `RequirementsDocumentService`, `RequirementsDocumentRenderer`
Scope: layer-1+

## FR-MCP-042 Requirements Management MCP Tools

The STDIO MCP tool surface shall expose requirements management tools for listing, generating, creating, updating, and deleting requirements entries so AI agents can manage requirements directly from a conversation.

**Covered by:** `FwhMcpTools` (`requirements_list`, `requirements_generate`, `requirements_create`, `requirements_update`, `requirements_delete`), `RequirementsDocumentService`
Scope: layer-1+

## FR-MCP-043 Multi-Tenant Workspace Resolution

The server shall resolve the target workspace per-request using a three-tier resolution chain: (1) `X-Workspace-Path` header (highest priority), (2) API key reverse lookup via `WorkspaceTokenService`, (3) default/primary workspace from configuration. All workspaces are served on a single port; no per-workspace Kestrel hosts are spawned.

**Covered by:** `WorkspaceResolutionMiddleware`, `WorkspaceContext`, `WorkspaceTokenService`, `WorkspaceAuthMiddleware`
Scope: layer-1+

## FR-MCP-044 Shared Database Multi-Tenancy

All workspace data shall be stored in a single shared SQLite database with a `WorkspaceId` discriminator column on every entity table. EF Core global query filters ensure workspace data isolation per-request. Cross-workspace queries use `IgnoreQueryFilters()` for admin operations.

**Covered by:** `McpDbContext`, `WorkspaceContext`, all entity types (`WorkspaceId` property)
Scope: layer-1+

## FR-MCP-045 Cross-Workspace TODO Move

The server shall support moving a TODO item from one workspace to another via REST (`POST /mcpserver/todo/{id}/move`) and STDIO (`todo_move` MCP tool), preserving all item fields including implementation tasks, requirements, and metadata. The move is implemented as create-in-target then delete-from-source.

**Covered by:** `TodoController.MoveAsync`, `FwhMcpTools.TodoMove`, `TodoMoveRequest`, `TodoServiceResolver`
Scope: layer-1+

## FR-MCP-046 Voice Conversation Sessions

The server shall provide voice-enabled agent interaction via Copilot CLI, supporting session creation with device binding, voice turn processing (synchronous and SSE streaming), transcript retrieval, session interruption, ESC-key injection for generation cancellation, and automatic idle session cleanup with configurable timeout. Voice connections can attach to running pooled agents, including agents currently processing one-shot work. One active session per device is enforced.

**Covered by:** `VoiceController`, `VoiceConversationService`, `VoiceConversationOptions`, `CopilotInteractiveSession`
Scope: layer-1+

## FR-MCP-047 Desktop Process Launch

The server shall support launching interactive desktop processes from a Windows service (LocalSystem) context using `CreateProcessAsUser` with WTS session token negotiation, enabling Copilot CLI and other GUI/console tools to run on the interactive desktop with stdio pipe redirection or visible console windows.

**Covered by:** `DesktopProcessLauncher`, `NativeMethods`
Scope: layer-1+

## FR-MCP-048 YAML Configuration Support

The server shall support `appsettings.yaml` as an optional configuration source loaded after `appsettings.json` with hot reload, enabling YAML-format configuration alongside JSON for local-only overrides.

**Covered by:** `Program.cs` (`AddYamlFile`), `NetEscapades.Configuration.Yaml`
Scope: layer-1+

## FR-MCP-049 Prompt Template Registry

The server shall provide a global prompt template registry with REST API endpoints (`/mcpserver/templates`) and MCP tools for CRUD operations (list, get, create, update, delete) and test/render operations. Templates are stored as YAML files, support Handlebars rendering with declared variables, and are filterable by category, tag, and keyword. A Director TUI tab shall enable template browsing and preview.

**Covered by:** `PromptTemplateController`, `PromptTemplateService`, `PromptTemplateRenderer`, `FwhMcpTools` (6 template tools), `TemplateClient`. The Director template-browsing TUI surface (`TemplatesScreen`) moved to the separate `McpServerManager` repository.
Scope: layer-1+

## FR-MCP-050 Per-Agent Workspace Runtime Management

The server shall provide runtime management for workspace-bound agents, including process launch/stop/status, configurable isolation modes (`none`, `worktree`, `clone`), branch strategy handling (`direct`, `feature-branch`, `worktree`), session-log linkage to known agent definitions, marker-file agent-specific instruction sections, and restart-policy-driven health monitoring.

**Covered by:** `AgentService`, `AgentController`, `IAgentProcessManager`, `AgentProcessManager`, `IAgentIsolationStrategy`, `AgentIsolationStrategyResolver`, `IAgentBranchStrategy`, `AgentBranchStrategyResolver`, `WorkspaceProcessManager`, `SessionLogService`, `AgentHealthMonitorService`
Scope: layer-1+

## FR-MCP-051 System-Wide Default Copilot Model

The server SHALL allow configuration of a system-wide default Copilot model (e.g., `gpt-5.3-codex`) that is applied consistently across all Copilot session types - server-initiated CLI invocations (`CopilotClientOptions.Model`), voice conversation sessions (`VoiceConversationOptions.CopilotModel`), and built-in agent type defaults (`AgentDefaults`). The configured model SHALL be overridable per-workspace via agent configuration and per-invocation via explicit parameters.

**Technical Implementation:** [TR-MCP-CFG-005](./Technical-Requirements.md#tr-mcp-cfg-005) | [Mapping](./TR-per-FR-Mapping.md)
Scope: layer-1+

## FR-MCP-052 Agent Pool Runtime Orchestration

The server shall maintain a configured pool of long-lived agent processes and route agent execution through pooled agents instead of independent ad-hoc launches.

Agent pool definitions shall include: `AgentName`, `AgentPath`, `AgentModel`, `AgentSeed`, and `AgentParameters`.

**Covered by:** `AgentPoolOptions` *(planned)*, `AgentPoolService` *(planned)*
Scope: layer-1+

## FR-MCP-053 One-Shot Queueing and Deferred Attachment

One-shot requests shall execute through the agent pool queue. If no eligible pooled agent is available, requests shall be queued and dequeued when an agent becomes available.

One-shot requesters shall receive processing lifecycle notifications and may attach to the running agent via interactive voice session or read-only response stream.

**Covered by:** `AgentPoolQueueService` *(planned)*, `AgentPoolController` *(planned)*
Scope: layer-1+

## FR-MCP-054 Agent Pool Availability and Control Endpoints

The server shall expose endpoints to list pooled agents and real-time availability, and provide runtime controls for connect, start, stop, recycle, queue inspection, queue cancel/remove, queue reorder (queued items only), and free-form one-shot enqueue.

The server shall expose a dedicated Agent Pool notification SSE stream with payload fields `AgentName`, `LastRequestPrompt`, and `SessionId`.

**Covered by:** `AgentPoolController` *(planned)*, `AgentPoolNotificationService` *(planned)*
Scope: layer-1+

## FR-MCP-055 Default Agent Selection by Request Intent

If a request omits `AgentName`, the server shall determine the request intent and select the configured default agent for that intent using intent-default flags.

One-shot endpoint context values shall support: `Plan`, `Status`, `Implement`, and `AdHoc`.

**Covered by:** `AgentPoolIntentResolver` *(planned)*, `AgentPoolService` *(planned)*
Scope: layer-1+

## FR-MCP-056 Template-Aware One-Shot Prompt Resolution

One-shot requests shall support template-driven and ad-hoc prompt modes. Template mode accepts `promptTemplateId` with optional values dictionary and workspace-context-derived values; caller-provided values override workspace context on key conflicts.

The server shall expose an endpoint that accepts prompt template ID plus values dictionary and returns the rendered prompt.

If context is provided without template ID, the server shall use current context-based template resolution. For `AdHoc` context without template ID, explicit ad-hoc prompt text is required.

One-shot endpoint template rendering shall support an `id` parameter used to populate `{id}` placeholders in templates. `id` is required only for template-resolved requests.

**Covered by:** `PromptTemplateController` *(planned extension)*, `AgentPoolController` *(planned)*
Scope: layer-1+

## FR-MCP-057 Director Agent Pool Management UI

*Moved to [Requirements-Director.md](Requirements-Director.md#fr-mcp-057-director-agent-pool-management-ui)*
Scope: layer-1+

## FR-MCP-058 Interactive Presence Signaling

When a user disconnects from an interactive response stream, the server shall send `User is AFK.` to the agent session.

When a user reestablishes an interactive response stream connection, the server shall send `User is here.` to the agent after stream establishment.

These presence messages do not apply to one-shot sessions.

**Covered by:** `AgentPoolStreamService` *(planned)*, `VoiceConversationService` *(planned extension)*
Scope: layer-1+

## FR-MCP-059 DI-Centered Single Source of Truth State Flow

The system SHALL enforce a DI-centered Single Source of Truth architecture across `McpServer.Support.Mcp`: authoritative mutable data sources must be owned by DI-registered singleton or scoped services, services shall notify state availability/changes via `INotifyPropertyChanged`, and consumers shall pull current state from the owning service rather than receiving pushed data payloads.

**Technical Implementation:** [TR-MCP-ARCH-002](./Technical-Requirements.md#tr-mcp-arch-002) | [Mapping](./TR-per-FR-Mapping.md)
Scope: layer-1+

## FR-MCP-060 Director MVVM/CQRS Full Endpoint Coverage

*Moved to [Requirements-Director.md](Requirements-Director.md#fr-mcp-060-director-mvvmcqrs-full-endpoint-coverage)*
Scope: layer-1+

## FR-MCP-061 Canonical TODO and Session Identifier Conventions

The server shall enforce canonical identifier conventions for newly created TODO and session log payloads:

- Persisted TODO IDs must match either uppercase kebab-case ending in a three-digit sequence suffix (for example `PHASE0-REMOTE-001` or `MCP-TODO-CREATE-001`) or `ISSUE-{number}` for canonical GitHub-backed TODOs.
- Create requests may use `ISSUE-NEW` only as a temporary server-side alias for immediate GitHub-backed TODO creation; persisted TODO IDs must still be canonical.
- Session IDs must match `<Agent>-<yyyyMMddTHHmmssZ>-<suffix>` and be prefixed by the exact `sourceType`/`agent`.
- Request IDs must match `req-<yyyyMMddTHHmmssZ>-<slugOrOrdinal>`.

Validation failures return client-visible errors without mutating persisted data.

**Covered by:** `TodoValidator`, `TodoService`, `SqliteTodoService`, `TodoCreationService`, `SessionLogIdentifierValidator`, `SessionLogController`, `SessionLogService`
Scope: layer-1+

## FR-MCP-062 Workspace Change Notifications

The server shall provide a real-time workspace change notification system that publishes create/update/delete domain events for workspace mutations (TODOs, session logs, repo files, context sync, tool registry, tool buckets, workspaces, GitHub operations, marker lifecycle, agents, and requirements) over Server-Sent Events at `GET /mcpserver/events`, with optional category filtering.

**Covered by:** `IChangeEventBus`, `ChannelChangeEventBus`, `EventStreamController`, `TodoService`, `SqliteTodoService`, `SessionLogService`, `RepoFileService`, `ToolRegistryService`, `ToolBucketService`, `WorkspaceService`, `WorkspaceController`, `AgentService`, `RequirementsDocumentService`, `IngestionCoordinator`, `GitHubController`, `WorkspaceProcessManager`
Scope: layer-1+

## FR-MCP-063 Workspace GitHub OAuth Bootstrap, Token Lifecycle, and Actions Control

The server shall provide workspace-scoped GitHub authentication controls and workflow operations that support OAuth bootstrap and secure token usage without breaking existing gh CLI compatibility.

Functional behavior shall include:

- OAuth bootstrap discovery endpoints exposing configured client ID, redirect URI, authorize endpoint, and scopes.
- Workspace-scoped token lifecycle endpoints to set, inspect, and revoke GitHub tokens.
- Authenticated GitHub execution path that prefers stored workspace token credentials and falls back to ambient gh auth only when policy allows it.
- GitHub Actions workflow run management endpoints for list/detail/rerun/cancel operations.
- Typed client parity for all new GitHub auth and workflow run endpoints.

**Technical Implementation:** [TR-MCP-GH-001](./Technical-Requirements.md#tr-mcp-gh-001) | [TR-MCP-GH-002](./Technical-Requirements.md#tr-mcp-gh-002) | [TR-MCP-GH-003](./Technical-Requirements.md#tr-mcp-gh-003) | [TR-MCP-GH-004](./Technical-Requirements.md#tr-mcp-gh-004)

**Covered by:** `GitHubIntegrationOptions`, `FileGitHubWorkspaceTokenStore`, `GitHubController`, `GitHubCliService`, `ProcessRunner`, `GitHubClient`
Scope: layer-1+

## FR-MCP-064 Marketing and Adoption Documentation

The system SHALL provide marketing-oriented documentation that clearly explains what McpServer is, its key feature set, why adopters need it, and the currently supported UI tooling surfaces (including VS extension and Web UI experiences).

**Technical Implementation:** [TR-MCP-DOC-001](./Technical-Requirements.md#tr-mcp-doc-001) | [Mapping](./TR-per-FR-Mapping.md)
Scope: layer-1+

## FR-MCP-065 Direct Website URL Ingestion

The server shall ingest remote website content directly from one URL (with optional bounded same-host crawling) into the context store and GraphRAG pipeline without pre-downloading files into `docs/external`.

**Covered by:** `ContextController` (`POST /mcpserver/context/ingest-website`), `WebsiteIngestor`, `IngestionCoordinator`, `FwhMcpTools` (`context_ingest_website`), `ContextClient.IngestWebsiteAsync`
Scope: layer-1+

## FR-MCP-066 Hosted Microsoft Agent Framework Library

The system SHALL provide a .NET 9 class library that packages an MCP-aware agent for hosting inside external .NET applications built on Microsoft Agent Framework.

The hosted agent SHALL include a built-in workflow that treats MCP Server session logging, TODO management, repository file access, local desktop process launch, and stateful in-process PowerShell sessions as first-class primitives, allowing host applications to bootstrap/continue session logs, create and update turns, inspect and mutate TODO items, browse repository files, launch local programs, run PowerShell commands inside persistent local runspaces, drive those runspaces directly through the host-facing agent contract when needed, and execute plan/status/implementation task flows without reimplementing those integrations.

**Status:** ✅ Complete

**Technical Implementation:** [TR-MCP-AGENT-006](./Technical-Requirements.md#tr-mcp-agent-006) | [TR-MCP-AGENT-007](./Technical-Requirements.md#tr-mcp-agent-007) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `McpServer.McpAgent` (`ServiceCollectionExtensions`, `McpAgentOptions`, `Hosting/*`, `PowerShellSessions/*`, `SessionLog/*`, `Todo/*`), `McpServer.Client` (`McpServerClient`, `RepoClient`, `DesktopClient`), `McpServer.McpAgent.SampleHost` (`Program.cs`, `SampleHostPreviewFactory.cs`)
Scope: layer-1+

## FR-MCP-067 Detailed Internal Server Error Responses

The system SHALL return a detailed client-visible error description for every endpoint response that fails with HTTP 500.

Detailed 500 responses SHALL describe the failed operation clearly enough for callers to diagnose the failure path and distinguish server faults from client mistakes, while remaining sanitized so secrets, tokens, and other sensitive internals are not exposed in the response body.

**Technical Implementation:** [TR-MCP-HTTP-002](./Technical-Requirements.md#tr-mcp-http-002) | [Mapping](./TR-per-FR-Mapping.md)
Scope: layer-1+

## FR-MCP-068 Administrative Configuration Management API

The server SHALL provide an admin-only configuration API that returns the current effective configuration as flattened key-value pairs and supports patching selected values back into `appsettings.yaml` without rewriting unrelated settings or serializing values that originate only from non-file configuration providers.

The configuration-management endpoints SHALL require standard JWT Bearer authentication with the `admin` role. When OIDC is not configured, the endpoints SHALL remain unavailable.

**Technical Implementation:** [TR-MCP-CFG-006](./Technical-Requirements.md#tr-mcp-cfg-006) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `ConfigurationController`, `AppSettingsFileService`, `Program.cs` (`ConfigurationAdmin` policy), `WorkspaceController` (shared appsettings helper reuse)
Scope: layer-1+

## FR-MCP-069 Immediate GitHub-Backed TODO Creation

The server shall support a create-time TODO identifier of `ISSUE-NEW` that immediately creates a GitHub issue, determines the resulting issue number, and persists the local TODO using the canonical `ISSUE-{number}` identifier returned by GitHub.

This behavior shall be available through all server-side TODO creation entry points that already support normal TODO creation. Callers shall receive the canonical persisted identifier rather than the temporary `ISSUE-NEW` alias.

**Technical Implementation:** [TR-MCP-TODO-003](./Technical-Requirements.md#tr-mcp-todo-003) | [TR-MCP-GH-005](./Technical-Requirements.md#tr-mcp-gh-005) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `TodoCreationService`, `GitHubCliService`, `TodoController`, `FwhMcpTools`, `VoiceConversationService`
Scope: layer-1+

## FR-MCP-070 Authoritative ISSUE-* Update Sync and Immutable Descriptions

The server shall treat MCP TODO updates as authoritative for existing `ISSUE-{number}` TODO items. When an `ISSUE-*` TODO is updated through a server TODO update surface, the server shall push the authoritative MCP state to GitHub, append a GitHub issue comment describing the applied change set, and keep the ISSUE description/body immutable after the first sync.

Priority synchronization shall use canonical GitHub labels in the form `priority: HIGH`, `priority: MEDIUM`, or `priority: LOW`. GitHub-to-TODO refreshes for existing `ISSUE-*` items shall preserve the local priority and description that were already established by the first sync.

**Technical Implementation:** [TR-MCP-TODO-004](./Technical-Requirements.md#tr-mcp-todo-004) | [TR-MCP-GH-006](./Technical-Requirements.md#tr-mcp-gh-006) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `TodoUpdateService`, `IssueTodoSyncService`, `TodoController`, `FwhMcpTools`, `VoiceConversationService`
Scope: layer-1+

## FR-MCP-071 ISSUE Comment Round-Trip and GitHub-Driven Closure Reconciliation

The server shall round-trip `ISSUE-{number}` discussion between GitHub and MCP TODOs without mutating the established TODO description. GitHub-origin issue comments shall sync into the TODO note inside a generated GitHub-comments section, while user-authored TODO note content outside that generated section shall remain preserved across subsequent syncs.

When an `ISSUE-*` TODO is updated locally with new note text, the server shall propagate the appended TODO-authored comment back to GitHub as an issue comment. When the GitHub issue is later closed outside MCP, a GitHub-to-TODO sync shall mark the corresponding TODO as done.

**Technical Implementation:** [TR-MCP-GH-007](./Technical-Requirements.md#tr-mcp-gh-007) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `IssueTodoSyncService`, `TodoUpdateService`, `GitHubController`, `TodoController`
Scope: layer-1+

## FR-MCP-072 Database-Authoritative TODO Storage with YAML Projection and Audit History

The server shall treat SQLite as the authoritative current-state store for workspace TODO items. When a configured workspace TODO document already exists and the authoritative database is empty, initialization shall import the current YAML document once into SQLite and thereafter keep `docs/Project/TODO.yaml` synchronized as a deterministic projection of authoritative database state rather than as the live writable source of truth.

The server shall preserve TODO document metadata such as `notes`, `completed`, and `code-review-remediation.reference`, retain append-only audit history for TODO state mutations, and expose that audit history through HTTP, typed client, and MCP tool surfaces so callers can retrieve tracked TODO states even after deletion when history exists.

**Technical Implementation:** [TR-MCP-TODO-005](./Technical-Requirements.md#tr-mcp-todo-005) | [TR-MCP-TODO-006](./Technical-Requirements.md#tr-mcp-todo-006) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `SqliteTodoService`, `TodoYamlFileSerializer`, `TodoController`, `TodoClient`, `McpServerMcpTools`, `TodoServiceFactory`
Scope: layer-1+

## FR-MCP-073 Parseable Log Event Field Cap

The server shall cap each Parseable log event payload to a maximum of 250 top-level fields so Parseable ingest remains within the supported field-count envelope for a single event.

When application log events contain more structured properties than the Parseable limit allows, the server shall preserve the canonical Parseable metadata fields (`timestamp`, `level`, `message`, and `exception` when present) and omit excess user properties rather than emitting an oversized payload.

**Technical Implementation:** [TR-MCP-LOG-003](./Technical-Requirements.md#tr-mcp-log-003) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `ParseableEventFormatter`, `ParseableBatchFormatter`
Scope: layer-1+

## FR-MCP-074 Azure DevOps Repository Pipeline Migration

The repository SHALL define Azure DevOps YAML pipelines as the source of truth for repository CI/CD instead of the retired GitHub Actions workflow files.

The Azure DevOps pipeline SHALL preserve the current repository automation intent for branch/path-filtered validation, published server artifacts, documentation artifacts, Windows MSIX packaging, and branch-conditional client package publication, while ignoring any separate Copilot coding agent pipeline.

**Technical Implementation:** [TR-MCP-CI-001](./Technical-Requirements.md#tr-mcp-ci-001) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `azure-pipelines.yml`, `docs/AZURE-PIPELINES.md`
Scope: layer-1+

## FR-MCP-075 PowerShell Session Cache Discovery from `.mcpSession`

The PowerShell `McpSession` module SHALL discover and reuse the current session object cached in the workspace `.mcpSession` folder so follow-on commands can resolve the active session even when the caller does not pass an explicit session object.

This cache-discovery behavior SHALL remain backward compatible with the existing `.mcpServer/session.yaml` slug/state wrapper and SHALL prefer the current-session cache when both representations are available.

**Technical Implementation:** [TR-MCP-AGENT-013](./Technical-Requirements.md#tr-mcp-agent-013) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `tools/powershell/McpSession.psm1`
Scope: layer-1+

## FR-MCP-076 Marker File Trust Bootstrap and Session Authenticity Validation

The server shall render a trust-bootstrap contract into `AGENTS-README-FIRST.yaml` that instructs agents to verify the marker signature, perform a nonce-based `/health` challenge, and treat any signature or nonce mismatch as `MCP_UNTRUSTED`.

When trust validation fails, the bootstrap flow shall stop using MCP services and shall not probe additional MCP endpoints. The marker contract shall remain explicit enough for `McpSession`, `McpTodo`, and `McpContext` to follow the same verified bootstrap sequence without diverging on trust semantics.

**Technical Implementation:** [TR-MCP-SEC-003](./Technical-Requirements.md#tr-mcp-sec-003) | [TR-MCP-AGENT-014](./Technical-Requirements.md#tr-mcp-agent-014) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `src/McpServer.Services/Services/MarkerFileService.cs`, `templates/prompt-templates.yaml`, `src/McpServer.ServiceDefaults/Extensions.cs`, `tools/powershell/McpSession.psm1`, `tools/powershell/McpTodo.psm1`, `tools/powershell/McpContext.psm1`, `docs/context/module-bootstrap.md`, `docs/USER-GUIDE.md`
Scope: layer-1+

## FR-MCP-077 Server Federation and Request Proxying

The server shall support an opt-in federation mode that proxies incoming requests to a configured remote MCP server instance. Routing shall support a global default target and per-workspace overrides. The feature shall include anti-loop protection (via `X-Mcp-Federation-Hop` header with a configurable maximum hop count), transparent SSE/streaming forwarding for `/mcp-transport`, a runtime management REST API at `/mcpserver/federation`, and auto-discovery of federation targets from running tunnel providers.

**Status:** ✅ Complete

**Technical Implementation:** `FederationOptions`, `FederationRegistry`, `FederationProxyService`, `FederationMiddleware`, `FederationController`

**Configuration:** `Mcp:Federation:Enabled`, `Mcp:Federation:Targets`, `Mcp:Federation:DefaultTarget`, `Mcp:Federation:WorkspaceRoutes`, `Mcp:Federation:MaxHops`
Scope: layer-1+

## FR-MCP-078 GraphRAG Ad-Hoc Document Ingestion

The server shall accept raw text or markdown content via a REST endpoint and MCP tool, chunk it, generate embeddings, store it in the context database and vector index, and optionally trigger a GraphRAG re-index. Documents ingested this way shall use source type "adhoc-text" by default and support caller-specified title, source type, and source key metadata.

**Status:** ✅ Complete

**Covered by:** `GraphRagController` (`POST /mcpserver/graphrag/documents/ingest`), `McpServer.GraphRag` (`GraphRagService` ad-hoc ingestion path), `FwhMcpTools` (graphrag ingest tool)
Scope: layer-1+

## FR-MCP-079 GraphRAG Entity and Relationship CRUD

The server shall provide full CRUD operations for explicit graph entity nodes and relationship edges, persisted in workspace-scoped EF Core tables. Entities shall have name, type, description, and extensible JSON metadata. Relationships shall link two entities with a typed, weighted, described edge. Deleting an entity shall cascade to all its relationships. All operations shall be available via REST endpoints, MCP tools, and REPL commands.

**Status:** ✅ Complete

**Covered by:** `GraphRagController` (entity + relationship endpoints), `McpServer.GraphRag` (`GraphRagService` entity / relationship CRUD), `GraphEntityEntity`, `GraphRelationshipEntity`, `FwhMcpTools` (graphrag entity/relationship tools), `McpServer.Repl.Core` (graphrag command shapes)
Scope: layer-1+

## FR-MCP-080 GraphRAG Document Management

The server shall provide endpoints to list indexed documents with chunk counts and token totals, retrieve chunks for a specific document ordered by chunk index, and delete a document with cascade removal of its chunks and corresponding vector index entries. All operations shall be workspace-scoped and available via REST endpoints, MCP tools, and REPL commands.

**Status:** ✅ Complete

**Covered by:** `GraphRagController` (document list/get/delete endpoints), `McpServer.GraphRag` (`GraphRagService` document management), `ContextDocumentEntity`, `ContextChunkEntity`, `FwhMcpTools` (graphrag document tools)
Scope: layer-1+

## FR-MCP-081 Byrd Iteration Phase and TODO Execution Persistence

The server shall persist Byrd iteration phases, decomposed execution TODOs, and TODO checkpoints so agents can resume multi-step work from MCP state instead of chat history. Persisted execution TODOs shall carry goal, summary, acceptance criteria, constraints, requirement links, relevant files, next action, test plan state, validation state, and linked session turn identifiers.

**Status:** ✅ Complete

**Covered by:** `TodoExecutionController` (`/mcpserver/todo-execution/*`), `TodoExecutionService`, Byrd phase + checkpoint entities, `McpDbContext`
Scope: layer-1+

## FR-MCP-082 Bounded Byrd Execution Context Hydration

The server shall return a bounded active TODO execution context and a checkpoint-based delta context for the current execution TODO. Hydration shall prefer concise requirement snippets, concise recent session-turn summaries, relevant files, artifacts, test state, validation state, and execution pointers, and shall not return full plan markdown or broad session-log history when compact state is sufficient.

**Status:** ✅ Complete

**Covered by:** `TodoExecutionController` (`active`, `next-ready`, `{todoId}`, `{todoId}/delta` endpoints), `TodoExecutionService`
Scope: layer-1+

## FR-MCP-083 Structured Android Validation for Byrd TODOs

The server shall expose a structured `adb_step` surface for safe Android validation actions used during Byrd execution. Supported actions shall be limited to fixed safe operations such as screenshot, tap, swipe, text input, keyevent, wait, app launch, and focus inspection, and their results shall be storable as validation evidence and TODO checkpoint artifacts.

**Status:** ✅ Complete

**Covered by:** `TodoExecutionController` (`POST /mcpserver/todo-execution/adb/step`), `TodoExecutionService.AdbStepAsync`, `AdbStepAction` / `AdbStepRequest` models, `FwhMcpTools` (`adb_step` tool)
Scope: layer-1+

## FR-MCP-084 Requirements Wiki Workspace Export/Import

The server, REPL, and agent plugins shall support requirements export and import in wiki format. Wiki export shall write both Azure DevOps Wiki and GitHub Wiki document folders directly under docs/Project/wiki. Wiki import shall detect wiki document folders, select the authoritative platform source using manifest and file modified timestamps, and create, update, delete, or ignore requirements and mappings to match the selected source.

**Status:** ✅ Complete

**Covered by:** `RequirementsController` (wiki export + ingest endpoints), `RequirementsDocumentService` (wiki renderer + parser), `McpServer.Repl.Core` (requirements wiki workflow commands)
Scope: layer-1+

## FR-MCP-085 QA Workspace Question CRUD

Create / read / update / delete a Question (title, body, tags[], author).
Scope: layer-1+

## FR-MCP-086 QA Workspace Answer CRUD

Create / read / update / delete an Answer attached to a Question.
Scope: layer-1+

## FR-MCP-087 QA Accepted Answer Invariant

Accept exactly one Answer per Question (idempotent; re-accept clears prior accepted answer).
Scope: layer-1+

## FR-MCP-088 QA Question Tag Filtering

Tag filter on Question list with AND semantics (`?tag=foo&tag=bar`).
Scope: layer-1+

## FR-MCP-089 QA Per User Voting

Vote (+1 / -1) on Question and Answer with one-vote-per-user enforcement. A given actor may hold at most one active vote per entity (Question or Answer). Submitting the same vote a second time is idempotent (returns the current state, no counter change, no new audit row). Submitting the opposite vote replaces the prior vote (counter adjusts by +/- 2; an audit row is written for the change). An actor may explicitly revoke their vote (counter adjusts by -1 or +1; audit row recorded). Voter identity is the value resolved by `IQaAuthorResolver`. The Question/Answer rows still store a denormalized counter for fast reads; the authoritative per-voter state lives in a `QaVoteEntity` table with a unique constraint (TR-MCP-QA-032). Voter identity and every vote transition (apply, change, revoke) appear in the audit history (TR-MCP-QA-019), and a voter-history endpoint exposes them (TR-MCP-QA-031).
Scope: layer-1+

## FR-MCP-090 QA Threaded Comments

Threaded comments on Questions and Answers with depth cap (<= 3).
Scope: layer-1+

## FR-MCP-091 QA FAQ Projection

`GET /mcpserver/qa/faq` returns questions that have an accepted answer, projected as `{ questionId, title, tags[], voteCount, acceptedAnswer: { body, author, voteCount }, deeplink }` where `deeplink = "/mcpserver/qa/questions/{id}"`. Default sort: accepted-answer voteCount desc, then question voteCount desc.
Scope: layer-1+

## FR-MCP-092 QA Author Resolution

Author identity resolves via request-body `author` if provided, falling back to API-key -> workspace-identity (via `WorkspaceTokenService`), then JWT `sub` claim.
Scope: layer-1+

## FR-MCP-093 QA Workspace Isolation

All Q&A data is workspace-scoped via composite PK `(WorkspaceId, Id)` and EF global query filter (TR-MCP-MT-003 pattern).
Scope: layer-1+

## FR-MCP-094 QA REST MCP STDIO and Client Parity

Q&A is reachable from REST, MCP STDIO tools, and the typed C# client library with feature parity.
Scope: layer-1+

## FR-MCP-095 QA REPL and PowerShell Parity

Q&A is reachable from the REPL via a `workflow.qa.*` command namespace (interactive REPL + `--agent-stdio` YAML envelope protocol) and from a PowerShell module (`McpQa.psm1`) following the `Verb-Noun` pattern of `McpTodo.psm1`.
Scope: layer-1+

## FR-MCP-096 QA User and Agent Documentation

Documentation surfaces the Q&A subsystem for end users, integrators, and agents (USER-GUIDE, CLIENT-INTEGRATION, api-capabilities, AGENTS, FAQ, README, plus a new `qa-schema.md` context doc).
Scope: layer-1+

## FR-MCP-097 QA Plugin Skill

Each Claude Code plugin (sibling repos `mcpserver-claude-code-plugin`, `mcpserver-claude-cowork-plugin`, `mcpserver-codex-plugin`, `mcpserver-cline-plugin`, `mcpserver-cline-v2-plugin`, `mcpserver-copilot-plugin`) gets a `skills/qa/SKILL.md` skill that lets agents use Q&A as a knowledge source - ask, answer, accept, and read FAQ via the REPL workflow.
Scope: layer-1+

## FR-MCP-098 QA Append Only Audit

Full audit tracking: every Q&A mutation (question create/update/delete, answer create/update/delete, accept/un-accept, vote +1/-1, comment add/delete) writes an append-only audit row capturing actor, action, version, full pre-mutation snapshot, and timestamp. Audit history is queryable per entity (`GET /mcpserver/qa/questions/{id}/audit`, `/answers/{id}/audit`, `/comments/{id}/audit`) and at workspace scope (`GET /mcpserver/qa/audit`) with paging, matching the TODO audit endpoint contract.
Scope: layer-1+

## FR-MCP-099 QA Web Research Capture

Mandatory web-research-to-Q&A capture: whenever a plugin/agent performs an internet search (web fetch, web search, MCP web tool, browser MCP, or any external HTTP retrieval) in order to answer a workspace-scoped question, the agent MUST post a new Question to `/mcpserver/qa/questions` containing the original prompt, then post an Answer containing the synthesized response with every source URL cited inline (markdown links) and as a `sources[]` array in the answer body's JSON sidecar. If the agent verified the synthesized answer, it MUST also call accept-answer. This is enforced by the `qa/SKILL.md` in every sibling plugin repo (mandatory rule at top of body) and surfaced in `AGENTS.md` / `CLAUDE.md` so agents cannot opt out. Captured `web_reference` actions in the session log point at the resulting Q&A entry's deeplink.
Scope: layer-1+

## FR-MCP-100 QA Close and Duplicate Flags

Close / duplicate flags: a Question can be closed with a reason and reopened; a Question can be marked as a duplicate of another Question (canonical) with both directions navigable. Closed questions are excluded from FAQ by default and from the default Question list (opt-in via `?includeClosed=true`); duplicates redirect FAQ consumers to the canonical Question via the deeplink. Close and duplicate transitions are full audit events (TR-MCP-QA-018 family).
Scope: layer-1+

## FR-MCP-101 QA Markdown Rendering and Sanitization

HTML / Markdown sanitization and rendering: every Question.Body, Answer.Body, and Comment.Body is authored as Markdown, stored verbatim, and additionally rendered to sanitized HTML at write time. Both representations are returned in the DTOs (`body` raw Markdown, `bodyHtml` sanitized HTML). The sanitizer strips script, iframe, on-* attributes, javascript: URLs, and other XSS vectors per a whitelist (allow paragraph, headings <=3, lists, code/pre, bold/italic, links with `rel="nofollow noopener"`, inline code, blockquote, tables). Sanitization runs on every write and on every audit-snapshot read so historical bodies are also safe to render.
Scope: layer-1+

## FR-MCP-102 QA Generated FAQ Wiki Page

FAQ wiki page: the documentation wiki output (Azure DevOps wiki under `docs/Project/wiki/azure/` and GitHub wiki under `docs/Project/wiki/github/`) includes a generated `FAQ.md` page rendered from the live `/mcpserver/qa/faq` endpoint of a configured workspace at build time. The page lists every accepted Q&A with the question title (linked to its detail endpoint), tags, vote counts, the rendered HTML body of the accepted answer, and the `sources[]` array as a sources section. The wiki Home / Sidebar / .order files reference the new FAQ page. The page is regenerated by the Nuke build during the wiki publication target.
Scope: layer-1+

## FR-MCP-103 Hub-and-Spoke Federation

The server shall support hub-and-spoke federation where a Hub instance is authoritative for enrolled LocalProxy servers, global workspace inventory, operation intake, sync fanout, queue status, and conflicts. Existing point-to-point federation remains supported as DirectProxy; Standalone continues to serve only local workspaces. A LocalProxy shall forward MCP requests to the configured hub, queue mutating requests durably during hub outages, replay queued operations when connectivity returns, and expose role, hub URL, proxy id, queue depth, stale/queued status, and conflict status to agents and operators.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Adapter diagnostics enumerate every required mutable state domain and distinguish covered, local-only, and apply-supported domains.
- [ ] LocalProxy live forwarding continues to route /mcpserver/* requests, including /mcpserver/memory, through existing proxy middleware when the hub is reachable.
- [ ] Mutating LocalProxy requests that are eligible for replay are queued durably during hub outages with operation id, domain, resource id, workspace id, headers, body, and base version.
- [ ] Queued operations replay through signed envelopes when signing is configured.
- [ ] Stale base-version operations create federation conflicts and do not overwrite authoritative hub state.

## FR-MCP-104 Decision-complete agent plans

All generated plans must be detailed enough for a less expensive implementation model to execute successfully without resolving unstated product, architecture, interface, testing, or rollout decisions.
Scope: layer-1+

## FR-MCP-105 Database integrity and durable audit enforcement

The MCP Server must preserve database integrity across all supported providers by enforcing workspace, TODO, requirement, federation, soft-delete, and audit relationships as durable relational contracts.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Every workspace-scoped memory index row references a canonical Workspaces row; global memory and index rows retain null WorkspaceId.
- [ ] Memory version and index rows remain durable when a parent memory is soft-deleted; database relationships do not cascade-delete them.
- [ ] SQLite, PostgreSQL, and SQL Server migrate existing memory rows to the corrected constraints without data loss and reject orphan workspace references.

## FR-MCP-106 Reliable plugin requirement updates

Agent plugins must reliably update existing FR, TR, and TEST requirement records through workflow.requirements.update* commands, including priority changes, without failing inside the wrapper path.
Scope: layer-1+

## FR-MCP-107 Outstanding session work consolidation

MCP Server must support an audited consolidation plan that inventories outstanding work from a long session, separates validated changes from unresolved dirty work, and sequences completion through Byrd gates before deploy or publish.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Each cumulative validation run uses an explicit unique run ID and deterministic TestResults/<runId> outputs; reports from another run or an earlier candidate cannot satisfy the current gate.
- [ ] Nuke Test and provider targets emit the selected-project inventory and exactly one fresh per-project TRX for every selected project without silently changing exclusions; missing, duplicate, or zero-discovery project results fail the gate.
- [ ] The session-lifecycle unit gate runs the complete Pester directory, Nuke Test, and Build.Tests non-integration scope, records structured Pester counters and each command result, and does not allow a later successful command to hide an earlier failure.
- [ ] Validation rejects stale, missing, duplicate, skipped, notExecuted, failed, empty, zero-discovery, and Pester failed-block or failed-container reports using run-start, source-file, tool-version, and candidate-source manifests.
- [ ] Build.Tests contains concrete red cases for fresh-run inventory acceptance, missing and duplicate reports, stale evidence, zero discovery, skips and notExecuted results, Pester failed blocks or containers, candidate-source drift, and earlier-command failure masking.

## FR-MCP-108 TODO Markdown description preservation

TODO create, update, read, audit, and projection paths shall preserve description Markdown formatting and whitespace instead of normalizing or stripping meaningful content.
Scope: layer-1+

## FR-MCP-109 Batch requirements mutation

The MCP Server shall allow agents and API clients to create or update multiple functional, technical, and test requirements in one atomic request by submitting a records array.
Scope: layer-1+

## FR-MCP-110 Deterministic Nuke PowerShell execution

Nuke build and deployment automation SHALL run PowerShell child hosts with non-interactive, no-profile flags so user profiles, prompts, aliases, and interactive host behavior cannot alter scripted execution.
Scope: layer-1+

## FR-MCP-111 Package workflow closeout skills across McpServer plugins

All McpServer plugin distributions expose sync-logs, commit-sync, and wrap-up as packaged skills so agents can synchronize logs, commit and push interrupted work, and close out MCP-backed work consistently across plugin families.
Scope: layer-1+

## FR-MCP-112 Requirements export description and AC formatting

Requirements exports shall render requirement descriptions as readable Markdown text and shall display structured acceptance criteria as a bulleted list instead of hiding or flattening AC into dense table cells.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Wiki exports render TEST requirement descriptions outside dense table cells so long descriptions remain readable. (evidence: RequirementsDocumentServiceTests.GenerateWikiAsync_RendersTestingRequirementsAsGroupedSectionsWithAcceptanceCriteria asserts per-TEST headings and paragraphs.)
- [x] Wiki exports render structured acceptance criteria under an Acceptance Criteria label as Markdown checklist bullets. (evidence: The same focused test asserts unchecked and checked AC bullets, including evidence text.)
- [x] Azure and GitHub wiki exports use the same requirement description and AC formatting. (evidence: The focused service test asserts GitHub and Azure Testing-Requirements.md output are equal.)

## FR-MCP-113 Plugin requirement batch payload parsing

The system SHALL accept valid YAML and JSON records arrays for requirement batch operations while preserving nested acceptance criteria.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] workflow.requirements.updateFrBatch accepts unindented records YAML and preserves nested acceptance criteria.

## FR-MCP-114 Parent TODO completion isolation

The system SHALL keep a TODO item's top-level done state independent from nested implementation task done state. Updating implementationTasks[].done SHALL NOT mark the parent TODO done unless the update request explicitly sets the parent done field or the TODO completion workflow deliberately satisfies the parent completion criteria.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Updating a nested implementation task done value does not include or change the top-level TODO done field when the caller did not explicitly set it. (evidence: Focused Bats test TODO HTTP body does not promote implementation task done to parent done passed in all five Bash plugin repos.)
- [x] A live TODO update can mark one implementation task done while the parent TODO remains not done. (evidence: Temporary live TODO TEMP-ISSUE39-001 remained done=false after updating one implementation task to done=true, then was deleted.)

## FR-MCP-115 Session and compaction hook output schema compliance

MCP plugin session and compaction hooks SHALL emit schema-valid hook outputs for their event type. Status-only SessionStart, SessionEnd, PreCompact, and PostCompact outcomes SHALL emit an empty JSON object; hooks that emit hookSpecificOutput SHALL include the matching hookEventName and only fields supported by that event. PostCompact SHALL NOT emit additionalContext because that event cannot inject context.
Scope: layer-1+
**Acceptance Criteria:**
- [x] SessionStart, SessionEnd, PreCompact, and PostCompact status-only hook scripts emit {} instead of non-spec hookSpecificOutput status payloads. (evidence: Hook Bats suites assert exact {} output for the affected session and compact hooks.)
- [x] PostCompact does not emit additionalContext. (evidence: Hook Bats suites assert post-compact output is {} and does not contain additionalContext.)

## FR-MCP-116 GitHub CLI service-account ownership resilience

The system SHALL allow GitHub-backed TODO and issue operations to run under service accounts even when Git rejects the workspace repository as dubious ownership, without requiring an untracked global Git configuration mutation.
Scope: layer-1+

## FR-MCP-117 Codex plugin wrapper bounded execution

The Codex MCP plugin wrapper SHALL return successful workflow responses promptly or fail within a caller-controlled bounded timeout with actionable diagnostics instead of forcing raw REST fallback.
Scope: layer-1+

## FR-MCP-118 Keyserver trust service

McpServer SHALL provide keyserver trust services that register trusted parties, manage public key metadata, sign transaction manifests, verify signed manifests, reject invalid or replayed manifests, preserve historical signing descriptors for verification, and persist audit evidence without exposing private key material.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Publisher, subscriber, arbiter, and future model parties can be provisioned with party ID, role, active signing key ID, active encryption key ID, status, created/updated UTC, and audit metadata.
- [x] Manifest signing binds transaction ID, turn ID, publisher party, subscriber party, key IDs, sequence, nonce, issued UTC, expiry UTC, algorithms, diffgram SHA-256, and encrypted body SHA-256.
- [x] Manifest verification succeeds for an unchanged canonical payload and valid keyserver signature and rejects unknown parties, disabled parties, unknown keys, disabled keys, expired manifests, replayed nonces, stale sequences, malformed signatures, and hash mismatches with deterministic reason codes.
- [x] Keyserver signing never returns, serializes, or logs private key material; external signing private PEM can be provisioned from file-backed startup configuration.
- [x] Key rotation supports a new active signing key while retaining old public descriptors for historic verification; full lifecycle automation beyond file-backed startup provisioning is deferred and explicit future scope.

## FR-MCP-119 Subscriber diffgram commit service

McpServer SHALL provide subscriber services that verify keyserver-signed manifests, decrypt intended diffgrams, validate encrypted and plaintext hashes, durably commit accepted diffgrams, expose abort/status flows, and reject invalid or conflicting commits.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Subscriber accepts a commit only when manifest verification succeeds against keyserver trust and the protected payload is addressed to the subscriber party/key ID.
- [x] Subscriber validates encrypted body SHA-256 before decrypt and plaintext diffgram SHA-256 after decrypt.
- [x] First valid commit persists transaction ID, diffgram ID, manifest hash, sequence, status, committed UTC, reason details, and audit metadata durably.
- [x] Duplicate commit with identical transaction/diffgram/hash is idempotent and returns committed; duplicate commit with mismatched payload, manifest, hash, or sequence is rejected as conflict.
- [x] Abort records aborted status, refuses later commit, and status exposes pending, committed, rejected, aborted, and reason details without exposing secrets.
- [x] Subscriber encryption private key rings decrypt old and rotated protected envelopes and bind separate-host configuration to the configured subscriber key material.

## FR-MCP-120 MCP Server transaction gating

McpServer SHALL gate QuadBrain/brain-slot mutating paths behind transaction manifest signing and subscriber commit confirmation before returning committed success, or fail closed before uncompensated side effects when a safe compensation boundary is not yet available. FR-MCP-173 carves out every non-QuadBrain first-party mutation (TODO, requirements, session-log for every source type including QBAgent, memory, repo, tools, GitHub, GraphRAG, voice, agent pool, REPL TODO workflow, requirements ingest, context rebuild, and federation apply/control): those persist without keyserver/coordinator even when turn transactions are enabled. QuadBrain brain-slot.invoke and brain-slot.weight-update remain in this gate.
Scope: layer-1+
**Acceptance Criteria:**
- [x] QuadBrain brain-slot.invoke and brain-slot.weight-update either route through compensation-capable coordinator gates or fail closed while required transactions are active. All other first-party mutations (federation apply, memory, TODO, repository write, prompt templates, TODO execution, requirements repository/export/ingest, session-log for every source type including QBAgent, tool registry, voice, agent-pool, GraphRAG, GitHub, context rebuild/website/sync, and federation control-plane) are governed by FR-MCP-173 and SHALL persist without coordinator/keyserver even when Mcp:TurnTransactions:Enabled=true.
- [x] QuadBrain coordinator ExecuteAsync rollback restores mutation snapshots when a brain-slot transaction fails after mutation. TransactionGatedMemoryService general-agent mutations are FR-MCP-173 and do not use coordinator compensation.
- [x] QuadBrain coordinator ExecuteAsync paths retain TODO compensation. TransactionGated TODO adapters are FR-MCP-173. ISSUE-backed GitHub side-effect compensation remains future scope for QuadBrain-gated paths.
- [x] Session-log writes including QBAgent are governed by FR-MCP-173 and persist without coordinator/keyserver. Workspace-stamp repair remains fail-closed while required transactions are active because it is not compensated.
- [x] Generic REPL client passthrough blocks unsafe protected namespaces and unclassified client namespaces while required transaction gating is active for QuadBrain operations, while explicitly service-gated namespaces remain routed to server-side gates that apply FR-MCP-173 for non-QuadBrain mutations.
- [x] Complete provider-level isolation across delayed subscriber rejection and bucket/GitHub whole-orchestration compensation remain documented future enhancements, not committed-success claims for this slice.

## FR-MCP-121 Degraded mode and rollback

McpServer SHALL enter explicit degraded mode when transaction dependencies are unavailable or commit cannot complete, allow only safe reads or explicitly fail-closed operations, and preserve audit records through rollback.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Coordinator status exposes enabled/degraded state, last reason, message, and transaction dependency health.
- [x] Required transaction gates reject mutation before side effects when the coordinator is degraded or required transaction dependencies cannot sign or commit.
- [x] Commit failure invokes available rollback compensation and reports rollback success or rollback failure without deleting audit evidence.
- [x] Durable pending commit handoffs are canceled after successful rollback compensation or commit timeout settlement.
- [x] Runtime/control-plane endpoints without complete remote compensation fail closed or remain explicitly deferred until future compensation slices.

## FR-MCP-122 Byrd v4 execution control

The transactional diffgram implementation SHALL follow Byrd Development Process v4 with requirements-first, failing-test-first, mocks-first, refactor, explicit validation, and zero-failure zero-skip validation gates for each executed scope.
Scope: layer-1+
**Acceptance Criteria:**
- [x] The plan records FR/TR/TEST identifiers and mappings before implementation closeout.
- [x] Each implementation slice names focused tests and validates zero failures and zero skips for the executed scope.
- [x] Deferred work is tracked as TODO/requirements state instead of skipped test placeholders.
- [x] Final closeout validation includes focused transaction tests, full affected unit suites, traceability validation, and solution build evidence.

## FR-MCP-123 Quad-model future scaffolding

The transaction foundation SHALL preserve the imported quad-model architecture while keeping Curiosity execution, AoT reconciliation execution, quad-model orchestration, and weight-update execution disabled by default until later requirements authorize them.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Imported diagrams retain stable IDs and future branch annotations for Curiosity, AoT reconciliation, weight redistribution, and quad orchestration.
- [x] Current production code implements transaction security and mutation gating only; direct model execution and weight-update execution remain disabled/deferred.
- [x] Deferred future scope is explicitly documented in the plan, mutation audit, design rounds, TEST-MCP-163, and TEST-MCP-170.

## FR-MCP-124 Imported document and diagram preservation

The imported Quad-Model transactional diffgram document SHALL be preserved as local project-contract artifacts, including its diagrams, branch IDs, source references, and implementation-scope annotations.
Scope: layer-1+
**Acceptance Criteria:**
- [x] All six imported Mermaid diagram IDs are present in `docs/Project/Quad-Model-Transactional-Diffgram-Plan.md`.
- [x] Each imported diagram section includes a Mermaid block, imported source-section reference, and repository annotations.
- [x] Diagram-derived implemented and deferred branches map to TEST-MCP-165 through TEST-MCP-173.

## FR-MCP-125 Federation and compatibility preservation

The transactional diffgram implementation SHALL remain additive to existing federation behavior and SHALL preserve existing HMAC federation envelope compatibility while adding transaction-specific trust boundaries.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Federation HMAC envelopes remain separate from transaction manifest signing and protected diffgram encryption.
- [x] Global federation mutation-adapter apply paths are transaction-gated through the coordinator.
- [x] Federation control-plane mutations fail closed while required transaction gating is active until full compensation is designed.
- [x] Existing proxy/federation compatibility expectations remain documented separately from transaction crypto.

## FR-MCP-126 aiUnit plan review

The transaction plan SHALL include a test-only aiUnit plan review gate that fails on critical or high findings and records run-log evidence before closeout.
Scope: layer-1+
**Acceptance Criteria:**
- [x] `tests/McpServer.PlanReview.Tests` validates aiUnit plan-review run-log evidence for PLAN-TURNTRANSACTIONS-001.
- [x] The gate fails when run-log findings contain critical or high severity findings.
- [x] The run-log artifact records prompt scope, provider/model metadata, findings status, and reviewed scope.
- [x] Explicit future-disabled work is treated as non-blocking only when it does not hide a safety, correctness, or validation gap.

## FR-MCP-127 Diagram-derived implementation tests

In-scope branches from imported activity and sequence diagrams SHALL have implementation-test coverage or an explicit deferred requirement before related code is written.
Scope: layer-1+
**Acceptance Criteria:**
- [x] SD-DIFFGRAM-001 valid, invalid, signing, verification, encryption, and hash branches are covered by keyserver/subscriber/client/integration tests.
- [x] AD-TXN-001 commit, subscriber unavailable, degraded, rollback, timeout, and audit branches are covered by coordinator, pub-sub, federation, and mutation-gating tests.
- [x] Deferred diagram branches for Curiosity, AoT, weight redistribution, and full quad execution are explicitly documented as disabled future scope.
- [x] TEST-MCP-165 through TEST-MCP-173 preserve diagram IDs, branch IDs, design mappings, and traceability closeout evidence.

## FR-MCP-128 Two-round architecture and design review

The implementation SHALL include two architecture/design rounds before closeout: a first architecture round defining boundaries, ownership, trust, storage, threat model, and gap analysis, and a second implementable design round defining DTOs, entities, options, interfaces, endpoint contracts, reason codes, audit payloads, XMLDoc obligations, and test mappings.
Scope: layer-1+
**Acceptance Criteria:**
- [x] `TurnTransactions-Architecture-Round1.md` captures component boundaries, trust model, storage boundaries, rollback/audit rules, threat model, and gap analysis.
- [x] `TurnTransactions-Design-Round2.md` captures implementable DTOs, entities, options, interfaces, endpoint contracts, reason codes, canonicalization, audit payloads, XMLDoc obligations, and TEST-MCP-158 through TEST-MCP-173 mappings.
- [x] `TurnTransactions-Mutation-Endpoint-Audit.md` captures current gated, fail-closed, and explicitly deferred mutation surfaces.
- [x] Requirements matrix and FR/TR mapping rows link FR-MCP-118 through FR-MCP-128 to transaction TR and TEST records.

## FR-MCP-129 Durable external brain-slot registry and live invocation

The MCP runtime SHALL provide durable workspace-scoped external brain-slot definitions for LeftHemisphere, RightHemisphere, CuriosityEngine, and ArbiterOfTruth, including CRUD, readiness status projection, and individually gated live model invocation.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Brain-slot definitions are durable CRUD records scoped by workspace and role.
- [x] Exactly one enabled slot per workspace and role is allowed; enabling a replacement requires replaceExisting=true and writes an audit entry.
- [x] A workspace is quad-ready only when all four roles have enabled slots with valid provider, model, endpoint policy, credential reference, and trusted party mapping.
- [x] CRUD stores and returns credentialReference only; raw API keys are never persisted or returned.
- [x] REST, client, and STDIO/MCP surfaces expose list/get/upsert/delete/enable/disable/status/invoke parity.
- [x] Invocation is rejected unless brain-slot execution is enabled, the slot is enabled, endpoint policy passes, credentials resolve, and required turn transactions are enabled.
- [x] No implicit fallback model is used; fallback behavior remains fail-closed with structured reason codes unless a configured slot is invoked and committed.

## FR-MCP-130 Transaction-gated Curiosity external result admission

The CuriosityEngine slot MAY request GraphRAG or context admission for external model output only after the related brain-slot invocation transaction commits successfully through the subscriber path.
Scope: layer-1+
**Acceptance Criteria:**
- [x] No model output is returned to the caller until the subscriber commit succeeds.
- [x] If commit fails, times out, or degrades, output is discarded from the response and is not injected into cache or GraphRAG.
- [x] Only CuriosityEngine may request GraphRAG/context admission.
- [x] Left, Right, and Arbiter invocations may return committed results but never mutate cache or GraphRAG.
- [x] Curiosity admission records the committed transaction and admission metadata for audit.

## FR-MCP-131 Quad containment and authorization boundary

The MCP runtime SHALL keep Quad-Brain branches fail-closed unless explicit branch requirements authorize them. FR-MCP-134 and FR-MCP-135 now authorize AoT reconciliation execution, durable weight updates, and full Quad-Brain orchestration; unauthorized cache mutation and implicit fallback remain contained.
Scope: layer-1+
**Acceptance Criteria:**
- [x] AoT reconciliation execution is authorized only through the transaction-gated ArbiterOfTruth slot path.
- [x] Weight update execution is authorized only through the safety-gated, transaction-coordinated weight update path.
- [x] Full automatic quad orchestration is authorized only when the workspace is quad-ready and all role outputs commit successfully.
- [x] Individual brain-slot invocation authorization still does not authorize non-Curiosity GraphRAG/cache mutation or implicit fallback model behavior.

## FR-MCP-132 Accurate HTTP semantics for /mcpserver/* credential failures

All /mcpserver/* endpoints return 401 Unauthorized for unknown, stale, or missing API keys. 503 Service Unavailable is returned only when the per-workspace auth-token subsystem has not yet been initialized, and per-workspace tokens rotating on restart must surface as 401, never as a blanket 503.
Scope: layer-1+
**Acceptance Criteria:**
- [x] All /mcpserver/* endpoints return 401 Unauthorized for unknown, stale, or missing API key
- [x] 503 Service Unavailable returned only when per-workspace auth-token subsystem not initialized
- [x] Every 503 includes Retry-After header and JSON body
- [x] Rotated/stale API key surfaces as 401, never as blanket 503

## FR-MCP-133 Readiness reflects the workspace/token subsystem

The readiness endpoint /ready reports Unhealthy when no enabled workspace is registered, primary workspace has no seeded auth token, or auth-token subsystem is uninitialized. Readiness never reports Healthy while /mcpserver/* would be rejected with 503.
Scope: layer-1+
**Acceptance Criteria:**
- [x] /ready endpoint checks workspace/token subsystem readiness
- [x] /ready reports Unhealthy when no enabled workspace registered
- [x] /ready reports Unhealthy when primary workspace has no seeded auth token
- [x] /ready never reports Healthy while /mcpserver/* would return 503

## FR-MCP-134 Full Quad-Brain orchestration and AoT reconciliation

The MCP runtime SHALL execute the full four-role Quad-Brain decision loop when the workspace is quad-ready, including LeftHemisphere, RightHemisphere, CuriosityEngine, and ArbiterOfTruth invocation, transaction-gated AoT reconciliation, committed final output return, and fail-closed rejection when any required slot, transaction, endpoint, credential, or party gate is unavailable.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Orchestration rejects before provider calls unless all four roles have exactly one enabled, valid, trusted, transaction-ready slot.
- [x] LeftHemisphere, RightHemisphere, and CuriosityEngine outputs are collected through existing transaction-gated slot invocation before ArbiterOfTruth reconciliation runs.
- [x] AoT reconciliation returns the final committed decision only after subscriber commit; failed or degraded commits discard model output from the caller response.
- [x] No implicit fallback model is used; fallback remains explicit fail-closed unless a configured slot is invoked and committed.

## FR-MCP-135 Quad-Brain weight update controls

The MCP runtime SHALL support durable, audited Quad-Brain role weight updates with AoT approval, admin approval, explicit safety-gate acknowledgement, version checks, before/after snapshots, and rollback metadata, while rejecting unsafe or stale updates without mutating slot state.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Weight updates require AoT approval, admin approval, safety gates passed, and a non-empty reason before slot weights change.
- [x] Each accepted update increments slot weight versions and records previous and new values in DataAuditLogs.
- [x] Stale expected versions, missing roles, disabled slots, invalid weights, or missing approvals return structured fail-closed reason codes.
- [x] Full orchestration can apply an explicit approved weight update but never performs an implicit self-improvement update.

## FR-MCP-136 ACID-coupled Microsoft Agent Framework agent definition

The system SHALL expose an explicit ACID-compliant, tightly coupled hosted-agent definition for Microsoft Agent Framework hosts, extending the existing ChatClientAgent integration while requiring authenticated workspace binding, serialized tool invocation, durable audit/session-log boundaries, and fail-closed tool exposure.
Scope: layer-1+
**Acceptance Criteria:**
- [x] The ACID profile has stable public metadata including id, name, source type, consistency model, coupling mode, and Microsoft Agent Framework extension type.
- [x] The ACID profile requires authentication, workspace scoping, session-turn boundaries, durable audit, transaction-required mutation policy, and serialized model tool invocation.
- [x] Generic passthrough, shell, desktop, repository-write, TODO-mutation, and GraphRAG-mutation tools are not exposed by default in the ACID profile.
- [x] Default hosted-agent registration remains backward compatible when the ACID profile is not selected.

## FR-MCP-137 Quad Brain coding agent execution

RETIRED 2026-07-20 by FR-MCP-142 and TR-MCP-QB-001. This requirement specified a hosted coding agent that reached QuadBrain orchestration through the mcp_quadbrain_coding_execute tool in the shared McpServer.McpAgent catalog. That tool is removed, because it advertised a QuadBrain capability to every hosted-agent host rather than to QBAgent alone, and it was already non-functional for QBAgent: QuadBrainInternalToolExecutor never had a case for it, so the interceptor classified it internal and returned Fail. Retired alongside TR-MCP-AGENT-016 and TEST-MCP-187. Replacement coverage is the absence suite under TEST-MCP-193. QuadBrain coding work continues server-side through POST /v1/chat/completions, the OpenAI-compatible endpoint QBAgent binds to with model id QuadBrain; that path is unchanged and separately covered. Corrected 2026-07-20 after an audit found this FR still describing removed behavior when its TR and TEST had already been retired.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Hosted agent exposes model-visible mcp_quadbrain_coding_execute tool
- [x] Tool calls McpServerClient.BrainSlots.OrchestrateAsync with coding metadata
- [x] Tool never bypasses Quad Brain transaction/admission contract
- [x] ACID profile includes Quad Brain coding tool while excluding generic passthrough, shell, write, desktop, todo, and graphrag mutation tools
- [x] Host code can execute same coding-agent path through typed runtime method

## FR-MCP-138 AiCodeReview and AiProjectReview Nuke targets trigger aiUnit via library

AiCodeReview and AiProjectReview Nuke targets SHALL integrate directly with the aiUnit Frontier library to trigger the AI review (code or project reviewType) from inside the target execution. This replaces any reliance on externally pre-run AI sessions or static artifacts.

**Acceptance Criteria:**
- Execute `dotnet build` of the _build project succeeds with the integration.
- Invoking the target (e.g. ./build.ps1 AiCodeReview) results in real SendAsync call to a Frontier client resolved from config.
- Produces a fresh aiunit.review.runlog.v1 JSON under artifacts/aiunit-code-review/ (and project equivalent).
- Produces a matching combined MD under docs/reviews/ containing the prompt and the findings JSON.
- Configuration loaded from appsettings.aiunit.json (falling back to the one in PlanReview.Tests) + env vars; uses ActiveStrategy (e.g. claude CLI).
- The targets do not depend on or execute unit test filters for review triggering (review is distinct from `Test`).
- Build tests cover client creation and markdown writing with mocks/stubs.
- All prior tests + new remain green (Byrd gate).
Scope: layer-1+

## FR-MCP-139 Warning suppression governance

The MCP Server workspace must maintain durable governance for warning suppression decisions, approved exceptions, required code fixes, validation evidence, and traceability across TODO and requirements artifacts.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Approved warning suppressions are recorded with diagnostic code, justification, owner, permanence, and review condition. (evidence: config/warning-suppression-approvals.json records current approved CA1416, CA1819, and CA2227 suppressions with owner, permanence, and review condition.)
- [ ] Unapproved diagnostics and broad warning bypasses remain remediation work until code, configuration, package metadata, or dependency changes remove the warning source. (evidence: REOPENED 2026-09-09T17:07:12Z: generated migration CS0612/CS0618 pragmas recurred (W18 open). Historical evidence retained. .editorconfig CA1848 severity override removed; CA1848 and CS8602 approval entries removed; CS8602 pragmas removed; Storage migration obsolete pragmas removed.)
- [ ] PLAN-WARNREMEDIATION-001 stays current with approved suppressions separated from required fixes and marks only validated work as done. (evidence: REOPENED 2026-09-09T17:07:12Z: PLAN-WARNREMEDIATION-001 W18 is Done=false. Historical evidence retained. PLAN-WARNREMEDIATION-001 W15/W18/W21-W24 evidence updated in TODO state; approved suppressions remain in config/warning-suppression-approvals.json.)
- [x] Requirements exports and traceability mappings include the suppression governance FR, TR, and aiUnit TEST records. (evidence: docs/Project/Functional-Requirements.md, docs/Project/Technical-Requirements.md, docs/Project/Testing-Requirements.md, docs/Project/TR-per-FR-Mapping.md, docs/Project/Requirements-Matrix.md, docs/Project/requirements-wiki-documents.zip)
- [ ] Generated provider migration designers and snapshots may not retain exact CS0612/CS0618 suppression pairs after scaffolding. Correction uses an explicit opt-in Nuke normalizer. Read-only validation must fail when those exact pragma pairs reappear. Do not create a parallel requirement family.

## FR-MCP-140 Self-describing marker signature canonicalization

The generated AGENTS-README-FIRST.yaml marker file shall embed the complete marker-v1 canonical field list and encoding contract inside the signature block so that any agent can reconstruct and verify the HMAC-SHA256 signature without consulting server source code, documentation, or a helper module. Recovered from origin/claude/dreamy-brahmagupta (commit ccda0a4e, 2026-04-09) where it was authored as FR-MCP-081; that id has since been reused on develop for Byrd Iteration Phase and TODO Execution Persistence, so this work is renumbered. Extends FR-MCP-076 (marker trust bootstrap) and TR-MCP-SEC-003 (signed marker bootstrap), neither of which states that the payload field list is emitted or that it is table-driven. Motivation: the marker-v1 field order is currently hand-reimplemented in at least six independent verifiers (McpSession.psm1, plugins lib-ps and lib-sh marker resolvers, the lib-node and mcp-repl-ts TypeScript resolvers, mcpserver-agent-core marker-trust.ts, MarkerFileClientOptionsResolver.cs) plus a prose spec in REPL-AGENT-GUIDE.md, with no test binding them together; a missed update makes a verifier compute a different HMAC and log MCP_UNTRUSTED.
Scope: layer-1+

## FR-MCP-141 Service-account process environment fidelity

When the server runs as a Windows service under a non-interactive account, child processes it launches shall resolve executables and environment the same way an interactive user session would. Executable resolution shall skip Microsoft\WindowsApps App-Execution-Alias stubs, which are zero-byte reparse points that fail with Win32Exception 1920 for service accounts. Tunnel providers shall apply the interactive user's USERPROFILE, HOME, APPDATA, and PATH to the child process so provider configuration files resolve, and shall resolve the provider binary against that enriched PATH. A missing provider binary shall be reported at Warning with a message naming the service-account and Store-alias causes and the available remedies, not as an unexplained error. Recovered from origin/claude/busy-dubinsky (2026-04-04 to 2026-04-05), which registered no requirement of any kind.
Scope: layer-1+

## FR-MCP-142 QuadBrain is absent from every general agent surface

No QuadBrain capability shall be exposed to general agents or to the agent plugins in any form. Absent, not gated: no brain-slot tool descriptors in the shared plugin cores, none advertised over the server MCP transports, no named client-passthrough route reaching BrainSlotClient, no QuadBrain-named tool in the shared hosted-agent catalog, and no brain-slot descriptor files in the shared mcps registry. QuadBrain remains reachable only as the OpenAI-compatible model at POST /v1/chat/completions, workspace-token authorized, which is the sole path QBAgent uses. Everything behind that endpoint stays server-side: QuadBrainOpenAiController, QuadBrainOpenAiChatService, QuadBrainOrchestrationService, the BrainSlot registry, invocation, credential, chat-client-factory and startup-seeder services, the BrainSlot storage entities and migrations, the QuadBrain tool interceptor, and config/brain-slots/quad-brain-slot-assignments.yaml. Evidence that motivated this requirement: the ClaudeCode session of 2026-07-20 could enumerate all eleven brain_slot tools from a general agent tool list, and plugins/core/lib-node/src/runtime/host-context.ts spread brainSlotTools into the ungated allToolDescriptors catalog advertised to every Node host plugin.
Scope: layer-1+

## FR-MCP-143 Session-log turns persist without a title and never lose a refined one

A session-log turn shall persist end to end when its title is deliberately omitted, and a title the agent has refined shall never be overwritten by a stale local copy. Thirteen open triage reports (BUG-TRIAGE-086 through 101, excluding the already-closed 097) collapse into five root causes, of which two account for eleven of the reports. First, the plugin PowerShell core rejects an empty title at parameter binding even though TR-MCP-REPL-015 requires callers to omit the title so a stale cached one is not resubmitted, so appendDialog, appendActions, completeTurn and the supersede path all fail. Second, the typed client posts anonymous request bodies through a source-generated JSON context that has no metadata for compiler-generated types, so the dedicated retitle endpoints throw before reaching the server. The remaining three are the supersede path clobbering a server-refined title from the local cache, failTurn refusing to close a turn the plugin cache shows as active, and a storage outage leaving health reporting Healthy while every persistence call fails behind inconsistent error shapes.
Scope: layer-1+

## FR-MCP-170 Incremental session-log dialog persist

Plugin workflow.sessionlog.appendDialog SHALL persist dialog items through SessionLogClient.AppendDialogAsync (POST /mcpserver/sessionlog/{agent}/{sessionId}/{requestId}/dialog) without a full-session SubmitAsync upsert when the turn already exists.

Acceptance Criteria:
- After a successful beginTurn, appendDialog returns success while TODO/requirements queries succeed in the same process.
- Server turn GET then contains the appended dialog items.
- Test double or recorded call: method is AppendDialogAsync or POST dialog, not SubmitAsync of the full session DTO.
- A missing turn on a never-degraded appendDialog path is classified not-found, retryable false; no failsafe is created for that 404. This does not override degraded MCP/service recovery and failsafe retention governed by FR-MCP-SESSIONLIFE-001-AC004.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] After a successful beginTurn, appendDialog persists valid dialog items and exact server readback shows the appended items while TODO and requirements operations remain usable in the same process.
- [ ] The incremental dialog path invokes SessionLogClient.AppendDialogAsync or the dialog POST and does not submit the complete session DTO through SubmitAsync.
- [ ] On a never-degraded appendDialog path, a missing turn is classified not_found with retryable false, does not create a failsafe for that 404, and does not increment the local auditDialog count; this criterion does not override degraded MCP/service recovery and failsafe retention governed by FR-MCP-SESSIONLIFE-001-AC004.
- [ ] A classified storage failure leaves local auditDialog unchanged; a later successful complete reconciles the local counter to the exact persisted server turn.

## FR-MCP-171 Retryable session-log persist degrade-queue

When client.SessionLog.SubmitAsync (beginTurn, updateTurn, completeTurn, or legacy upsert) returns timeout, HTTP 503, or backend_unavailable, the plugin SHALL retain the session_submit failsafe, keep current-turn.yaml in_progress, SHALL NOT throw, and SHALL report degraded/queued using the same contract as the existing timeout path.

Acceptance Criteria:
- HTTP 503 backend_unavailable and timeout produce the same degrade-queue contract (persisted false, degraded true, queued true, failsafe retained).
- Failsafe file remains until a later successful persist or drain replay.
- After storage recovers, query shows the turn.
Scope: layer-1+

## FR-MCP-172 Failsafe drain does not poison successful plugin calls

A successful workflow.requirements.getFr, getTr, or sessionlog queryHistory SHALL NOT be delayed by a 30s SessionLog.SubmitAsync drain timeout, SHALL NOT print Failsafe queue drain failed for timeout or HTTP 503, SHALL NOT latch drain completed, and a later drain after storage answers SHALL replay the queued record.

Acceptance Criteria:
- getFr EXIT 0 with the FR body when a queued session_submit times out or returns 503.
- stderr has no Failsafe queue drain failed for that class.
- ReplFailsafeDrainCompleted stays false on abort.
- Next drain in-process replays after a stubbed success.
Scope: layer-1+
**Acceptance Criteria:**
- [x] getFr EXIT 0 with the FR body when a queued session_submit times out or returns 503. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] stderr has no Failsafe queue drain failed for that class. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] ReplFailsafeDrainCompleted stays false on abort. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Next drain in-process replays after a stubbed success. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-MCP-173 Keyserver signs QuadBrain transactions only

Keyserver manifest signing SHALL be used only for QuadBrain transactions: publisher party id prefix brain-slot:, or operation name prefix brain-slot. or quadbrain. All other first-party mutations (TODO, requirements, session-log for every source type including QBAgent, memory, repo, prompt templates, tool registry, GitHub, GraphRAG, voice, agent pool, issue-todo-sync, tool buckets, REPL TODO workflow, requirements ingest, context rebuild, and federation apply/control) SHALL persist without calling ITurnTransactionCoordinator or the keyserver even when Mcp:TurnTransactions:Enabled=true and RequiredForMutations=true. Do not disable the live TurnTransactions flag as the fix. QuadBrain brain-slot.invoke and brain-slot.weight-update remain coordinator-gated and may call keyserver.

Acceptance Criteria:
- ac-1: With TurnTransactions.Enabled=true and RequiredForMutations=true, general-agent mutations (todo.update, requirements.fr.update, sessionlog.submit for GrokCode and QBAgent, memory.add, repo.write, github.cli) do not invoke ITurnTransactionCoordinator.ExecuteAsync and still succeed.
- ac-2: brain-slot.invoke and brain-slot.weight-update still invoke the coordinator and may call SignManifestAsync.
- ac-3: Coordinator degraded state does not block general-agent first-party mutations.
- ac-4: Live TurnTransactions.Enabled remains true for QuadBrain; the repo default may stay false.
- ac-5: Focused TransactionGated* tests plus TurnTransactionCoordinatorTests, TurnTransactionKeyserverScopeTests, and BrainSlotInvocationTransactionTests complete with zero failures and zero skips.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] With TurnTransactions.Enabled=true and RequiredForMutations=true, general-agent mutations (todo.update, requirements.fr.update, sessionlog.submit for GrokCode and QBAgent, memory.add, repo.write, github.cli) do not invoke ITurnTransactionCoordinator.ExecuteAsync and still succeed.
- [ ] brain-slot.invoke and brain-slot.weight-update still invoke the coordinator and may call SignManifestAsync.
- [ ] Coordinator degraded state does not block general-agent first-party mutations.
- [ ] Live TurnTransactions.Enabled remains true for QuadBrain; the repo default may stay false.
- [ ] Focused TransactionGated* tests plus TurnTransactionCoordinatorTests, TurnTransactionKeyserverScopeTests, and BrainSlotInvocationTransactionTests complete with zero failures and zero skips.

## FR-MCP-AGENT-PARITY-001 FR-MCP-AGENT-PARITY-001

Legacy agent-parity functional TODO link retained for historical traceability. Status: superseded by concrete plugin/core parity requirements and matrix rows; no active implementation work is tracked under this stub.
Scope: layer-1+

## FR-MCP-AGENT-PARITY-002 FR-MCP-AGENT-PARITY-002

Legacy agent-parity functional TODO link retained for historical traceability. Status: superseded by concrete plugin/core parity requirements and matrix rows; no active implementation work is tracked under this stub.
Scope: layer-1+

## FR-MCP-AUDIT-001 Permanent local audit history

Audit rows for mutable MCP state remain permanent in the local database and are excluded from federation and wiki exports. Runtime storage preserves legacy audit reads and stores new generic payloads compactly.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Audit rows are omitted from federation payloads and wiki exports while local audit version checks remain usable.
- [ ] The SQL Server runtime principal can insert audit rows but cannot update or delete either audit ledger or write migration history.
- [ ] Legacy JSON rows remain readable; new generic audit rows persist all four snapshot, diff, and metadata payloads with versioned compression.
- [ ] SQLite, SQL Server, and PostgreSQL provider migrations apply and round-trip audit payloads without rewriting historical text.

## FR-MCP-BATCH-001 Plugin requirement batch payload parsing

All MCP server plugins SHALL accept valid YAML and JSON records arrays for requirement batch operations without schema-validation rejection.
Scope: layer-1+

## FR-MCP-CLEARSESSION-001 Shared clear-session reset skill for all agent plugins

All MCP Server agent plugins SHALL provide a shared `clear-session` skill that resets the agent to a ready state in five ordered steps: (1) end the current MCP session, (2) clear agent context (best-effort programmatic, else instruct the per-host manual clear command and pause), (3) reload the agent instruction file selected by host (CLAUDE.md for Claude hosts, AGENTS.md otherwise), (4) execute the add-profile skill, and (5) report ready.
Scope: layer-1+

## FR-MCP-DOCFXWIKI-001 Optional DocFX content in requirements wiki exports

A workspace may declare one or more DocFX workflows whose generated content is included in GitHub and Azure requirements wiki artifacts without changing existing exports when no workflow is configured.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] docs/wiki.yaml may omit docfx entirely and produce byte-equivalent requirements wiki behavior apart from generated timestamps.
- [ ] Each configured workflow builds DocFX once and maps its generated files into the selected GitHub and Azure wiki roots.
- [ ] Platform filters include content only in the requested github and/or azure outputs.
- [ ] Generated DocFX files appear in platform manifests and stale generated files are removed on the next successful export.
- [ ] Workspace traversal, absolute external paths, and reparse-point escapes are rejected before command execution or file copy.
- [ ] Invalid configuration, process timeout, non-zero exit, or missing output fails the export without publishing a partial wiki artifact.

## FR-MCP-FAILSAFE-001 Failsafe drain treats 503 backend_unavailable as backend-down and can retry

Session-log persist that hits the storage budget or a transient provider fault stays retryable HTTP 503 backend_unavailable with failsafe on disk. Drain aborts without incrementing drainAttempts or quarantining. After storage answers, a later drain in the same process can replay. BUG-TRIAGE-159.
- [ ] Submit/append still returns retryable backend_unavailable and keeps failsafe YAML
- [ ] Test-ReplFailsafeBackendUnreachable treats HTTP 503 and code backend_unavailable as unreachable
- [ ] Drain does not latch failed=1 as permanently completed in-process
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Submit/append still returns retryable backend_unavailable and keeps failsafe YAML
- [ ] Test-ReplFailsafeBackendUnreachable treats HTTP 503 and code backend_unavailable as unreachable
- [ ] Drain does not latch failed=1 as permanently completed in-process

## FR-MCP-FED-BACKFILL-001 LocalProxy backfills existing workspace data to the hub after enrollment

After enrollment a LocalProxy must copy all existing workspace-scoped data for each enrolled workspace to the hub, idempotently, preserving ids, versions, timestamps and history where the domain supports it, using batched signed envelopes (decision D2). AC1: Domains todo (items, tasks, list items, requirement links, document metadata, audit history), session_log (full graph), requirements (acceptance criteria, traceability, scope layers), memory (+versions), use cases, documents/chunks, triage, tools buckets/definitions, agents, brain slots, handoff runs, actors are each backfilled or explicitly listed as local-only with a reason. AC2: Re-running creates no duplicates and reports already_applied counts. AC3: Backfill operations do not fan out to other proxies. AC4: federation/status reports backfill state per workspace and domain; staleReadStatus is non-clear until complete; while a workspace is incomplete the proxy serves its reads locally and forwards writes (decision D4). AC5: Per-domain per-workspace row-count and checksum parity report after completion. Evidence 2026-10-06: ~1.885M proxy rows vs 1,650 hub rows for the enrolled proxy's workspaces.
Scope: layer-1+

## FR-MCP-FED-PATH-001 Syntax-based interpretation of request-supplied workspace paths

A server must interpret any request-supplied workspace path by its own syntax (drive letter, UNC, POSIX root), never by the host OS, so a Linux host accepts and stores Windows paths unchanged in meaning and a Windows host accepts POSIX paths. AC1: On a Linux host, C:\Users\kingd and C:/Users/kingd resolve to the same Windows identity and nothing is prefixed with the process working directory. AC2: On a Windows host, /home/x stays a POSIX path. AC3: Triage submit/getReport/queryGroups round-trip on a Linux hub using the submitter's original Windows path. AC4: WorkspaceService.Init never creates a directory from a foreign-platform path. Evidence: TriageService.cs:1417 Path.GetFullPath produced /opt/mcpserver/app/C:\Users\kingd on hub LAB-OMARCHY (2026-10-06). Plan: docs/plans/2026-10-07-federation-fixes.md (P1).
Scope: layer-1+

## FR-MCP-FED-ROUTE-001 Hub resolves forwarded requests to the proxy workspace and fails closed

The federation hub must resolve a request forwarded by a LocalProxy to that proxy workspace's canonical row using (X-Mcp-Proxy-Id, proxy-local workspace path) or the GlobalWorkspaceId. AC1: Forwarded GET /todo with X-Workspace-Path F:\GitHub\McpServer from PAYTON-LEGION2 returns that workspace's data (200), never 400 and never the hub primary workspace. AC2: X-Workspace-Path set to the GlobalWorkspaceId resolves to the same workspace. AC3: A request carrying X-Mcp-Federation-Hop without a resolvable workspace fails closed with a 4xx diagnostic and never falls back to the API key's default workspace. AC4: The LocalProxy forwards the hub GlobalWorkspaceId (not its local path) in X-Mcp-Global-Workspace-Id. AC5: The inter-server hub token can only address workspaces registered to the presenting proxy. Evidence 2026-10-07 hub probe: no header -> 200 hub McpServer TODOs (58); proxy path, hash id and forwarded headers -> 400 Unknown workspace path.
Scope: layer-1+

## FR-MCP-FED-WSSYNC-001 Proxy workspace configuration propagates to hub canonical rows

Proxy-owned workspace configuration (Name, IsEnabled, TodoPath, RunAs, AgentPath, PromptTemplate, StatusPrompt, ImplementPrompt, PlanPrompt, IsPrimary, DataDirectory, TunnelProvider) must propagate to the hub canonical Workspaces row on enroll and heartbeat. Hub-maintained state (CurrentRequirementLayerKey) is hub-owned (decision D3): never overwritten by heartbeats, drift reported. AC1: After enroll, every proxy-owned field on every canonical row equals the proxy row (lab repro 55/55). AC2: A TodoPath change on the proxy is visible on the hub after the next heartbeat. AC3: GET federation/workspaces exposes a drift indicator for hub-owned fields that differ from the proxy. AC4: Older proxies that send no configuration fields keep current behaviour. Evidence 2026-10-06: 1 TodoPath and 8 CurrentRequirementLayerKey mismatches of 55; EnsureFederatedWorkspaceRow hard-codes TodoPath docs/todo.yaml.
Scope: layer-1+

## FR-MCP-FILETOOLS-001 Global repository discovery tools

Every MCP transport, hosted agent, and QBAgent surface must expose read_file, list_dir, and grep_files through one server-owned repository discovery implementation.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] HTTP and stdio MCP tools/list expose read_file, list_dir, and grep_files with the documented schemas.
- [ ] Generic hosted agents and QBAgent expose the same read-only capabilities without duplicate tool names.
- [ ] Existing repository read, list, write, and edit contracts remain compatible.

## FR-MCP-HELP-001 Agent Help conversation API

Agents stuck on MCP Server surfaces can open help sessions, submit turns, query status, retrieve transcripts, and stream responses over HTTP.
Scope: layer-1+

## FR-MCP-HELP-002 Inbound guardrails

Inbound user messages are evaluated by deterministic guard rules before helper execution; violations terminate the session.
Scope: layer-1+

## FR-MCP-HELP-003 Transcript persistence

Help turns are captured as append-only JSONL under the workspace data root.
Scope: layer-1+

## FR-MCP-HELP-004 Guard incident logging

Blocked inbound messages produce durable incident records for operator review.
Scope: layer-1+

## FR-MCP-HELP-005 Corpus bootstrap and outcome analysis

Sessions optionally bootstrap a stub context pack; completed sessions can be analyzed for triage and documentation follow-ups.
Scope: layer-1+

## FR-MCP-HELP-006 MCP STDIO tool parity

STDIO MCP exposes agent_help_create_session, agent_help_submit_turn, and agent_help_get_status mirroring the HTTP controller.
Scope: layer-1+

## FR-MCP-HELP-007 Typed client library

SharpNinja.McpServer.Client exposes AgentHelpClient on McpServerClient for session create, turn submit, status, and transcript retrieval.
Scope: layer-1+

## FR-MCP-HELP-008 Marker prompt guidance

Generated markers instruct agents when and how to invoke Agent Help for MCP Server issues.
Scope: layer-1+

## FR-MCP-HELP-009 REPL workflow parity

The REPL exposes workflow.agenthelp typed wrappers with the same contracts as REST and MCP tools.
Scope: layer-1+

## FR-MCP-HELP-010 Agent Help configuration

AgentHelp options control enablement, guard behavior, storage paths, execution strategy, and helper model defaults.
Scope: layer-1+

## FR-MCP-HELP-011 Agent Help grok-cli execution strategy and default

Agent Help SHALL provide a Grok CLI execution strategy named grok-cli (with grok-build accepted as an alias) and SHALL use grok-cli as the default execution strategy when a caller does not specify one.
Scope: layer-1+

## FR-MCP-HOSTILEREVIEW-001 Enqueue bounded hostile review request

An authenticated agent can enqueue a bounded hostile review request scoped to the active workspace. The request includes target type, mode, scope statement, artifact links, requester identity, workspace identity, and optional acceptance criteria. Oversized payloads are rejected with no queue row. Foreign workspace is 403.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Request includes target type, mode, scope statement, artifact links, requester identity, workspace identity, optional AC list. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Serialized request JSON greater than 1048576 bytes is rejected with no queue row. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Authenticated workspace scope: foreign workspace is 403 and no queue row. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Valid request creates a QueueItem with stable id and status queued. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)

## FR-MCP-HOSTILEREVIEW-002 Artifact links resolve through MCP APIs

Artifact links resolve only through supported MCP APIs (TODO, FR/TR/TEST, session log, triage, plans, files, commits, generated docs). Missing, unauthorized, stale, or ambiguous links produce diagnostics, not silent omission.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Missing link produces a diagnostic, not silent omit. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Unauthorized or stale or ambiguous link produces a diagnostic, not silent omit. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Successful resolve stores the resolved artifact identity and hash when available. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Authorize each artifact at submit and reauthorize it at every dispatch. Resolve only through supported workspace-scoped services. Store only normalized identity, type, version/hash, and sanitized diagnostic metadata. Permit no raw artifact or assembled prompt in queue rows, notifications, logs, receipts, or result metadata. Reject more than 64 links, an artifact over 1 MiB decoded, aggregate resolved input over 8 MiB, or unsupported/binary content that cannot be inspected safely. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)

## FR-MCP-HOSTILEREVIEW-003 Reviewer run records model effort identity

Each reviewer execution records model, effort, agent identity, plugin/source, prompt template/version, run id, timestamps, and token/runtime metadata when available. Missing metadata is omitted with a diagnostic, never fabricated.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Execution row records model string, effort level, agent identity, plugin/source surface. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Execution row records prompt template id and version, run id, start/end UTC. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Token/runtime metadata stored when provided; omitted with diagnostic when not provided, not fabricated. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] A server-owned worker uses the existing agent infrastructure with effective model gpt-6-astra and effort xhigh. Queue state is durable. Request, attempt, pool-job, model-execution, and accepted-terminal-result identities are distinct. Model execution is bounded at-least-once across process loss. Lease loss, repeated model execution, or duplicate completion cannot produce more than one accepted terminal result. Cancellation is internal to host/workspace lifecycle handling and existing authorized AgentPool cancellation, never a public hostile-review mutation. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)

## FR-MCP-HOSTILEREVIEW-004 Normalized findings and request quality

Normalized findings distinguish defects, risks, missing tests, unclear requirements, insufficient disclosure, out-of-scope, and uncertainty. Verdicts are AGREE, DISAGREE, or UNKNOWN. Request-quality scores disclosure, scope clarity, objective clarity, confidence, and enough-context.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Findings distinguish defects, risks, missing tests, unclear requirements, insufficient disclosure, out-of-scope, uncertainty. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Verdicts are AGREE, DISAGREE, or UNKNOWN only. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Request-quality scores disclosure, scope clarity, objective clarity, confidence, enough-context as explicit fields. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)

## FR-MCP-HOSTILEREVIEW-005 Query failure modes by dimensions

Query reports filter by workspace, model, effort, requesting agent, reviewer agent, target type, artifact type, severity, and category. Combined filters AND. Empty match is empty list.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Query with each dimension returns only matching runs. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Combined filters AND. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] Empty match is empty list, not error. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)

## FR-MCP-HOSTILEREVIEW-006 Default queue-and-record no auto mutation

Default behavior is queue-and-record. Completing a review does not edit product files, requirements, or TODOs. Surfaces expose submit/status/get/query only.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Completing a review does not edit product files, requirements, or TODOs. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] REST, REPL, Director, plugin skill expose submit/status/get/query only. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] No hidden repair/apply endpoint is registered in this TODO. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)
- [x] status, get, and query are read-only. submit is the only public mutation. No cancel, repair, apply, file edit, TODO edit, or requirement edit behavior is hidden in any read operation. (evidence: tests/McpServer.Support.Mcp.Tests/Services/HostileReviewG4OverlayTests.cs; overlay G4 rereview SHA-256 BFD7029944F1EAAC99F2808EA47146DBBD7C87EEB3E02AB4ADC31F95D3F0DFD1)

## FR-MCP-HYGIENE-001 Read-only workspace validation service

A read-only workspace validation service uses a versioned rule registry and a shared result contract with rule code/version, severity, entity kind, workspace identity, record IDs, evidence, remediation, run timestamp, duration, and summary counts.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Result contract has rule code/version, severity, entity kind, workspace identity, record IDs, evidence, remediation, run timestamp, duration, summary counts. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Clean workspace produces zero findings. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Registry is versioned; unknown rule code is not silently skipped. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)

## FR-MCP-HYGIENE-002 Traceability and missing-AC rules

Rules identify FR/TR/TEST with no AC rows, TR with no FR, FR lacking TR/TEST, TEST with no FR, and broken or duplicate mappings.
Scope: layer-1+
**Acceptance Criteria:**
- [x] FR/TR (and TEST unless excluded by a documented rule) with no AC rows is a finding with record id and evidence. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] TR mapped to no FR is a finding. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] FR lacking required TR or TEST coverage is a finding. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] TEST mapped to no FR is a finding. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Broken or duplicate mappings are findings. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)

## FR-MCP-HYGIENE-003 TODO consistency rules

Rules identify done=true with incomplete tasks, done=false with all tasks complete, completion without doneSummary, remaining vs completion contradiction, missing dependency targets, and missing referenced requirement IDs.
Scope: layer-1+
**Acceptance Criteria:**
- [x] done=true with any incomplete implementation task is a finding. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] done=false with all implementation tasks complete is a finding. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] done=true without doneSummary is a finding. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] remaining text that contradicts completion is a finding. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] missing dependency target ids are findings. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] missing referenced requirement IDs are findings. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)

## FR-MCP-HYGIENE-004 Stale turns and non-terminal triage

Turns in_progress more than 48h after authoritative timestamp (injectable UTC clock) are findings. Triage reports in live non-terminal states are findings. Override threshold is positive, at most 168h, authenticated, recorded.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Turns in_progress more than 48h after the authoritative timestamp (injectable UTC clock) are findings. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Triage reports in live non-terminal states from the domain model are findings; processing failure is distinct from pending. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Threshold override must be positive, at most 168h, authenticated, and recorded on the run. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Unauthenticated validate is rejected. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Cancellation is honored. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Large workspaces paginate rather than unbounded load. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)

## FR-MCP-HYGIENE-005 Surface parity and no auto-repair

REST, Director, REPL, and plugin skill expose the same validation. Same rule codes, identities, severities, counts, and threshold. Never auto-repair. Director exit 1 on Error or Critical; exit 0 when empty or Warning-only.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Authenticated REST, Director command, REPL command, and plugin skill expose the same validation. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Parity: same rule codes, identities, severities, counts, and threshold. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Validation never auto-repairs or deletes records. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Director exit 1 when any finding has severity Error or Critical. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)
- [x] Director exit 0 when findings are empty or Warning-only; JSON is always written. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WorkspaceHygieneG5OverlayTests.cs; G5 TRX SHA-256 7B3EA931BEDAE3D8D69A260BA9EAB516EDF8337BCF742712E4B4036DC30B7D16 Passed 25 Failed 0 Skipped 0)

## FR-MCP-LIVE-CODEX-20260603T2014Z Live Codex plugin acceptanceCriteria verification

Temporary live verification for plugin acceptanceCriteria rollout.
Scope: layer-1+

## FR-MCP-LIVE-CODEX-20260603T2015Z Live Codex plugin acceptanceCriteria verification

Temporary live verification for plugin acceptanceCriteria rollout.
Scope: layer-1+

## FR-MCP-LLMSTRATEGY-001 Per-role QuadBrain LLM completion strategy

Each QuadBrain role (Creativity, Logic, CuriosityEngine, ArbiterOfTruth) SHALL complete through a provider strategy chosen per role. The orchestration-to-strategy seam SHALL be richer than CompleteAsync(slot, input, temperature) returning string. A turn SHALL pass shared orchestration context by object reference including original input, committed role evidence, session id, turn id, and transaction id. HTTP strategies MAY flatten that context to chat messages. QuadBrain SHALL NOT merge a third-party agent or tool stack to satisfy this requirement.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Two different QuadBrain roles in one process can resolve two different provider strategies. (evidence: tests/McpServer.Support.Mcp.Tests/Services/BrainSlotLlmStrategyTests.cs CreateStrategy_TwoRoles_ResolvesTwoDifferentStrategyTypes)
- [x] A strategy implementation receives the shared turn-context object by reference (same original input, role evidence, session/turn/transaction ids). (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainLiveOrchestrationTests.cs ExecuteFullOrchestrationAsync_WithRealServicesAndFakeBrains_CommitsArbiterDecision Assert.Same; BrainSlotInvocationTransactionTests InvokeAsync_WhenTurnContextSupplied_PassesSameInstanceToStrategy)
- [x] An HTTP-strategy path serializes that context into chat messages rather than dropping it, and no new third-party agent SDK is required to complete a turn. (evidence: BrainSlotLlmStrategyTests BuildOpenAiCompatibleRequestJson_WhenTurnContextSupplied_IncludesOriginalInputAndTurnIds; Factory_CreateStrategy_ExistsWithoutNewAgentSdk)

## FR-MCP-MARKER-004 Marker removal deletes the marker and leaves no tombstone

Removing the AGENTS-README-FIRST.yaml workspace marker must delete the file. It must not rename the marker to an AGENTS-README-FIRST.yaml.deleted-{timestamp} archive copy that is never reclaimed. The marker is regenerated in full on every server start and carries the per-workspace API key that rotates on each restart, so an archived copy preserves no recoverable state of value while leaving an expired credential on disk. Each graceful shutdown currently leaves one tombstone permanently: as of 2026-07-20 the McpServer workspace held 19 of them, 587,033 bytes, dated 2026-07-08 through 2026-07-16, every one containing the apiKey that was live when it was written. TR-MCP-DB-003 (soft deletes for persistent MCP data) governs persistent MCP domain rows and their relationships; it does not extend to regenerated filesystem artifacts, and applying it to the marker was an over-generalization. The same rule applies to the legacy .mcp-server.yaml and .mcp-server.json markers removed alongside it.
Scope: layer-1+

## FR-MCP-MEMORY-001 Global and workspace memory storage

The MCP Server SHALL store raw-text memories with a stable memory ID, explicit scope, and exact text round-trip semantics. Supported scopes are Global and Workspace. Global memories are visible to every workspace, while Workspace memories are visible only to their owning workspace.
Scope: layer-1+
**Acceptance Criteria:**
- [x] A memory record has a stable ID, scope, category, raw text, version, author metadata, and created/updated timestamps.
- [x] Global memories are returned for every workspace and are not stamped with a workspace owner.
- [x] Workspace memories require an owning workspace and are not returned for any other workspace.
- [x] Removed memories are hidden from normal reads and lists without physically deleting the row.
- [x] Memory text round-trips exactly, including internal newlines and punctuation.

## FR-MCP-MEMORY-002 Memory CRUD tools

The MCP Server SHALL expose add, list, update, and remove operations for raw-text memories through REST, typed client, MCP stdio, and REPL workflow surfaces.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Add creates a memory and returns ID, text, scope, category, version, and timestamps.
- [x] List returns the effective memory set for the active workspace by default.
- [x] Update replaces raw text, increments version, and can change scope under validated rules.
- [x] Remove soft-deletes a memory by ID.
- [x] Invalid IDs, duplicate active IDs, invalid scopes, empty text, and unauthorized scope changes return clear errors.

## FR-MCP-MEMORY-003 Required memories injection format

Supported agents SHALL receive active memories at each host-supported request boundary in a deterministic `REQUIRED MEMORIES` block. Memory text SHALL be raw text and SHALL NOT be summarized, decorated, or rewritten.
Scope: layer-1+
**Acceptance Criteria:**
- [x] The injected block header is exactly `REQUIRED MEMORIES`.
- [x] Each memory renders as `- MEMORY-CATEGORY-001: Raw memory text`.
- [x] An empty memory set renders exactly `REQUIRED MEMORIES` followed by `- None`.
- [x] Scope labels, timestamps, source metadata, confidence, and summaries do not appear in the injected block.
- [x] Hosts without request-boundary injection document the limitation and expose the best available explicit memory-list fallback without claiming automatic injection.

## FR-MCP-MEMORY-004 Marker template memory guidance

Generated `AGENTS-README-FIRST.yaml` instructions SHALL explain MCP memories, the memory tools, the ID format, scope behavior, and the exact `REQUIRED MEMORIES` rendering contract.
Scope: layer-1+
**Acceptance Criteria:**
- [x] templates/prompt-templates.yaml contains an MCP Memories section in the default marker prompt. (evidence: templates/prompt-templates.yaml MCP Memories section.)
- [x] The section names memory_add, memory_list, memory_update, and memory_remove. (evidence: templates/prompt-templates.yaml MCP Memories tool list.)
- [x] The section documents Global versus Workspace scope and the MEMORY-{CATEGORY}-{NNN} ID format. (evidence: templates/prompt-templates.yaml scope and ID guidance.)
- [x] The section states that memory text is raw text, not a secret store, and must not be silently generated. (evidence: templates/prompt-templates.yaml memory rules.)
- [x] The section documents agent-local memory import safeguards, updatedBy attribution, and session-log action recording for memory mutations. (evidence: docs/context/memory.md and templates/prompt-templates.yaml import and attribution rules.)
- [x] A marker-template contract test fails if the required section, tools, render format, import safeguards, or attribution rules are missing. (evidence: MemoryContractArtifactTests.MemoryContextDocumentation_IncludesImportAndAttributionRules.)

## FR-MCP-MEMORY-005 REPL memory namespace

The REPL SHALL expose typed `workflow.memory.*` operations for memory add, list, update, and remove.
Scope: layer-1+
**Acceptance Criteria:**
- [x] `workflow.memory.add`, `workflow.memory.list`, `workflow.memory.update`, and `workflow.memory.remove` dispatch through typed workflow code.
- [x] Valid REPL memory commands return standard result envelopes.
- [x] Invalid memory method names return the normal method-not-found envelope.
- [x] Invalid request payloads return standard structured error envelopes without crashing the REPL process.

## FR-MCP-MEMORY-006 Memory scope management and ordering

The MCP Server SHALL allow memories to be marked Global or Workspace and SHALL return Global memories before Workspace memories, with each group sorted by ID ascending.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Add supports explicit `Scope` and defaults to Workspace only when omitted.
- [x] Update can change a memory between Global and Workspace under validated rules.
- [x] List APIs, REPL methods, stdio tools, and required-memory injection all use Global-first grouping.
- [x] Each scope group sorts by ID ascending using ordinal string comparison.
- [x] Global rows never appear after workspace rows, and workspace rows from other workspaces are excluded.

## FR-MCP-MEMORY-007 Agent plugin memory integration

Official McpServer agent plugins SHALL expose memory tools and SHALL inject the `REQUIRED MEMORIES` block at host-supported request boundaries, or SHALL document a host limitation and expose an explicit memory-list fallback.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Codex, Claude Code, Claude Cowork, Copilot, Grok, Cline v1, Cline v2, and OpenCode plugin lanes validate memory tool availability. (evidence: Shell plugin Bats memory tests and TypeScript memory tests.)
- [x] Plugins with request-boundary injection hooks render REQUIRED MEMORIES on every supported user prompt boundary. (evidence: Plugin validation and marker memory injection coverage.)
- [x] Plugins without a usable request-boundary injection hook document the host limitation without claiming automatic injection. (evidence: Plugin docs and validation expectations.)
- [x] Plugin validation identifies the host hook or fallback, workspace marker path, and example REQUIRED MEMORIES output. (evidence: Plugin validation coverage.)
- [x] Plugin memory mutations append session-log actions and clear local failsafe entries after server acknowledgement. (evidence: Shell Bats and TypeScript memory tests for mutation action append and failsafe cleanup.)

## FR-MCP-MEMORY-008 Federated Memory State

The MCP Server SHALL federate Memory as a first-class mutable federation domain. Memory federation uses the existing /mcpserver/memory REST surface and federation operation envelope pipeline, not new public memory endpoints. Adapter diagnostics, LocalProxy outage queueing, signed replay, hub conflict detection, and fanout apply semantics SHALL include the memory domain.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Federation adapter diagnostics list memory as covered, non-local-only, and apply-supported.
- [ ] /mcpserver/memory maps to federation domain memory.
- [ ] LocalProxy live forwarding of memory REST requests continues through existing proxy middleware.
- [ ] Offline queued memory creates require an explicit valid MEMORY-* ID.
- [ ] Offline memory creates without an explicit valid ID are not queued.
- [ ] Offline queued memory update and delete operations replay through signed envelopes.
- [ ] Stale memory base-version operations create federation conflicts and do not overwrite hub state.

## FR-MCP-PATHNORM-001 Persist workspace paths with forward slashes and platform tag

Operator directive (PLAN-PATHNORM-001, decision D1 2026-10-07: delivered in P1). Persisted workspace paths, storage keys and identity hashes use '/' as the separator for all platforms; the windows: (case-insensitive) / case-sensitive: tag is kept; Windows-origin paths are detected by drive letter (C:/) or UNC (//server/share), not by separator; the UNC leading '//' is preserved; paths are converted to '\' only at OS boundaries that require it (\\?\ long-path prefixes, cmd.exe arguments, native APIs). AC1: C:\Users\kingd, C:/Users/kingd and c:/users/KINGD produce one storage key. AC2: \\srv\share\x and //srv/share/x produce one storage key that still starts with //. AC3: Existing stores are converted by the --workspace-path-rekey maintenance command (decisions D5-D7 2026-10-07): after it runs no Windows-shaped workspace value contains a backslash, per-table and per-workspace row counts are unchanged, and foreign keys validate; the server refuses to start against an unconverted store (no dual-key lookup). AC4: Native file operations on Windows receive backslash paths where the OS requires them.
Scope: layer-1+

## FR-MCP-PLUGIN-BATCH-001 Plugin requirement batch payload parsing

All MCP server plugins SHALL accept valid YAML and JSON records arrays for requirement batch operations without schema-validation rejection.
Scope: layer-1+

## FR-MCP-PLUGINCORE-001 Canonical plugin core with sync and checksum guard

A single canonical plugin core SHALL be distributed into plugin repos by a sync tool that writes a per-file sha256 manifest, and a checksum guard SHALL fail CI when a synced file is edited locally.
Scope: layer-1+

## FR-MCP-PLUGINCORE-002 No-duplication CI guard for plugin lib files

Plugin CI SHALL fail when a lib file is neither covered by the core manifest nor declared as plugin residual.
Scope: layer-1+

## FR-MCP-PLUGINCORE-003 Persistent REPL daemon

A persistent REPL daemon SHALL serve many requests from one long-lived repl child over NDJSON framing, with auto-start, crash-restart, and spawn-per-call fallback.
Scope: layer-1+

## FR-MCP-PLUGINCORE-004 Reliable plugin session-log dialog parsing

Official McpServer plugins SHALL parse documented dialogItems and dialog payloads, preserve every item, and reject empty or unparseable appendDialog input instead of reporting a successful no-op.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Documented dialogItems arrays preserve every dialog item and increment auditDialog by the accepted item count. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Empty or unparseable appendDialog payloads return failure with an actionable error instead of a silent successful no-op. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] The canonical parsing fix propagates to every official plugin distribution without checksum drift. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-MCP-PLUGIN-HEADER-001 Agent runtime header fields record only observed values

Plugin-created session logs SHALL record the four agent runtime header fields (agentSessionId, agentSessionTranscriptFile, agentExecutablePath, agentExecutableVersion) only from observed runtime facts. A value SHALL NOT be synthesized, and a field SHALL be left empty rather than populated with a placeholder, a substitute identifier, or a path that does not exist. Scope: layer-1+. Acceptance Criteria: (1) a transcript path is recorded only when that file exists on disk; (2) the agent executable version is never taken from the plugin version, and is 'unknown' when live discovery fails; (3) agentSessionId carries only a provider-native identifier and is never the MCP session id; (4) a stale cached or environment-supplied value that fails these rules is dropped rather than re-submitted.
Scope: layer-1+

## FR-MCP-PLUGININT-001 End-to-end Session Log validation for every agent plugin

The repository family must provide repeatable integration coverage proving that Codex, Claude Code, Claude Cowork, Copilot, Grok, Cline, Cline v2, and OpenCode plugin surfaces complete the canonical Session Log workflow against a real MCP Server.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Every supported plugin has a scenario that bootstraps a session, begins a turn, appends representative action and dialog data, completes the turn, and verifies durable server-visible content. (evidence: tests/McpServer.PluginIntegration.Tests; tests/Build.Tests/PluginSessionLogIntegrationTargetTests.cs; overlay G2 Codex extra-high AGREE)
- [x] Each scenario resolves cache state only under {workspace}/.mcpServer/{agent}. (evidence: tests/McpServer.PluginIntegration.Tests; tests/Build.Tests/PluginSessionLogIntegrationTargetTests.cs; overlay G2 Codex extra-high AGREE)
- [x] Setting PLUGIN_ROOT_OVERRIDE cannot redirect session or turn cache state. (evidence: tests/McpServer.PluginIntegration.Tests; tests/Build.Tests/PluginSessionLogIntegrationTargetTests.cs; overlay G2 Codex extra-high AGREE)
- [x] The deterministic workflow assertions and companion aiUnit semantic assertions execute for all eight plugin scenarios. (evidence: tests/McpServer.PluginIntegration.Tests; tests/Build.Tests/PluginSessionLogIntegrationTargetTests.cs; overlay G2 Codex extra-high AGREE)
- [x] The validation target reports zero failed and zero skipped tests and identifies the exact plugin source revision used by each scenario. (evidence: tests/McpServer.PluginIntegration.Tests; tests/Build.Tests/PluginSessionLogIntegrationTargetTests.cs; overlay G2 Codex extra-high AGREE)
- [x] Every one of the eight catalog rows executes its production plugin entrypoint for bootstrap, begin, append dialog, append actions, complete, failed submit, and retry. Direct McpServer.Client calls do not satisfy plugin invocation. Persisted state is independently queried after process success. The aiUnit assertion invokes the configured aiUnit evaluator against a redacted execution receipt and fails closed on malformed, skipped, unavailable, or synthetic output. (evidence: tests/McpServer.PluginIntegration.Tests; tests/Build.Tests/PluginSessionLogIntegrationTargetTests.cs; overlay G2 Codex extra-high AGREE)
- [ ] For each server-side session persistence contract changed by this remediation, all eight supported production plugin entrypoints normalize primary success, retryable degraded or queued state, and terminal failure identically. Process exit alone never proves persistence; primary success requires exact server readback.

## FR-MCP-PLUGIN-SKILLS-001 Package workflow closeout skills across McpServer plugins

All McpServer plugin distributions expose sync-logs, commit-sync, and wrap-up as packaged skills so agents can synchronize logs, commit/push interrupted work, and close out MCP-backed work consistently across plugin families.
Scope: layer-1+

## FR-MCP-PRODUCT-001 Product CRUD

A registered workspace can create, get, list (visible), update, and soft-delete products it owns. Key is a PROD-* string matching ^PROD-[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$ (examples PROD-MCPSERVER, PROD-MCP-PLUGIN), unique among non-deleted products. Application API is CQRS only; REST/MCP/REPL/client only dispatch handlers. AC: create returns key + ownerWorkspaceId; invalid key is 400; duplicate key is 409; non-owner update/delete is 403; soft-delete hides from default list.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] create returns key and ownerWorkspaceId
- [ ] invalid key is 400
- [ ] duplicate key is 409
- [ ] non-owner update or delete is 403
- [ ] soft-delete hides product from default list

## FR-MCP-PRODUCT-002 Workspace product membership

A workspace maps to zero or more products. The owner workspace adds and removes members by workspace id. A member may leave itself. Adding a workspace requires that workspace to be registered, enabled, and not soft-deleted. AC: add requires registered enabled workspace; list members returns owner + members; leave removes only the caller; removed member loses product reads.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] add requires registered enabled workspace
- [ ] list members returns owner and members
- [ ] leave removes only the caller
- [ ] removed member loses product reads

## FR-MCP-PRODUCT-003 Shared effective requirements

Member GetEffectiveRequirements unions local effective rows with sibling members' effective rows, provenance-tagged with originWorkspaceId, layer-matched using the origin workspace layer catalog. productScope=local hides siblings; default productScope is product. AC: two workspaces in one product see each other's in-scope FR/TR/TEST/mappings; productScope=local hides siblings; id collision returns two rows with different originWorkspaceId.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] two member workspaces see each others in-scope FR TR TEST and mappings
- [ ] productScope local hides siblings
- [ ] id collision returns two rows with different originWorkspaceId

## FR-MCP-PRODUCT-004 Product isolation

Non-members cannot read product membership or sibling requirements. Local requirement mutations never write sibling rows. A leaked workspace API key cannot list all products or dump non-member workspaces. AC: outsider get-product is 404; outsider effective is local-only; update-fr on sibling id does not change the sibling row.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] outsider get-product is 404
- [ ] outsider effective is local-only
- [ ] update-fr on sibling id does not change the sibling row

## FR-MCP-PRODUCT-005 Product requirement context

Context search/pack can retrieve product-visible requirement text with origin tags. It must not pull sibling source files. Source type product-requirements filters to those chunks. AC: pack for a member includes sibling FR body; pack does not include sibling .cs chunks; source type product-requirements filters to those chunks.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] pack for a member includes sibling FR body
- [ ] pack does not include sibling source file chunks
- [ ] source type product-requirements filters to those chunks

## FR-MCP-QBAGENT-001 QBAgent marker-driven QuadBrain-only bootstrap

QBAgent SHALL communicate exclusively with the MCP Server QuadBrain service. On startup it SHALL read the marker file (AGENTS-README-FIRST.yaml) in its start directory and use that marker's apiKey and baseUrl to reach the QuadBrain service - with no other endpoints and no fallback. If no marker file is present in the start directory, QBAgent SHALL exit gracefully without error spew and without contacting any endpoint.
Scope: layer-1+
**Acceptance Criteria:**
- [x] A valid marker binds baseUrl and apiKey from the marker and applies the QBAgent profile.
- [x] A marker missing apiKey or with a non-absolute baseUrl is rejected as invalid.
- [x] With no marker present QBAgent exits gracefully with exit code 0 and contacts no endpoint.
- [x] An interactive run loop routes each prompt through the bound runtime, handles blank lines and exit commands, stops at end of input, and reports runner failures without aborting.

## FR-MCP-QBEXEC-001 QuadBrain server-side MCP-tool execution with AoT transaction interception

QuadBrain SHALL execute every MCP-internal tool (every tool whose name starts with mcp_ that McpServer exposes: session, TODO including query/get/plan/status/implementation, requirements including list/get/create/update, repo including read/list/write/edit, GraphRAG, desktop, PowerShell session, client invoke, and mutating git) directly server-side during orchestration through existing in-process application/CQRS services. QuadBrain SHALL NOT emit mcp_ tools to QBAgent as OpenAI tool_calls. Successful internal execution SHALL return a normal assistant message (finish_reason stop) carrying the service result. Tools OUTSIDE McpServer (non-mcp_ names) SHALL be emitted as OpenAI tool_calls for QBAgent. Internal execution SHALL NOT call HTTP endpoints. Mutating TODO and Requirements tools SHALL still gate through the turn transaction coordinator. QuadBrain orchestration SHALL perform session logging.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Tools are classified MCP-internal (mcp_ prefix) versus external. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainToolInterceptionTests.cs)
- [x] The interceptor executes handled internal tools server-side and strips them; only non-mcp_ external calls are emitted to the agent as tool commands. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainToolInterceptionTests.cs)
- [x] Internal tool failures and unhandled internal tools are surfaced to the agent as a note and earmarked as Session Log failures, never as tool commands. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainOpenAiChatServiceTests.cs)
- [x] A concrete executor routes TODO and Requirements mutations through the transaction-gated services so the AoT commit applies them server-side. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs)
- [x] QuadBrain orchestration performs the Session Log write for the turn including internal-tool failure entries. (evidence: tests/McpServer.Support.Mcp.Tests/Services/BrainInteractionSessionLoggerTests.cs; tests/McpServer.Support.Mcp.Tests/Services/QuadBrainOpenAiChatServiceTests.cs)
- [x] Every mcp_* tool name published by McpHostedAgentToolAdapter and QBAgentDefinition (AllowedTools plus BlockedTools) is executed server-side when elected. None of those names appear in the OpenAI tool_calls array returned to QBAgent. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainOpenAiChatServiceTests.cs CompleteAsync_CatalogName_StopsWithoutEmittingToolCall; docs/receipts/hostile-validator-20260910T233311Z.md)
- [x] When every elected tool is mcp_* and execution succeeds, the OpenAI response is finish_reason stop with assistant content equal to the in-process service result (not an empty message and not a tool_call). (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainOpenAiChatServiceTests.cs CompleteAsync_CatalogName_StopsWithoutEmittingToolCall)
- [x] Internal tool execution dispatches in-process application/CQRS services (ITodoService, IRepoFileService, session-log, requirements, GraphRAG, desktop, PowerShell session, and so on). It does not HTTP-call /mcpserver/*, /v1/*, or /mcp-transport, and tests proving this do not depend on the Windows service. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Executor_DoesNotDependOnHttpClient)

## FR-MCP-QBEXEC-002 Concrete QuadBrain internal-tool executor

QuadBrain SHALL provide a concrete IQuadBrainInternalToolExecutor (replacing NoopInternalToolExecutor in DI) that dispatches every mcp_* tool name QuadBrain may elect. Reads and queries SHALL call the same in-process application/CQRS services controllers use (ITodoService, IRepoFileService, session-log, requirements, GraphRAG). Mutations SHALL call the transaction-gated services (ITransactionGatedTodoMutationService, the transaction-gated requirements document service, TransactionGatedRepoFileService, mutating mcp_git) so each mutation commits through the turn transaction coordinator. Results map to InternalToolExecutionOutcome.Ok/Fail. An mcp_ name that is not in the hosted MCP tool catalog returns Unhandled and is surfaced as a note, never as a QBAgent tool command. The executor SHALL NOT invoke HTTP endpoints.
Scope: layer-1+
**Acceptance Criteria:**
- [x] mcp_todo_query, mcp_todo_get, mcp_todo_plan, mcp_todo_status, mcp_todo_implementation, mcp_todo_create, mcp_todo_update, and mcp_todo_delete are handled. Mutations go through ITransactionGatedTodoMutationService; reads/queries go through ITodoService. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Execute_CatalogName_IsHandled)
- [x] Every mcp_requirements_* name (list/get/create/update for FR, TR, and TEST) is handled through the requirements application/CQRS services. Mutations remain transaction-gated. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Execute_CatalogName_IsHandled)
- [x] mcp_repo_read, mcp_repo_list, mcp_repo_write, and mcp_repo_edit are handled through IRepoFileService. Writes/edits remain transaction-gated with snapshot rollback on reject. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Execute_CatalogName_IsHandled)
- [x] An mcp_ name that is not in the hosted MCP tool catalog returns InternalToolExecutionOutcome.Unhandled and is surfaced as a note, never as a tool command. The executor replaces NoopInternalToolExecutor in DI. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Execute_UnknownCatalogAbsentMcpName_ReturnsUnhandled; src/McpServer.Support.Mcp/Program.cs)
- [x] mcp_session_bootstrap, mcp_session_update, mcp_session_turn_begin, mcp_session_turn_update, mcp_session_turn_complete, and mcp_session_query_history are handled through the session-log application services. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Execute_CatalogName_IsHandled)
- [x] Every mcp_graphrag_* name from McpHostedAgentToolAdapter is handled through GraphRAG application services. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Execute_CatalogName_IsHandled)
- [x] mcp_desktop_launch, mcp_powershell_session_create, mcp_powershell_session_command, mcp_powershell_session_close, mcp_client_invoke, and mutating mcp_git are handled through their existing in-process services. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs; IQuadBrainPowerShellSessions)
- [x] No handled route uses HttpClient or REST against /mcpserver/*, /v1/*, or /mcp-transport. Unit and integration tests proving these routes use mocks or WebApplicationFactory and do not require the Windows service. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Executor_DoesNotDependOnHttpClient)

## FR-MCP-QBEXEC-003 Full-fidelity inter-brain session logging

QuadBrain SHALL log all interaction between the brains in full. Every brain-slot invocation (LeftHemisphere, RightHemisphere, CuriosityEngine, ArbiterOfTruth) and the AoT reconciliation SHALL write its full prompt and full output text to the session log, correlated by the turn's TurnId, in addition to the existing durable hashed audit row (BrainSlotInvocationEntity). Internal-tool execution outcomes and internal-tool failure notes SHALL also be recorded to the session log. Secrets SHALL be redacted. This is a primary reason the model runs inside the MCP Server.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Each brain-slot invocation writes full prompt + full output text to the session log (not only SHA-256 hashes), under the correct TurnId.
- [ ] AoT reconciliation input and output are logged in full to the session log.
- [ ] Internal-tool executed and failed outcomes (interception Executed/Failed) are recorded to the session log as the turn proceeds.
- [ ] Secret values (api keys, bearer tokens) are redacted before logging; the existing hashed BrainSlotInvocationEntity audit row is retained as the durable index.

## FR-MCP-QBOLLAMA-002 Ollama integration tests provision and release their own server

The QuadBrain Ollama integration tests must not require an operator to have started Ollama beforehand. At startup the test fixture probes http://localhost:11434/api/tags. If a server already answers, the fixture uses it and must leave it running after the tests finish. If no server answers, the fixture starts one from a discovered ollama executable, waits until the endpoint answers, and records that it owns the process. At teardown the fixture stops only a server it started itself, and never stops a pre-existing server. If no ollama executable can be discovered, the fixture fails with an actionable message naming the InstallOllama Nuke target rather than a bare connection-refused error. A server the fixture started must not survive the test run even when the run fails or the endpoint never becomes reachable.
Scope: layer-1+

## FR-MCP-QBOPENAI-001 QuadBrain OpenAI-compatible chat-completions endpoint

QuadBrain SHALL expose an inbound OpenAI-compatible chat-completions endpoint (chat/completions shape) backed by QuadBrain orchestration, accepting standard OpenAI chat messages and tool/function definitions and returning OpenAI-shaped completions - including assistant tool_calls when the model elects to invoke a tool - so any OpenAI-compatible client, including QBAgent, can use QuadBrain as a drop-in model. QBAgent (FR-MCP-QBAGENT-001) consumes this endpoint as its IChatClient and executes the emitted tool calls via the Microsoft Agent Framework loop; the ACID tightly-coupled profile is NOT required for QBAgent.
Scope: layer-1+
**Acceptance Criteria:**
- [x] An inbound OpenAI chat request maps the role-tagged transcript onto QuadBrain orchestration and returns the Arbiter output as the assistant message.
- [x] Tool definitions in the request flow through and the response emits assistant tool_calls when QuadBrain elects to call a tool.
- [x] Bearer-auth (Authorization Bearer with X-Api-Key fallback) is validated via WorkspaceTokenService; invalid or missing yields 401.
- [x] QBAgent wires a standard OpenAI IChatClient to the v1 endpoint and runs the Agent Framework tool loop with action tools under the non-ACID profile.

## FR-MCP-QBPROGRESS-001 Live QuadBrain role progress on qbagent

While a qbagent prompt is running, the operator SHALL see each QuadBrain role (Creativity, Logic, CuriosityEngine, ArbiterOfTruth) as it starts and when it completes, including that role's output text, without waiting for the full orchestration to finish. The OpenAI chat-completions stream SHALL emit those role events before the final Arbiter assistant message. The final assistant message remains the Arbiter decision (FR-MCP-QBOPENAI-001). Heartbeat still-working lines are not a substitute for role progress.
Scope: layer-1+

## FR-MCP-QBRAIN-001 Product display brand is QBrain.AI

Where this product is named for a person, the display brand is QBrain.AI. That includes the README title, live documentation titles, the Windows service DisplayName, and other human-readable product titles. It does not by itself rename a namespace, a package id, a path, or a repository.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A reader of the live README title sees QBrain.AI.
- [ ] The Windows service DisplayName is QBrain.AI where the service is installed under the new name.
- [ ] Live product titles no longer use "MCP Server" for this product.
- [ ] Historical receipts are not rewritten to satisfy this requirement.

## FR-MCP-QBRAIN-002 Product identity stays distinct from the Model Context Protocol

The open protocol remains the Model Context Protocol. Protocol wording and the protocol endpoint stay recognizable as MCP. The product rename must not make agents treat `/mcp-transport` or MCP JSON-RPC as a retired product name.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Live docs that describe the wire protocol still say Model Context Protocol where they mean the protocol.
- [ ] `/mcp-transport` remains the MCP endpoint and is not redirected onto a QBrain.AI path.
- [ ] Bare "MCP" in protocol sentences is classified and left in place. It is not bulk-replaced.

## FR-MCP-QBRAIN-003 Product identity stays distinct from QuadBrain and QBAgent

QuadBrain remains the four-role feature. QBAgent remains the agent tool. The command `qbagent` remains `qbagent`. The product brand QBrain.AI must not absorb those names, and those names must not be rewritten into QBrain.AI.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Live docs still describe QuadBrain as the feature and QBrain.AI as the product.
- [ ] The tool command `qbagent` still exists.
- [ ] The namespace segment `QBAgent` remains `QBAgent` after the product root changes.

## FR-MCP-QBRAIN-004 1.x callers keep a working product identity

Through the 1.x line, a caller that still uses the old product route, the old config section, the old product environment variables, or the old NuGet package ids can still operate. At 2.0 those aliases end. This is the continuity requirement. How the aliases are built is a technical requirement.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A 1.x request to the old product HTTP prefix still succeeds for the representative route covered by tests.
- [ ] A 1.x configuration that contains only the old config section still boots.
- [ ] A 1.x package reference to each published `SharpNinja.McpServer.*` id still compiles against the moved public types via the type-forward package.
- [ ] 2.0 is the version where those aliases are allowed to stop. They are not removed inside 1.x.

## FR-MCP-QBRAIN-005 Historical identity and host names stay

People can still read historical receipts, existing requirement IDs, and the host names PAYTON-LEGION2 and LAB-OMARCHY as they were written. The rebrand does not rewrite that history and does not rename those machines or that lab.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Existing files under `docs/receipts/**` are not rewritten. New inventory and hostile-validation receipts may be added. They do not replace historical receipt bodies.
- [ ] Existing `FR-MCP-*`, `TR-MCP-*`, and `TEST-MCP-*` IDs are not renamed. The new IDs in this plan are additions.
- [ ] The hostname PAYTON-LEGION2 and the lab name LAB-OMARCHY still appear where they identify that host and that lab.

## FR-MCP-QBSEED-001 Config-driven Quad-Brain provisioning and live-loop readiness

The server provisions the four GLOBAL Quad-Brain roles (LeftHemisphere, RightHemisphere, CuriosityEngine, ArbiterOfTruth) into the durable brain-slot registry from configuration at startup, without manual API calls, as a single global set. The /v1 OpenAI-compatible endpoint resolves the caller workspace from its token to scope server-side internal-tool mutations, not brain-slot visibility (brains are global).
Scope: layer-1+
**Acceptance Criteria:**
- [x] When Mcp:BrainSlots:ExecutionEnabled is true and Slots is populated, the startup seeder upserts and enables each configured slot as a single global set and the quad becomes ready in every workspace context.
- [x] Provisioning is idempotent across restarts and does not abort host startup when a single slot definition is invalid.
- [x] When execution is disabled or no slots are configured, the seeder provisions nothing.
- [x] A /v1/chat/completions request runs the real four-role orchestration over the global brains; the token workspace scopes only the internal-tool mutations.

## FR-MCP-QBSKILLS-001 Agent Skills registry and progressive disclosure

QBAgent provides an agentskills.io-compatible skill registry/loader. Discovery loads only each skill name+description; Activation loads the full SKILL.md on demand; Execution follows the instructions using the baseline tools. SKILL.md frontmatter requires name and description (optional license/version/allowed-tools).
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Discovery returns only name+description for every available skill; load returns the full SKILL.md body.
- [ ] A SKILL.md missing name or description is rejected by the manifest parser.

## FR-MCP-QBSKILLS-002 Skill tool (list_skills / load_skill)

QBAgent exposes external tools list_skills and load_skill(name) so the model can discover and activate skills at runtime under progressive disclosure.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] list_skills returns the discovery list; load_skill returns the named skill body.

## FR-MCP-QBSKILLS-003 Vendor dotnet/skills and author workspace skills

The repo vendors dotnet/skills (agentskills.io) and authors workspace skills in SKILL.md format: byrd-tdd-process, mcp-session-logging, mcp-todo, mcp-requirements-traceability, and usage skills for the git/bash/edit tools. Discovery scans both vendored and workspace skill roots.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Discovery includes both vendored dotnet/skills and authored workspace skills.
- [ ] Authored workspace SKILL.md files pass frontmatter validation.

## FR-MCP-QBTOOLS-001 QBAgent external file tools

QBAgent exposes agent-side external tools read_file, write_file, edit_file, and list_files that operate on the workspace through the MCP client (server RepoFileService), so the server path-traversal/reparse/allowlist safety governs all file access from both planes.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] read_file/write_file/edit_file/list_files are registered as non-mcp_ external AITools and execute in the QBAgent loop.
- [ ] All four route through the MCP client to the server RepoFileService; path traversal and out-of-root access are rejected server-side.

## FR-MCP-QBTOOLS-002 QBAgent run_powershell tool

QBAgent exposes a run_powershell external tool backed by the in-process HostedPowerShellSessionManager runspace, returning output/error/exit streams.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] run_powershell executes a command in a hosted runspace and returns captured output and error streams.

## FR-MCP-QBTOOLS-003 QBAgent run_bash tool (optional Git Bash)

QBAgent exposes an optional run_bash external tool that resolves bash.exe (Git for Windows) from PATH via ProcessRunner; when bash is unavailable it returns a structured unavailable result rather than failing the agent. PowerShell remains primary.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] When bash.exe is present, run_bash executes a command and returns stdout/stderr/exit code.
- [ ] When bash.exe is absent, run_bash returns available=false without throwing.

## FR-MCP-QBTOOLS-004 QBAgent git tool (full, push to origin)

QBAgent exposes a git external tool supporting status, diff, log, branch, add, commit, checkout, push, and reset via ProcessRunner. Push targets the existing origin remote name only; arbitrary remotes/refspecs from the model are rejected. Mutating git on the internal plane is transaction-gated.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Read subcommands (status/diff/log/branch) run against the workspace repo and return output.
- [ ] add/commit/checkout/reset/push are supported; push targets origin only and never a non-origin remote.
- [ ] Unknown subcommands are rejected.

## FR-MCP-QBTOOLS-005 Server-side mcp_repo_edit, mcp_bash, mcp_git tools

The MCP tool adapter exposes server-side mcp_repo_edit, mcp_bash, and mcp_git tools (mcp_ prefix) executed server-side by QuadBrain via the internal-tool executor; mutating variants are transaction-gated. One core implementation per capability is shared with the agent-side external tools.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] mcp_repo_edit/mcp_bash/mcp_git are present in the adapter tool surface with mcp_ prefix.
- [ ] Mutating mcp_ tools are gated through the turn transaction coordinator and share the single core capability with the external plane.

## FR-MCP-QBTOOLS-006 RepoFileService targeted edit

IRepoFileService gains EditAsync(relativePath, oldString, newString, expectedOccurrences?) performing a targeted string replacement with the same path-safety, audit, and change-event behavior as Write; ambiguous or missing matches fail; transactional compensation reuses the snapshot/restore path.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A unique oldString is replaced; a missing oldString fails; an ambiguous match fails unless replaceAll/expectedOccurrences is set.
- [ ] Transaction-gated EditAsync rolls back to the original content when the transaction is rejected.

## FR-MCP-QBTOOLS-007 QBAgent registers full tool and skill surface

QBAgent registers the full external tool set (file/powershell/bash/git) plus the skill tools on every run via baseOptions.ChatOptions.Tools, and injects the skill discovery list into the system prompt.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Every QBAgent run exposes the external tool set and the skill tools to the Agent Framework loop.

## FR-MCP-QUAD-SESSION-001 Per-session QuadBrain instances over global brains

QuadBrain brain definitions are global, but a running orchestration is an instance attached to a single session; multiple instances may run concurrently, each bound to its own session. A /v1/chat/completions request declares its session via the X-Session-Id header (optional X-Turn-Id), and the server threads that session and turn into the orchestration so inter-brain logging, internal-tool-failure logging, and turn transactions are correlated and concurrent instances stay isolated.
Scope: layer-1+
**Acceptance Criteria:**
- [x] A /v1 request X-Session-Id (and optional X-Turn-Id) header is threaded into the orchestration request metadata (sessionId/turnId) and TurnId.
- [x] Inter-brain logging and internal-tool-failure logging use the attached session/turn and are a no-op when absent.
- [x] A request with no X-Session-Id attaches no session metadata and runs as an anonymous instance.
- [x] Multiple concurrent /v1 requests with different X-Session-Id values are independent instances over the shared global brains.

## FR-MCP-REPL-001 YAML Protocol STDIO REPL Host

The server shall provide a YAML-envelope STDIO REPL host that accepts structured commands over standard input, executes operations against workspace services, and returns structured YAML responses over standard output. The REPL host shall support the same trust bootstrap, authentication, and workspace resolution semantics as the HTTP and MCP STDIO transports.

**Status:** ✅ Complete

**Technical Implementation:** [TR-MCP-REPL-001](./Technical-Requirements.md#tr-mcp-repl-001) | [TR-MCP-REPL-002](./Technical-Requirements.md#tr-mcp-repl-002) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `McpServer.Repl.Core` (`IReplProtocol`, `IYamlEnvelope`, `IYamlSerializer`, `IMarkerFileReader`, `ITrustBootstrapService`, `IAuthRotationHandler`, `IWorkspaceSelector`), `McpServer.Repl.Host` (`Program.cs`, `AgentStdioHandler`, `InteractiveHandler`, `ServiceCollectionExtensions`)
Scope: layer-1+

## FR-MCP-REPL-002 REPL Lifecycle Management

The REPL host shall support graceful startup, interactive command loop, structured error handling with typed error codes, and clean shutdown on EOF or explicit exit commands. The host shall maintain session context across commands within a single process invocation and emit lifecycle events for observability.

**Status:** ✅ Complete

**Technical Implementation:** [TR-MCP-REPL-003](./Technical-Requirements.md#tr-mcp-repl-003) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `McpServer.Repl.Host` (`Program.cs`, `AgentStdioHandler`, `InteractiveHandler`), `McpServer.Repl.Core` (`SessionLogErrorEnvelope`)
Scope: layer-1+

## FR-MCP-REPL-003 Command Namespace Parity

The REPL command surface shall provide namespace-organized commands with functional parity to HTTP REST endpoints and MCP STDIO tools for TODO operations, session log operations, context operations, requirements management, workspace management, and agent pool operations. Command routing shall reuse existing service contracts without duplicating business logic.

**Status:** ✅ Complete

**Technical Implementation:** [TR-MCP-REPL-004](./Technical-Requirements.md#tr-mcp-repl-004) | [TR-MCP-REPL-005](./Technical-Requirements.md#tr-mcp-repl-005) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `McpServer.Repl.Core` (`ITodoWorkflow`, `TodoCommandShapes`, `ISessionLogWorkflow`, `SessionLogCommandShapes`, `SessionLogModels`, `IRequirementsWorkflow`, `RequirementsCommandShapes`, `RequirementsCommandModels`, `IGenericClientPassthrough`, `ClientCommandShapes`), `McpServer.Repl.Host` (`TodoWorkflow`, `RequirementsWorkflow`, `SessionLogWorkflow`, `GenericClientPassthrough`)
Scope: layer-1+

## FR-MCP-REPL-004 Trust Bootstrap and Auth Rotation

The REPL host shall implement marker-file trust bootstrap with signature verification and health nonce challenge before accepting operational commands. API key authentication shall use the same per-workspace token semantics as HTTP endpoints. The host shall detect API key rotation between commands and emit warnings when tokens become stale.

**Status:** ✅ Complete

**Technical Implementation:** [TR-MCP-REPL-006](./Technical-Requirements.md#tr-mcp-repl-006) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `McpServer.Repl.Core` (`ITrustBootstrapService`, `IMarkerFileReader`, `IAuthRotationHandler`), `McpServer.Repl.Host` (`AgentStdioHandler`)
Scope: layer-1+

## FR-MCP-REPL-005 Orchestration State Visibility

The REPL host shall expose commands for querying agent pool state, active voice sessions, queued one-shot requests, and workspace notification subscriptions. State queries shall return current snapshots without blocking on long-running operations.

**Status:** ✅ Complete

**Technical Implementation:** [TR-MCP-REPL-007](./Technical-Requirements.md#tr-mcp-repl-007) | [Mapping](./TR-per-FR-Mapping.md)

**Covered by:** `McpServer.Repl.Core` (`IGenericClientPassthrough`, `ClientCommandShapes`), `McpServer.Repl.Host` (`GenericClientPassthrough`)

---

## REPL v1.0 Requirements Freeze

**Freeze Tag:** `REPL-v1.0-FREEZE` | **Date:** 2025-01-04

All REPL functional requirements (FR-MCP-REPL-001 through FR-MCP-REPL-005) are complete and frozen for v1.0 delivery. Full source code traceability comments have been added to all `McpServer.Repl.Core` and `McpServer.Repl.Host` files. All iteration 1-6 unit tests and integration tests pass. No defects remain.


---
Scope: layer-1+

## FR-MCP-REPL-006 Deprecate workflow.* REPL namespaces in favor of client.* passthrough

The REPL SHALL mark every workflow.* response deprecated and route workflow.sessionlog lifecycle verbs with explicit identifiers statelessly through the SessionLog client.
Scope: layer-1+

## FR-MCP-REPL-007 REPL Credential Discovery Diagnostics

`mcpserver-repl --agent-stdio` shall expose `--workspace-path` and `--marker-file` CLI overrides for credential resolution. When marker discovery fails, the diagnostic message shall enumerate every directory searched and distinguish "marker not found" from "marker signature mismatch". The diagnostic is forwarded into the `McpServerClient` and appended to the "Authentication required" exception so callers see the root cause rather than the generic message.

**Covered by:** `MarkerFileClientOptionsResolver.TryResolveWithDiagnostics`, `Program.cs` (`--workspace-path` / `--marker-file`), `McpClientBase.EnsureAuthenticated`
Scope: layer-1+

## FR-MCP-REPL-008 Per-agent REPL isolation

Agent REPL callers must identify the invoking agent on every mcpserver-repl invocation so session, cache, and verified marker state are isolated per agent and workspace.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Every plugin REPL launcher passes --agent, including the default agent value. (evidence: plugins/core/lib-sh/repl-invoke.sh; plugins/core/lib-ps/repl-invoke.ps1; plugins/core/lib-sh/repl-daemon.js; plugins/core/lib-node/src/transport/repl-bridge.ts)
- [x] Verified marker cache entries are keyed by canonical agent identity and workspace. (evidence: src/McpServer.Repl.Host/MarkerFileClientOptionsResolver.cs; tests/McpServer.Repl.IntegrationTests/MarkerFileClientOptionsResolverTests.cs)
- [x] Named-agent child process invocation is covered by integration tests. (evidence: tests/McpServer.Repl.IntegrationTests/ReplChildProcessHelper.cs; tests/McpServer.Repl.IntegrationTests/MarkerFileClientOptionsResolverTests.cs)

## FR-MCP-REPL-009 Degraded session-log persistence isolation

The MCP REPL SHALL isolate plugins from MCP Session Log service degradation during session and in-progress turn operations. When a turn closes while the primary service is degraded, the REPL SHALL durably persist the complete turn through an independent failsafe strategy and SHALL notify the caller with the failsafe path.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Open, begin, update, appendDialog, and appendActions remain successful when primary MCP Session Log persistence fails but failsafe persistence succeeds. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] The failsafe artifact contains a replayable session-log persistence envelope including the attempted turn data and status. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] completeTurn and failTurn report degraded persistence, the independent strategy name, and the absolute failsafe path without claiming primary MCP persistence succeeded. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Primary persistence success produces no pending failsafe artifact and reports normal MCP persistence. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-MCP-REPL-010 Plugin session-log title refinement surfaces

The MCP REPL plugin SHALL expose setTurnTitle and setSessionTitle workflow methods that durably update the active turn's title and the session title through explicit server title-update paths, so an agent-refined title survives the whole-session re-submit the plugin issues on every subsequent persist. Scope: layer-1+. Acceptance Criteria: (1) workflow.sessionlog.setTurnTitle updates current-turn.yaml queryTitle and persists the new title to the server for the active turn; (2) workflow.sessionlog.setSessionTitle writes session-state.yaml title and persists the new session title to the server; (3) a subsequent supersede/complete/append whole-session re-submit does not revert either title.
Scope: layer-1+

## FR-MCP-REPL-011 Plugin failsafe queue drains instead of accumulating

BUG-TRIAGE-097. The MCP plugin PowerShell runtime writes every session-log submit to a failsafe queue on disk before calling the backend, so a crash or an unreachable server cannot lose the turn. Until now nothing ever replayed those records: the queue only grew, and plugin Status reported pendingCount 0 while captured turns sat undrained (33 records in F:/GitHub/McpServer as of 2026-07-20, oldest 2026-07-14, eight added in a single session). An agent or operator MUST be able to get queued turns into the session log once the backend is reachable again, automatically on the first proven-reachable call and on demand through an explicit drain verb, without ever losing a record: a record leaves the queue only after its submission is confirmed, a record the backend rejects does not block the newer records behind it, and a record that cannot be replayed at all is set aside for inspection rather than deleted or retried forever. Plugin Status MUST report the real queue depth.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Each session-log submit is written to the workspace and agent scoped failsafe queue before backend submission, and both automatic proven-reachable replay and explicit drain process records oldest first.
- [ ] A recovery record is deleted only after the backend confirms durable persistence for the exact workspace, agent, session, and request.
- [ ] A backend-rejected record does not block newer records, and a structurally unreplayable or exhausted record is quarantined with diagnostics rather than deleted or retried forever.
- [ ] Plugin status reports the real pending and quarantined queue depth for the active workspace and agent.
- [ ] Drain submission uses the 120-second default helper budget and honors a larger REPL_TIMEOUT; an ordinary two-second nested helper budget is not applied to replay. Automatic nested drain defers while a REPL call is in flight and a timeout abort leaves drainAttempts and completion latch unchanged.

## FR-MCP-REQAC-001 Structured acceptance criteria on requirements

FR/TR/TEST requirements support structured acceptance criteria using the same {id,text,isSatisfied,evidence} shape as TODO acceptance criteria, settable on create/update and returned on get.
Scope: layer-1+

## FR-MCP-REQAC-002 Copy acceptance criteria from a TODO to a requirement

A copy operation populates a requirement's acceptance criteria from a TODO's acceptance criteria verbatim (field-for-field).
Scope: layer-1+

## FR-MCP-REQAC-PLUGIN-001 Plugin acceptanceCriteria rollout

All Bash and TypeScript MCP plugin families expose structured acceptanceCriteria on FR/TR/TEST create and update flows, including copy-from-TODO support where applicable.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Bash and TypeScript plugin live gates preserve structured acceptanceCriteria through workflow and REST round-trip verification. (evidence: Live FR-CODEXBIND-001 workflow create/get plus REST GET returned AC-CODEXBIND-001 after service and REPL tool updates.)

## FR-MCP-REQACPLUGIN-001 Plugins expose AcceptanceCriteria on requirements surface

Every MCP server plugin (bash and TypeScript families) lets its agent set and read structured acceptanceCriteria ({id,text,isSatisfied,evidence}) on FR/TR/TEST create/update via the plugin command surface, including hydration on partial updates.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Bash family typed-params builder emits acceptanceCriteria block on create+update for FR/TR/TEST
- [ ] TypeScript family tool inputSchema declares acceptanceCriteria + typedParams forwards it
- [ ] Plugin tests cover both create and partial-update hydration paths

## FR-MCP-REQACPLUGIN-002 Plugins fail on proven AcceptanceCriteria loss

Every MCP server plugin that accepts caller-supplied requirement acceptanceCriteria must either preserve the supplied criteria or fail loudly when the mutation response proves the criteria were dropped.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Criteria-only requirement updates preserve the caller-supplied acceptanceCriteria block instead of replacing it with an empty or stale hydrated list. (evidence: Direct sourced shell assertions passed for Codex, Claude Code, Claude Cowork, Copilot, and Grok; Jest criteria-only update tests passed for Cline, Cline v2, and OpenCode.)
- [x] If a caller supplies acceptanceCriteria and a successful mutation response explicitly returns acceptanceCriteria empty, the plugin reports requirements_acceptance_criteria_not_captured instead of success. (evidence: Direct sourced shell assertions and focused Jest tests exercise the explicit empty-response case.)
- [x] Requirement create/update calls without acceptanceCriteria continue to work without injecting an empty criteria list. (evidence: Shell no-AC create assertions passed and existing TypeScript focused tests remain green.)

## FR-MCP-REQRECOVERY-001 Atomic requirements ledger recovery

The MCP Server shall support dry-running and atomically applying an auditable recovery plan that can create, update, or delete FR, TR, TEST, acceptance-criteria, and mapping state without exposing a partially recovered ledger.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Dry-run performs no mutation and returns a deterministic ordered plan containing every create, update, delete, mapping upsert, and mapping delete plus a normalized hash of the effective pre-state.
- [ ] Apply commits all validated requirement records, acceptance criteria, deletions, and mappings in one transaction. Any validation, referential-integrity, concurrency, or persistence failure rolls the complete plan back.
- [ ] Apply requires the dry-run pre-state hash and an idempotency key. A stale hash or reuse of the key with different content is rejected without mutation.
- [ ] Replaying an identical committed request with the same idempotency key returns the original committed result and creates no duplicate records, criteria, mappings, or audit entries.
- [ ] A committed result reports exact per-operation counts and IDs, the new effective-state hash, and a query-verifiable audit receipt whose post-state matches the approved plan.
- [ ] Every supported agent plugin that advertises requirements operations exposes the same dry-run and apply schema and normalizes success, stale-precondition, idempotent replay, and rollback outcomes identically through its production entrypoint.
- [ ] Dry-run and apply bind the plan to the exact workspace ID, target layer key, productScope value, layer-catalog version or hash, scopeStartLayerKey, scopeEndLayerKey, normalized raw target-layer state including shadowed rows, and normalized effective projection. Every bound value is returned in the plan and audit receipt.
- [ ] Apply compares every bound raw, effective, layer-catalog, and scope precondition inside the transaction immediately before the first mutation, rejects stale or out-of-bound plans without mutation, writes only records owned by the declared target layer, and never silently mutates inherited or shadowed records outside the declared bounds.

## FR-MCP-REQSCOPE-001 FR-MCP-REQSCOPE-001

Placeholder requirement backfilled for TODO link FR-MCP-REQSCOPE-001.
Scope: layer-1+

## FR-MCP-REQSCOPE-002 FR-MCP-REQSCOPE-002

Placeholder requirement backfilled for TODO link FR-MCP-REQSCOPE-002.
Scope: layer-1+

## FR-MCP-REQSCOPE-003 FR-MCP-REQSCOPE-003

Placeholder requirement backfilled for TODO link FR-MCP-REQSCOPE-003.
Scope: layer-1+

## FR-MCP-REQSCOPE-004 FR-MCP-REQSCOPE-004

Placeholder requirement backfilled for TODO link FR-MCP-REQSCOPE-004.
Scope: layer-1+

## FR-MCP-SERVICEUPDATE-001 Cross-platform service update preserving live state

The existing Nuke UpdateService target detects Windows or Linux and updates the selected service while preserving the live configuration and file data strategy. Linux updates an existing systemd service without rewriting its operator configuration.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] UpdateService selects Windows or Linux at runtime; Windows defaults/launcher remain compatible; Linux x64/arm64 use extensionless apphost; unsupported hosts fail before changes.
- [ ] Both platforms preserve live appsettings.yaml and configured DataFolder with legacy fallback. Linux also preserves unit/drop-ins/environment files and Unix ownership/modes/ACLs/xattrs through a private retained archive.
- [ ] Linux validates installed service identity and stage before stop; backup precedes replacement; restore precedes start; service executable and server/workspace health must pass. Failures preserve recovery artifacts and never report success.
- [ ] Mocks-first tests and full applicable unit suites pass with zero failures/skips; independent gates pass; existing local Linux service update preserves configuration/data and trusted workspace behavior.

## FR-MCP-SESSIONATTR-001 Session-log foreign filesModified and commits are rejected or marked

A session-log turn for workspace W never lists filesModified or commit artifacts that resolve outside W unless the turn explicitly marks them as cross-workspace or foreign-repo. Forward-only. BUG-TRIAGE-108.
- [ ] filesModified outside workspace root rejected or require foreign marker
- [ ] commit SHA/message/files from another repo require foreign marker or redirect
- [ ] Completeness audits can filter foreign artifacts
Scope: layer-1+
**Acceptance Criteria:**
- [ ] filesModified outside workspace root rejected or require foreign marker
- [ ] commit SHA/message/files from another repo require foreign marker or redirect
- [ ] Completeness audits can filter foreign artifacts

## FR-MCP-SESSIONEND-001 SessionEnd emits empty object when cache cannot be resolved

SessionEnd and pre-compact emit {} and exit 0 when Resolve-McpCacheDir cannot find a workspace. When cwd, CLAUDE_PROJECT_DIR, or hook payload identifies a workspace, flush that cache. No-op is not a hook failure. BUG-TRIAGE-140. FR-MCP-115.
- [ ] missing MCP_WORKSPACE_PATH SessionEnd exit 0 and {}
- [ ] identifiable workspace still flushes .mcpServer/<agent>
- [ ] no pending cache is a silent no-op
Scope: layer-1+
**Acceptance Criteria:**
- [ ] missing MCP_WORKSPACE_PATH SessionEnd exit 0 and {}
- [ ] identifiable workspace still flushes .mcpServer/<agent>
- [ ] no pending cache is a silent no-op

## FR-MCP-SESSIONLIFE-001 Degraded begin keeps the full turn and does not advertise a stored open

A degraded beginTurn keeps queryText, queryTitle, planFile, todoId, turnRequestId, sessionId, openedAt, build state, and audit counters. Hook status is turn-opened-degraded until the store has the turn. Complete recovery order is cached queryText, then cached queryTitle, then Recovered session-log turn, without forcing queryTitle. Update and append omit an empty QueryText. Supersede persists canceled. appendDialog on a degraded missing turn resubmits once or queues a dialog failsafe. A genuine 404 that was never degraded does not.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A degraded begin retains every cached turn field, including prompt, context, metadata, identity, status, timestamps, title, and counters; it never replaces the turn with a reduced three-field object.
- [ ] Prompt-hook status reports durable opened only after confirmed primary persistence; otherwise it reports opened-degraded and identifies the retained recovery artifact without representing the turn as server-persisted.
- [ ] Complete recovers required query text from the cached query text, then a valid cached title, then the approved placeholder, without replacing a valid title; update omits empty query text so stored query text and title are preserved.
- [ ] A missing-turn appendDialog on an already degraded local turn performs at most one bounded recovery submit and then retains a session_dialog failsafe; an unrelated never-degraded not-found remains a classified nonretryable error.
- [ ] A same-request retry supplies preserved creation metadata, normalizes canceled and cancelled supersession consistently, and never silently converts locally active state into proof of server persistence.

## FR-MCP-SESSIONLIFE-002 Durability before verb mode for plan and todo metadata

Resolve durability first. A matching requestId is omit-unbound only when the turn is already durable. Otherwise beginTurn, update, append, and complete use explicit values, then cached values, then exact None. Ordinary raw first persist rejects an omitted pair. canceled and cancelled supersede first persists may omit either field and receive exact None. Durable reopen omits unbound fields. Assert-ReplCurrentTurnFresh does not rewrite a cached session id. Wrong-workspace marker paths and marker drift are rejected. Get-ReplCompleteTurnPersistSessionId stays unchanged.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] First persistence resolves planFile and todoId using explicit request values, then verified cache values, then the exact sentinel None, and stores a non-null pair.
- [ ] Ordinary raw first persistence rejects omitted, null, empty, or whitespace metadata; canceled or cancelled supersession may omit it and stores None, and a durable reopen preserves that omission contract.
- [ ] Explicit metadata updates both cache and outgoing persistence. Omission after binding is allowed only after durable identity is proven for the exact workspace, agent, session, and request.
- [ ] Freshness validation rejects workspace, agent, session, or request drift and never rewrites or rebinds an already cached session identifier from a marker or inherited process value.
- [ ] The three governing contract documents consistently describe explicit/cache/None precedence, ordinary first-persist rejection, canceled/cancelled supersession, and durable-reopen omission.

## FR-MCP-SESSIONLIFE-003 Three session-log persist outcomes

Primary success, or a confirmed retained failsafe as classified queued success that does not claim primary persistence, or neither destination which is a nonzero failure. appendActions refuses a request-id mismatch. A title that reached neither the server nor a failsafe exits nonzero. Primary success for response, interpretation, tags, and contextList requires a query. Repeated unchanged updateTurn does not write a second session_submit. The wrapper object carries code, retryable, persisted, degraded, queued, method, requestId, failsafePath, message, and child stderr.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Every session-log mutation returns exactly one truthful outcome: primary persisted, degraded queued with a confirmed retained failsafe, or failed/lost with a nonzero process result.
- [ ] The result includes code, retryable, persisted, degraded, queued, method, requestId, failsafePath, message, and diagnostic stderr fields appropriate to the observed outcome.
- [ ] Caller requestId is honored only when it matches the active turn; mismatches are rejected without mutating cache, server state, or recovery artifacts.
- [ ] A primary-success result is accepted only with exact server readback of the intended response, interpretation, tags, contextList, actions or dialog, and identity.
- [ ] Repeated unchanged updates and sequential append/complete calls are idempotent: no duplicate recovery work, child rows, or outcome ambiguity is introduced.
- [ ] Write-ahead recovery is retained before backend submission and deleted only after durable confirmation; a queued result is never represented as primary persistence or accepted TODO completion evidence.
- [ ] A dense existing session containing representative turns and every supported child collection accepts a session update inside the five-second storage command budget, or returns one classified retryable outcome inside that budget. A successful retry has exact durable readback and introduces no duplicate or partial child rows.

## FR-MCP-SESSIONLIFE-004 Failsafe replay, child deadline, and contention classification

One child deadline covers asynchronous stdin and stdout and process-tree cleanup. Hook default bound is 30 seconds. Codex failsafe identity stays Codex when PLUGIN_AGENT_NAME or MCP_AGENT_NAME is inherited as Grok. Quarantine files 3358, d5f9, and 9ad7 are repaired, replayed even when drainAttempts is exhausted, and deleted only after durable success. Import recovery scans pending importRecovery yaml, persists a mapped DTO, and deletes only that envelope after persisted true and degraded false. Busy, locked, budget expiry, and wrapped contention are retryable. Connection outage is backend_unavailable. Automatic and explicit drain do not latch completion on contention.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] One bounded child-process deadline, default 30 seconds for the hook operation, covers stdin writes, stdout and stderr reads, wait, cancellation, and process-tree cleanup without a stranded child or premature disposal race.
- [ ] Codex child execution preserves Codex agent identity and workspace-scoped cache ownership even when inherited environment variables identify Grok or another agent.
- [ ] Quarantine repair accepts historical supported shapes through object-first parsing, fills only missing values with None, preserves valid values, and never fabricates identity.
- [ ] Contention and service outage remain distinct classified outcomes; both drain entry points retain retryable work without consuming attempts or latching completion and later replay exactly once. When storage is actually unavailable, health.storage reports unreachable; contention is not mislabeled as storage-down.
- [ ] Import-recovery ingestion accepts a validated canonical session bundle or reconstructs the complete bundle from verified sources, never submits the importRecovery envelope as a session, and preserves all files on failure.
- [ ] Path containment, reparse-point containment, size and count bounds, source identity, and canonical schema are verified before any source or recovery artifact is read or persisted.
- [ ] Partial and canceled replay remains retryable and idempotent; concurrent replay cannot duplicate work; only the exact unchanged recovery artifact is deleted after verified durable persistence.

## FR-MCP-SESSIONLIFE-005 Stop hook stale pin and session-log uniqueness

Stop hook runs failed-build and incomplete-audit gates first. It allows a stale pin only when authoritative server completion shows the local request id is not the active turn. A genuinely active different request id is not cleared. Both timestamp and lastUpdated stale is the age case. A fresh lastUpdated alone must not pass a stale pin. BUG-TRIAGE-229 is predecessor-schema detection before save, classified provider text in details.inner, and one bounded uniqueness retry.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Failed-build and incomplete-audit enforcement executes before any stale-pin allow, timestamp refresh, auto-close, or recovery that could bypass those gates.
- [ ] A stale local in_progress turn is reconciled only by authoritative Completed proof for the exact workspace, agent, session, and request; active, missing, ambiguous, or unavailable proof fails closed and retains state.
- [ ] Old, fresh, missing, and invalid timestamp and lastUpdated combinations, completed or missing local files, and mismatched request IDs are covered; recency alone never proves completion.
- [ ] Schema-predecessor failures are detected before mutation and provider errors retain a classified details.inner diagnostic without leaking credentials.
- [ ] One bounded retry applies only to the known unique same-session/request race; the winner is reread and merged without duplicate children or loss of unrelated state, while unrelated failures and cancellation propagate.

## FR-MCP-SESSIONLOGCTX-001 Session turns record current plan file and MCP TODO id

Every session-log turn SHALL store planFile and todoId. After persist, query/get SHALL return both fields. They are never null in API output. When no plan or TODO is active, the stored value SHALL be the exact sentinel None (case-sensitive). The first persist of a turn SHALL reject omitted, null, empty, or whitespace planFile or todoId. planFile SHALL accept a workspace-relative path, an exact absolute path, or a ~/ home-relative path. .. is rejected. Query SHALL support exact filters on planFile and todoId, and text search SHALL match those fields. Existing rows SHALL be backfilled from turn contents and agent history under ~. Import, transcript ingest, and federation apply SHALL persist a validated pair (None if extraction finds nothing). Children: AC-FR-MCP-SESSIONLOGCTX-001-001, AC-FR-MCP-SESSIONLOGCTX-001-002, AC-FR-MCP-SESSIONLOGCTX-001-003, AC-FR-MCP-SESSIONLOGCTX-001-004, AC-FR-MCP-SESSIONLOGCTX-001-005, AC-FR-MCP-SESSIONLOGCTX-001-006, AC-FR-MCP-SESSIONLOGCTX-001-007.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Every session-log turn SHALL store planFile and todoId. After persist, query/get SHALL return both fields. They are never null in API output.
- [ ] When no plan or TODO is active, the stored value SHALL be the exact sentinel None (case-sensitive).
- [ ] The first ordinary persist of a turn SHALL reject omitted, null, empty, or whitespace planFile or todoId and insert no turn row. A canceled or cancelled supersession may omit the pair, stores the exact sentinel None for each missing value, and a durable reopen preserves that bounded exception.
- [ ] planFile SHALL accept a workspace-relative path, an exact absolute path, or a ~/ home-relative path. .. is rejected.
- [ ] Query SHALL support exact filters on planFile and todoId, and text search SHALL match those fields.
- [ ] Existing rows SHALL be backfilled from turn contents and agent history under ~. Uncertain results stay None. Invented ids/paths are forbidden.
- [ ] Import, transcript ingest, and federation apply SHALL persist a validated planFile and todoId (None if extraction finds nothing). Null is never stored.

## FR-MCP-SESSIONLOGSAN-001 Sanitized session-log read responses

Session-log query and single-session read responses must redact built-in credential forms and workspace-configured regular-expression matches before data leaves the server while preserving the raw persisted session log.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Query and single-session GET responses redact secrets from session metadata, turns, actions, processing dialog, contexts, files, blockers, requirements, commits, raw context, and original entry payloads.
- [ ] Stored entities and submitted DTOs remain unchanged; sanitization is an outbound projection only.
- [ ] Default credential detectors are active without custom configuration and custom workspace rules may add bounded regex matches.
- [ ] Filtering, total count, ordering, offset, and limit are computed from raw data and remain unchanged after redaction.
- [ ] Federated and stdio read surfaces apply the same sanitization behavior.

## FR-MCP-STRICTCOUNT-001 updateTurn accepts omitted empty or scalar tags and contextList under StrictMode

workflow.sessionlog.updateTurn succeeds when tags or contextList is omitted, empty, or a single scalar. Invoke-McpPlugin exits 0. No StrictMode Count throw. Success stdout stays silent. BUG-TRIAGE-158.
- [ ] omitted/empty/scalar tags and contextList persist
- [ ] exit 0 and no Count cannot be found
- [ ] appendActions/updateTurn emit no boolean on success
Scope: layer-1+
**Acceptance Criteria:**
- [ ] omitted/empty/scalar tags and contextList persist
- [ ] exit 0 and no Count cannot be found
- [ ] appendActions/updateTurn emit no boolean on success

## FR-MCP-SUBLOG-001 Subscriber high-performance message logging

The transaction subscriber SHALL log every received transaction message (commit and abort outcomes) to a high-performance log store (Parseable) when configured, capturing transaction id, event, reason, status, manifest and encrypted-body hashes, diffgram id, and party ids; logging is best-effort and SHALL never block or fail the commit path on sink errors.
Scope: layer-1+
**Acceptance Criteria:**
- [x] A pluggable ISubscriberMessageLog seam exists with a no-op default and a Parseable HTTP sink.
- [x] The Parseable sink POSTs a flat JSON batch to the ingest endpoint with the X-P-Stream header and basic auth.
- [x] The subscriber emits one message-log entry per received message at the audit chokepoint, independent of the durable audit gate.
- [x] Sink transport errors are swallowed and never break the transaction.

## FR-MCP-TEMPVOL-001 Plugin wrappers align TEMP to the workspace volume

Plugin session-start and wrapper entrypoints set TEMP and TMP to a writable directory on the workspace volume when they differ from the target volume. Prompt-template guidance stays. Failed replacement moves must not look like success. Do not patch PSGallery PowerShell.MCP. BUG-TRIAGE-117.
- [ ] TEMP/TMP on workspace volume when workspace is not on TEMP drive
- [ ] templates still document same-volume TEMP and verify-after-edit
- [ ] failed move is a visible error
Scope: layer-1+
**Acceptance Criteria:**
- [ ] TEMP/TMP on workspace volume when workspace is not on TEMP drive
- [ ] templates still document same-volume TEMP and verify-after-edit
- [ ] failed move is a visible error

## FR-MCP-TESTRESOURCE-001 Repository-independent test fixtures and outputs

Fixture inputs must be packaged as test-project resources and generated test artifacts must use test-owned output locations, without depending on the repository root. Tests that intentionally verify live repository or sibling plugin source may read those sources as their subject.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Fixture inputs for applicable tests are packaged as resources in their owning test projects and load without using a checkout-root path.
- [ ] Generated test artifacts are written only to test-owned disposable output locations, not to repository fixture or documentation paths.
- [ ] Tests whose subject is the live repository or sibling plugin source retain their real-source integrity checks; the no-repo-path rule does not replace those checks with synthetic fixtures.

## FR-MCP-TODO-CLOSE-001 Close TODO item by ID

Users and agents can close a TODO item with a single ID-scoped operation that marks the item complete and records the completion timestamp.
Scope: layer-1+
**Acceptance Criteria:**
- [x] A REST endpoint accepts a TODO ID without requiring the caller to resubmit the full TODO update payload. (evidence: TodoController.CloseAsync POST /mcpserver/todo/{id}/close covered by TodoControllerTests.CloseAsync_WhenItemExists_SetsDoneAndCompletedDate.)
- [x] Closing an open TODO sets the item status to DONE by setting done true and records a non-empty completion timestamp. (evidence: TodoControllerTests.CloseAsync_WhenItemExists_SetsDoneAndCompletedDate asserts done true and UTC completedDate.)
- [x] Closing a missing TODO returns the existing not-found mutation failure behavior. (evidence: TodoControllerTests.CloseAsync_WhenItemMissing_ReturnsNotFound.)
- [x] The typed client exposes the same close-by-id operation. (evidence: TodoClientTests.CloseAsync_PostsCorrectUrl.)

## FR-MCP-TRANSCRIPT-001 Transcript source ingestion

The system shall ingest agent transcript bundles from supported source formats with deterministic source detection and diagnostics.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Auto detection identifies exactly one supported source or rejects ambiguous and unsupported input with diagnostics. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by TranscriptCorePipelineTests.Detector_DiscoversEverySupportedRealTranscriptSource and RealTranscriptFixtureIntegrationTests.RealTranscriptManifestCoversEveryAgent.)
- [x] Folder, multipart, and ZIP ingestion discover independent session bundles without mixing sessions. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by SessionLogTranscriptIngestionControllerTests.IngestUploadAsync_MixedZipBundleReturnsMultiStatusWhenStrictFalse, IngestUploadAsync_ZipClaudeFixturePersistsAndDeletesStagingRun, and controller path/upload tests.)

## FR-MCP-TRANSCRIPT-002 Faithful loss-aware normalization

The system shall normalize supported transcripts into a neutral event model without silently discarding malformed, unknown, partial, or unpaired records.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Native identity, ordering, timestamps, roles, content blocks, reasoning, tool calls/results, usage, failures, workspace metadata, subagents, and provenance are preserved when present. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by IngestionService_NormalizesRealTranscriptFixtures and RealJsonlFixturesContainProviderSpecificEvents across Claude, Codex, Grok, Cline, Copilot, and OpenCode fixtures.)
- [x] Missing semantic values remain absent and derived required IDs are deterministic and explicitly marked. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by unsupported/malformed/incomplete diagnostics tests including IngestionService_CodexUnsupportedRecordsEmitDiagnostics, ClineMalformedMessagesEmitDiagnostics, and OpenCodeJsonlIncompleteStepEmitsDiagnostic.)

## FR-MCP-TRANSCRIPT-003 Canonical session log projection

The system shall project neutral transcript events directly into canonical Session Log YAML using the existing session-log serializer and model.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Canonical Session Log YAML is produced directly from neutral events through the existing session-log serializer/model. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by IngestionService_NormalizationWritesArtifactsWithoutSessionPersistence, IngestionService_PersistWritesRunArtifactsAndPendingFailsafeEnvelope, and TranscriptSessionLogPersisterTests.PersistAsync_SubmitsUnifiedSessionLogThroughSessionLogService.)
- [x] Compatibility profile output is optional and caller-selected for Claude, Codex, or Grok. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by IngestionService_EmitsCompatibilityJsonlWhenProfileRequested and Repl.Core NormalizeTranscripts tests.)

## FR-MCP-TRANSCRIPT-004 Idempotent import and recovery

The system shall import transcript-derived Session Log YAML through the existing persistence path with write-ahead recovery and idempotent replay.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Repeated imports use deterministic idempotency data and persist through the existing session-log path. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by TranscriptSessionLogPersisterTests.PersistAsync_SubmitsUnifiedSessionLogThroughSessionLogService and HTTP ingest path persistence tests.)
- [x] A failsafe importRecovery envelope is retained unless persistence explicitly reports persisted=true and degraded=false. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by IngestionService_PersistWritesRunArtifactsAndPendingFailsafeEnvelope, IngestionService_PersistNamesFailsafeDocumentsByRootIdWithoutOverwrite, and TEST-MCP-REPL-025 plugin Pester failsafe tests.)

## FR-MCP-TRANSCRIPT-005 Model-owned session log writing for Claude Codex Grok

Claude, Codex, and Grok models shall write MCP Session Log entries themselves through the normal session-log APIs; plugins shall not expose transcript ingestion or normalization endpoints, helpers, skills, or parser forks.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Claude, Codex, and Grok plugins expose no transcript ingestion or normalization helper, skill, endpoint shortcut, or parser fork. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by plugin Pester TEST-MCP-TRANSCRIPT-010 does not expose transcript ingestion endpoints through plugins and removes legacy Codex JSONL parser helpers.)
- [x] Models continue to write session-log turns, actions, decisions, and completions through the existing workflow.sessionlog tools instead of relying on automatic transcript ingestion. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by plugin Pester marker prompt/sessionlog tests and live Codex turn req-20260711T022759Z-prompt-c4f0 using workflow.sessionlog appendActions/appendDialog/CompleteTurn path.)

## FR-MCP-TRANSCRIPT-006 HTTP path and upload ingestion

The system shall expose HTTP transcript ingestion for allowlisted server-local files/folders, multipart uploads, multi-file uploads, and ZIP uploads.
Scope: layer-1+
**Acceptance Criteria:**
- [x] POST /mcpserver/sessionlog/ingest/path accepts allowlisted file and folder paths and rejects unauthorized paths. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by IngestPathAsync_WorkspaceRelativeCodexFixturePersistsAndDeletesFailsafe, IngestPathAsync_RealFixtureForEachAgentNormalizesThroughHttp, and unauthorized path tests.)
- [x] POST /mcpserver/sessionlog/ingest/upload accepts multipart files and ZIP bundles within documented limits. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by IngestUploadAsync_ZipClaudeFixturePersistsAndDeletesStagingRun, IngestUploadAsync_RejectsDuplicateZipPaths, and controller ZIP traversal tests.)

## FR-MCP-TRANSCRIPT-007 REPL and MCP ingestion parity

The system shall expose transcript ingestion and normalization through typed client, REPL, and native MCP tools with equivalent behavior.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Typed client and REPL expose equivalent ingest and normalize operations. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by SessionLogClientTests.IngestTranscriptPathAsync_PostsPathContract, IngestTranscriptUploadAsync_PostsMultipartUploadContract, and Repl.Core transcript workflow/dispatcher tests.)
- [x] MCP calls retain required workspacePath while hosted and REPL agents resolve workspace ownership from their bound client. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by TranscriptMcpToolTests.SessionLogIngestPath_DelegatesWorkspaceBoundRequest, SessionLogNormalizePath_DelegatesProfileProjectionWithoutPersistenceByDefault, and McpTransport transcript tool tests.)

## FR-MCP-TRANSCRIPT-008 Secondary provider normalization

The system shall normalize Cline, Copilot, and OpenCode transcripts and native stores into canonical Session Log YAML and optional Claude, Codex, or Grok compatibility JSONL.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Cline paired JSON/JSONL, Copilot event folders, and OpenCode JSONL/SQLite snapshots normalize into canonical Session Log YAML. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by IngestionService_NormalizesRealTranscriptFixtures, OpenCodeSqliteTranscriptTests, and real manifest coverage for Cline, Copilot, and OpenCode.)
- [x] Secondary sources can emit optional Claude, Codex, or Grok compatibility JSONL without reparsing it for canonical YAML. (evidence: Current validation 2026-07-10 21:33-21:37 CDT: Support.Mcp transcript unit 60 passed/0 failed/0 skipped; Support.Mcp transcript integration+McpTransport 22/0/0; Repl.Core transcript 4/0/0; Client IngestTranscript 2/0/0; clean plugin Pester 47/0/0. Covered by IngestionService_EmitsCompatibilityJsonlWhenProfileRequested and Repl.Core normalization profile tests.)

## FR-MCP-TRANSCRIPT-009 Transcript ingestion size ceilings raised to Int32.MaxValue

Transcript ingestion must accept transcript sources whose per-file size, per-JSONL-line size, record count, upload request size, and expanded archive size are bounded only by Int32.MaxValue (2,147,483,647). Operators ingesting large agent transcripts (notably Claude Code JSONL, where a single line can carry a full tool result) must not be rejected by the previous 256 MiB per-file, 8 MiB per-line, 2,000,000-record, 512 MiB request, or 2 GiB expanded-content ceilings. Guards that defend against hostile archives rather than large transcripts are retained unchanged: archive entry count, compression ratio, ZIP symlink rejection, and path-traversal rejection. Supersedes the ceiling values asserted by FR-MCP-TRANSCRIPT-002 and TR-MCP-TRANSCRIPT-001; the bounded-reader obligation itself is unchanged, only the bound values move.
Scope: layer-1+

## FR-MCP-TRANSCRIPT-SEARCH-001 Codex transcript adapter handles tool_search and inter_agent records

Ingesting Codex JSONL with inter_agent_communication_metadata, tool_search_call, and tool_search_output produces zero unknown diagnostics for those types, emits paired tool events or a documented info skip, and a successful Persist=true ingest deletes importRecovery with persisted=true degraded=false. BUG-TRIAGE-122.
- [ ] inter_agent_communication_metadata is normalized or documented info skip
- [ ] tool_search_call/output become paired events with call_id/name/status
- [ ] successful persist deletes importRecovery
Scope: layer-1+
**Acceptance Criteria:**
- [ ] inter_agent_communication_metadata is normalized or documented info skip
- [ ] tool_search_call/output become paired events with call_id/name/status
- [ ] successful persist deletes importRecovery

## FR-MCP-TRIAGE-001 Fire-and-forget triage intake

Agents can submit workspace-scoped incidental bug reports without leaving their current task.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] REST, client, REPL, and plugin tool paths all accept the same report contract.
- [ ] Intake persists the report and returns reportId, groupId, status, and quietDeadlineUtc.
- [ ] Intake does not run research or create a TODO synchronously.

## FR-MCP-TRIAGE-002 Async triage grouping and research

Related reports are grouped, MCP Server and MCP Server plugin reports are routed to the registered McpServer workspace when it exists, and groups are researched asynchronously and converted to TODOs.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Groups are deterministic and workspace-isolated.
- [ ] New matching reports reset the 15-minute quiet window.
- [ ] A configured triage agent receives group JSON plus rendered prompt and must return schema-valid JSON.
- [ ] Valid output creates one BUG-TRIAGE-### backlog TODO; invalid output creates no TODO and exposes failure status.
- [ ] MCP Server core and MCP Server plugin bugs are grouped into the registered McpServer workspace when that workspace exists; otherwise they stay in the submitting workspace.

## FR-MCP-TRIAGE-003 REPL triage parity

The REPL exposes the complete triage surface through client passthrough and typed workflow wrappers.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] client.triage.* works through generic passthrough after adding McpServerClient.Triage.
- [ ] workflow.triage.* routes through typed workflow classes and returns deprecated metadata consistent with existing workflow namespaces.
- [ ] YAML validation, error envelopes, and request/response shapes are covered.

## FR-MCP-TRIAGE-004 Plugin triage skills

All plugin distributions teach agents when and how to use triage.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Each plugin skill bundle includes triage guidance.
- [ ] Skills say to use triage for incidental bugs, not for the user active requested fix.
- [ ] Skills explicitly say not to expect immediate resolution and to continue the current task after submission.

## FR-MCP-TRIAGEERR-001 Normalized error envelope for REST, MCP, REPL, and plugins

Every failure on REST /mcpserver/*, MCP tools, REPL workflow errors, and plugin shims returns a machine-readable envelope with code, message, retryable, and optional details so plugins and Agent Help can branch on code without scraping prose. Innermost EF or provider text lives in details.inner.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Every failure on REST /mcpserver/*, MCP tools, REPL workflow errors, and plugin shims returns a machine-readable envelope with code, message, retryable, and optional details so plugins and Agent Help can branch on code without scraping prose. Innermost EF or provider text lives in details.inner.

## FR-MCP-TRIAGEHELP-001 Agent Help is diagnosis or incomplete never completed echo

Agent Help turns are either a FINAL ANSWER diagnosis or an incomplete or error status. Progress-only plan narration is not a completed diagnosis. CLI failure, timeout, or unavailability does not complete via UseEchoHelperFallback. workflow.agenthelp.submitTurn waits at least HelperTimeout.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Agent Help turns are either a FINAL ANSWER diagnosis or an incomplete or error status. Progress-only plan narration is not a completed diagnosis. CLI failure, timeout, or unavailability does not complete via UseEchoHelperFallback. workflow.agenthelp.submitTurn waits at least HelperTimeout.

## FR-MCP-TRIAGEPLUGIN-001 Plugin root session, cache, console, and persist identity

Root UserPromptSubmit stays on the root session while background agents run. Plugin cache replacement does not break in-flight hooks or reports named version-drift. New PowerShell consoles inherit workspace identity from hook payload. beginTurn Submit timeout is degraded or queued with failsafe retained. completeTurn survives sessionId rebind without leftover failsafe.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Root UserPromptSubmit stays on the root session while background agents run. Plugin cache replacement does not break in-flight hooks or reports named version-drift. New PowerShell consoles inherit workspace identity from hook payload. beginTurn Submit timeout is degraded or queued with failsafe retained. completeTurn survives sessionId rebind without leftover failsafe.

## FR-MCP-TRIAGEREQ-001 listTr ids are getTr updateTr deleteTr able

Every TR id returned by listTr is retrievable and mutable via getTr, updateTr, and deleteTr. createTr and batch create still reject non-canonical TR ids.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Every TR id returned by listTr is retrievable and mutable via getTr, updateTr, and deleteTr. createTr and batch create still reject non-canonical TR ids.

## FR-MCP-TRIAGESCHEMA-001 SessionLogs missing AgentSession columns fail closed

After host start, sessionlog query never fails with SQL Invalid column name for AgentSessionId, AgentSessionTranscriptFile, AgentExecutablePath, or AgentExecutableVersion. Missing schema fails closed as pending-migration. Provider migrations apply the four columns on every host workspace database: Sqlite 20260818205751_AddSessionLogTagsAndAgentSessionHeaders, SqlServer 20260818205807_AddSessionLogTagsAndAgentSessionHeaders, Postgres 20260818205822_AddSessionLogTagsAndAgentSessionHeaders.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] After host start, sessionlog query never fails with SQL Invalid column name for AgentSessionId, AgentSessionTranscriptFile, AgentExecutablePath, or AgentExecutableVersion. Missing schema fails closed as pending-migration. Provider migrations apply the four columns on every host workspace database: Sqlite 20260818205751_AddSessionLogTagsAndAgentSessionHeaders, SqlServer 20260818205807_AddSessionLogTagsAndAgentSessionHeaders, Postgres 20260818205822_AddSessionLogTagsAndAgentSessionHeaders.

## FR-MCP-TRIAGESTORE-001 Session-log persist is diagnosable and idempotent

Session-log persist is diagnosable and idempotent on identical action resubmit. Session tags persist and round-trip on query. replace_turn for a missing turn is 404. canceled and cancelled are queryable terminal statuses. Superseded hook turns persist canceled with planFile and todoId None sentinels and no opaque 500.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Session-log persist is diagnosable and idempotent on identical action resubmit. Session tags persist and round-trip on query. replace_turn for a missing turn is 404. canceled and cancelled are queryable terminal statuses. Superseded hook turns persist canceled with planFile and todoId None sentinels and no opaque 500.

## FR-MCP-TRIAGESTORE-002 Storage-only outages fail fast without flipping health liveness

Session-log and triage mutating calls fail within about 5 seconds with a classified storage-unavailable error when SQL is unreachable. GET /health remains process-live and echoes nonce. Failsafe stays queued. After restore the next mutate succeeds.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Session-log and triage mutating calls fail within about 5 seconds with a classified storage-unavailable error when SQL is unreachable. GET /health remains process-live and echoes nonce. Failsafe stays queued. After restore the next mutate succeeds.

## FR-MCP-TRIAGETODO-001 EXEC dual-store rehydrate and retry-clean plan create

set_todo_test_plan rehydrates from a durable EXEC-TODO when execution-state is missing that row. create_todos_from_plan is retry-clean, accounts for soft-deleted ids, and never returns only the bare EF outer DbUpdateException message.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] set_todo_test_plan rehydrates from a durable EXEC-TODO when execution-state is missing that row. create_todos_from_plan is retry-clean, accounts for soft-deleted ids, and never returns only the bare EF outer DbUpdateException message.

## FR-MCP-USECASE-001 CRUD workspace-scoped use cases

The server shall support create, read, update, and soft-delete of workspace-scoped use cases with header fields: title, brief description, precondition, postcondition, scope, and priority. Default queries exclude soft-deleted rows. Multi-tenant isolation via WorkspaceId is required.
Scope: layer-1+

## FR-MCP-USECASE-002 Actors, flows, and ordered steps

Use cases support actors (Primary, Secondary, System, External), flows (Basic, Alternative, Exception) with sequence numbers, and ordered steps with action text and optional system response and data entities.
Scope: layer-1+

## FR-MCP-USECASE-003 Bidirectional UC to FR links with Realizes default

Use cases link bidirectionally to functional requirements using string FR ids. Default link type is Realizes. Active links are unique per workspace, use case, and FR. Unlink is soft-delete of the link row.
Scope: layer-1+

## FR-MCP-USECASE-004 Create use case from FR

Operators and agents can create a shell use case from an existing FR title/body with an automatic Realizes link.
Scope: layer-1+

## FR-MCP-USECASE-005 Diagram generation Mermaid primary

Two diagram kinds: (a) sequence from flows/steps; (b) UML use-case from persisted graph. Mermaid primary; PlantUML supported. Sequence is not a substitute for the use-case canvas editor.
Scope: layer-1+

## FR-MCP-USECASE-006 UC FR Realizes coverage API

A runtime coverage API reports use cases without Realizes FR links and FRs without Realizes use case links for the active workspace.
Scope: layer-1+

## FR-MCP-USECASE-007 First-party Use Case UI

First-party UI via REST. Primary diagram UI is UML use-case drag-and-drop canvas (FR-011). Structure forms secondary. Sequence render separate.
Scope: layer-1+

## FR-MCP-USECASE-008 Use case versioning and approval

Draft/Submitted/Approved/Rejected; version increments on Approve.
Scope: layer-1+
Acceptance: Approve increments VersionNumber; invalid status rejected.
Scope: layer-1+

## FR-MCP-USECASE-009 Product membership hooks

Optional ProductKey and list-by-product (hooks only).
Scope: layer-1+
Acceptance: set/clear ProductKey; list-by-product returns matches.
Scope: layer-1+

## FR-MCP-USECASE-010 Traceability integration for UC-FR Realizes

Shared Realizes algorithm; USECASE FR/TR/TEST IDs in docs matrix.
Scope: layer-1+
Acceptance: Shared algorithm tests; ValidateTraceability green for USECASE IDs.
Scope: layer-1+

## FR-MCP-USECASE-011 UML use-case canvas editor

Palette + free canvas + drag-and-drop UML use-case diagram editor (actors, use-case ovals, system boundary, association, include, extend). Classic UML editor interaction; not form-only.
ACs: AC-011-1 palette; AC-011-2 place shapes; AC-011-3 association; AC-011-4 include/extend; AC-011-5 rename; AC-011-6 move+layout persist; AC-011-7 boundary; AC-011-8 canvas primary UI; AC-011-9 REST only.
Scope: layer-1+

## FR-MCP-USECASE-012 Persist use-case diagram graph

Workspace-scoped graph (nodes, edges, layout) saved and loaded for a use case; soft-delete and validation. ACs AC-012-1 through AC-012-6 including audit on put.
Scope: layer-1+

## FR-MCP-USECASE-013 Export diagram to Mermaid

Persisted graph exports deterministic Mermaid per mcp-usecase-diagram-schema:1. ACs AC-013-1 through AC-013-4.
Scope: layer-1+

## FR-MCP-USECASE-014 Export diagram to PlantUML

Same graph exports PlantUML use-case syntax. ACs AC-014-1 through AC-014-3.
Scope: layer-1+

## FR-MCP-USECASE-015 BUG-TRIAGE-139 fourteenth-review safe durable remediation

Use-case creation and its supporting workspace, federation, requirements-export, timeout, and repository-evidence paths shall preserve one canonical ASCII-normalized durable identity, resist filesystem races through handle-relative contained mutation, remain physically bounded and cancellable, preserve exact provider state and real failures, reject blocking special files, and produce hermetic truthful evidence without regressing previously approved controls.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Persisted workspace, federation, and creation-receipt identifiers normalize Unicode dash variants to canonical ASCII before hashing, and replay is idempotent on SQLite, SQL Server, and PostgreSQL.
- [ ] Requirements rollback deletion, restoration writes, replacement, and directory creation are relative to pinned contained directory handles so concurrent junction or reparse swaps cannot affect objects outside the workspace.
- [ ] Mapped-drive and UNC physical identity resolution used by saves and federation upserts is asynchronous, cancellable, finite, and leaves no abandoned workers or repeated uncancellable probes.
- [ ] Requirements snapshots reject or nonblockingly inspect FIFO, device, socket, and other non-regular entries while preserving explicit file, byte, aggregate, depth, and cancellation limits.
- [ ] SQLite federation work restores exact managed, EF, connection-string, native busy-timeout, and busy-handler state across success, failure, cancellation, disposal, pooling modes, and repeated calls.
- [ ] SQLite connection opening is bounded before and after native-handle creation, cancel-before-handle and close/dispose races do not leak workers or handles, and native interruption is scoped to the active operation.
- [ ] SQLite, SQL Server, and PostgreSQL preserve genuine provider exceptions that coincide with cancellation and convert only genuine provider cancellation to OperationCanceledException.
- [ ] Repository evidence tests discover the repository from true external artifact directories without environment injection and bound stdout/stderr drain while killing descendant process trees that inherit pipes.
- [ ] Fourteenth receipts map exact commands to outputs, distinguish completed failures from aborted or inconclusive runs, supersede inaccurate twelfth claims explicitly, and carry an independently verified SHA-256 inventory.
- [ ] All previously approved controls remain covered and complete current-plus-prior provider, repository, release-build, compile, test, and traceability gates finish with zero failures and zero skips.

## FR-MCP-USECASE-016 BUG-TRIAGE-139 fifteenth-review bounded cross-platform remediation

Use-case persistence and its supporting contained rollback, physical workspace identity, SQLite opening, cancellation classification, and repository evidence paths shall remain safe and finitely completing on every supported platform, including deterministic CI builds, while preserving exact provider failures and truthful supersession evidence.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Linux rollback directories retain owner search and execute permission, nested restoration reproduces file contents and mode, and all mutations remain contained.
- [ ] Physical workspace identity resolution completes within a finite bound on Windows and non-Windows without caller-thread blocking, cancellation gaps, abandoned workers, or silent platform returns.
- [ ] SQLite connection opening is finitely bounded before native-handle publication on every supported platform and leaves no worker, handle, callback, interrupt, pool, or lifecycle leak.
- [ ] Only outcomes precisely attributable to requested cancellation become OperationCanceledException; independent I/O, disposal, and provider failures retain their original type and details.
- [ ] Repository and Agent Help fixtures discover their root from true external deterministic builds with mapped CallerFilePath and no MCP_REPOSITORY_ROOT override.
- [ ] Every supported platform executes an applicable native contract assertion; platform-specific tests neither skip nor silently return.
- [ ] The rejected fourteenth receipt is preserved with an explicit supersession notice, and the fifteenth evidence records every failed, inconclusive, and passing run with independently verified hashes and command mappings.

## FR-MCP-USECASE-017 BUG-TRIAGE-139 sixteenth-review race-safe bounded remediation

Use-case persistence and its filesystem, provider, process, platform-test, and evidence boundaries shall close physical alias and replacement races, complete publicly within finite contracts, preserve truthful worker and provider causality, execute applicable native contracts, and report only exact immutable evidence while retaining every previously approved control.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Physical workspace identity rejects safe lexical paths whose physical target is on an unsafe mount, remains safe across symlink or mount replacement timing, completes publicly within its deadline, and reports any unstoppable worker as active until it actually exits.
- [ ] SQLite data-source validation and pre-handle opening resist safe-link and check-to-open replacement, use no ineffective Thread.Interrupt dependency for native Linux I/O, finish cleanup within a finite deadline, and preserve exact lifecycle, handle, worker, and exception state.
- [ ] PostgreSQL SQLSTATE 57014 is translated to caller cancellation only with causal evidence produced by the caller-triggered cancellation mechanism; statement timeout and administrative cancellation remain PostgresException even during concurrent token cancellation.
- [ ] Platform-specific tests are discovered or composed only where applicable, prove real execution and inventory counts, and never pass through source inspection, skip, silent return, abort, inconclusive outcome, or a below-minimum count.
- [ ] Containment race coverage requires at least one successful contained read and write while proving no escape or corruption, and deterministic total-rejection tests prove that rejecting every attempt cannot satisfy the success gate.
- [ ] Windows descendant cleanup establishes containment at process creation or proves an equivalent race-free boundary before descendants can escape, and timeout or cancellation terminates immediate descendants finitely without regressing non-Windows process-group cleanup.
- [ ] Historical rejected receipts remain intact but are explicitly superseded; final evidence identifies the exact immutable tested SHA, contains executable commands or a mechanically complete ledger, independently reconciles hashes, mappings and totals, and limits conclusions to the proven local and retained-evidence boundary.
- [ ] All current and prior requirements pass focused and cumulative Windows, native Linux/FUSE/non-root, SQLite, LocalDB, fresh PostgreSQL, deterministic external, BDPv4, build, traceability, Release, repository, history, harness, and EOL gates from C:-physical outputs with exact zero failures and zero skips.

## FR-MCP-USECASE-018 Edit existing use-case actors, flows, and steps in place

Operators and agents shall edit actor, flow, and step records through supported authenticated operations while preserving the existing component identities and parent relationships.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A supported authenticated operation updates an actor already associated with a use case, preserves ActorId and UseCaseId, and returns the changed name, description, type, and IsPrimary values.
- [ ] A supported authenticated operation updates an existing flow in its parent use case, preserves FlowId and UseCaseId, and returns the changed FlowType, Name, and SequenceNumber values.
- [ ] A supported authenticated operation updates an existing step in its parent flow and use case, preserves StepId and FlowId, and returns the changed StepNumber, ActorId, Action, SystemResponse, and DataEntities values.
- [ ] Component updates reject missing, soft-deleted, cross-workspace, and parent-mismatched IDs without changing any row or creating duplicates.
- [ ] Updating actors, flows, or steps leaves the use case approval status, version, links, unrelated actors, unrelated flows, and unrelated steps unchanged while advancing only the aggregate update timestamp.

## FR-MCP-VERIFYWRAP-001 Code-verify reports disk-full and honors timeout without hanging

code-verify.ps1 reports a typed disk-capacity failure instead of an unhandled WriteAllText when the workspace drive is full, and preserves current-turn audit state. Each invocation completes or fails within its documented timeout and does not occupy the console after the child build exits. BUG-TRIAGE-125, BUG-TRIAGE-130.
- [ ] IOException disk full is typed and current-turn remains valid
- [ ] wrapper returns or fails within documented timeout
- [ ] no indefinite in-process hang after child dotnet exits
Scope: layer-1+
**Acceptance Criteria:**
- [ ] IOException disk full is typed and current-turn remains valid
- [ ] wrapper returns or fails within documented timeout
- [ ] no indefinite in-process hang after child dotnet exits

## FR-MCP-WIKIEXPORT-001 Configurable requirements wiki export tree

Requirements wiki export must optionally discover docs/wiki.yaml in the active workspace and use it as the authoritative wiki document tree, navigation tree, optional home template, and flattened document list for GitHub and Azure wiki exports while preserving current output when the file is absent.
Scope: layer-1+
**Acceptance Criteria:**
- [x] When docs/wiki.yaml is absent, GenerateWikiAsync produces the same canonical Home, requirements documents, manifests, GitHub _Sidebar.md and _Footer.md, and Azure .order output as before.
- [x] When docs/wiki.yaml is present, the documents collection is the complete flattened export list and every navigation document reference must resolve to exactly one declared document.
- [x] Declared documents can use generated requirement sources and workspace-relative Markdown source files, and their target paths are written under each eligible platform output folder.
- [x] The optional home template renders generatedAtUtc, navigation, and documents tokens; absent home templates fall back to a generated home page derived from the navigation tree.
- [x] Platform filters control whether declared documents appear in GitHub, Azure, or both, and generated manifests list only files exported for that platform.
- [x] Invalid docs/wiki.yaml content fails with actionable validation errors before any export file is modified.
- [x] GitHub sidebar and Azure order files are generated from the complete navigation tree, including nested folder navigation.

## FR-MCP-WIKIEXPORT-002 Default wiki export configuration during marker generation

When MCP Server writes a workspace marker file, it must also create a default docs/wiki.yaml if the workspace does not already provide one, so wiki export has an explicit document tree for future GitHub and Azure exports.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Marker generation creates docs/wiki.yaml under the workspace root when that file is absent.
- [x] Marker generation leaves an existing docs/wiki.yaml byte-for-byte unchanged.
- [x] The default wiki.yaml uses schema mcp-wiki-export/v1 and declares a complete flattened document list for generated home, functional, technical, testing, mapping, and matrix documents.
- [x] The default navigation tree references every declared document exactly once and is valid for both GitHub and Azure wiki export.
- [x] The generated default config is written through object serialization, not line-based YAML construction.

## FR-MCP-WIKIEXPORT-003 Optional wiki export JSON dump

Optional --include-dump on wiki export emits versioned JSON dump of MCP tables keyed by source workspace, including TODO rows and requirement links. No-flag behavior is unchanged.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Without flag, export is byte-equivalent to current wiki zip/tree behavior (no dump file). (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] With flag, dump has schemaVersion, exportedAtUtc, sourceWorkspaceKey, sourceWorkspacePath, tables[], todos[], todoRequirementLinks[], SHA-256 hashes, diagnostics. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Dump TODO rows and requirement links match store query for that workspace. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] The dump policy registry covers every live McpDbContext DbSet and fails when model and registry differ. Output excludes unrelated workspace rows and global secrets. Scalar, nested JSON, headers, encoded textual payloads, diagnostics, prompts, outputs, commands, and free text are sanitized in the outbound projection without mutating stored rows. Integrity hashes are computed over the final canonical UTF-8 bytes after redaction. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-MCP-WIKIEXPORT-004 add-workspace dump hydration

add-workspace --dump on WorkspaceClient.CreateAsync / POST /mcpserver/workspace hydrates TODOs from dump, remaps workspace identity, rejects malformed dumps with no partial write.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Hydrated TODOs come from dump rows. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Old source workspace IDs and paths do not appear in destination operational ownership, authorization, routing, active-process, replay, lease, executable-owner, or operational foreign-key columns. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Malformed dump, version mismatch, missing tables, unsafe path: rejected, no partial write. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] An identical durable receipt is resolved before active-workspace duplicate rejection and before fresh-import filesystem-collision rules. Workspace registration and all hydrated database rows commit in one transaction. Cancellation or failure before commit leaves no workspace or imported domain row. Projection, workspace initialization, marker creation, process start, and change notification occur only after commit. A post-commit failure remains CommittedPendingActivation or ActivationFailed and is durably resumable. An existing nonempty repository checkout is a valid destination. Every pre-existing repository and user file is preserved. Only conflicting service-owned generated/output paths block or defer activation. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Immutable non-operative import provenance may retain the original source workspace ID/path, is explicitly historical, and cannot participate in destination authorization, routing, replay, ownership, or execution. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-MCP-WIKIEXPORT-005 todo.yaml deprecation

todo.yaml is deprecated as TODO source of truth. When dump and todo.yaml both exist, dump wins and a diagnostic names both. Cleanup archives to .mcpServer/archive/todo-yaml/ with evidence. Never silent delete.
Scope: layer-1+
**Acceptance Criteria:**
- [x] todo.yaml is not used as TODO source when dump is present. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Cleanup archives to .mcpServer/archive/todo-yaml/ with evidence; never silent delete. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Conflict diagnostic names both paths. (evidence: tests/McpServer.Support.Mcp.Tests/Services/WikiDumpG6OverlayTests.cs; WikiDumpG7OverlayTests.cs; DocsSyncG8OverlayTests.cs; G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

## FR-MCP-WORKSPACE-LAYER-001 FR-MCP-WORKSPACE-LAYER-001

Placeholder requirement backfilled for TODO link FR-MCP-WORKSPACE-LAYER-001.
Scope: layer-1+

## FR-MCP-XAGENT-001 CompleteTurn refuses cross-sourceType current-turn rebind

When current-turn.yaml sessionId prefix differs from the active agent (Codex vs GrokCode vs ClaudeCode), CompleteTurn does not SubmitAsync as a new turn on the other session and does not return internal_server_error. Same-agent session rotation still rebinds. CompleteTurn never closes a different requestId. Empty title omits per TR-MCP-REPL-015. BUG-TRIAGE-106, BUG-TRIAGE-142.
- [ ] cross-sourceType mismatch refused or restored to originating cache
- [ ] same-agent rotation can complete without 500
- [ ] CompleteTurn does not hijack a concurrent other requestId
Scope: layer-1+
**Acceptance Criteria:**
- [ ] cross-sourceType mismatch refused or restored to originating cache
- [ ] same-agent rotation can complete without 500
- [ ] CompleteTurn does not hijack a concurrent other requestId

## FR-SUPPORT-010 MCP Context Unification

Local MCP server providing context retrieval, TODO management, repository access, session logging, and ingestion capabilities for AI agent integration.

**Covered by:** `ContextController`, `TodoController`, `RepoController`, `SessionLogController`, `McpServerMcpTools`, `McpDbContext`, `HybridSearchService`, `EmbeddingService`, `VectorIndexService`, `Fts5SearchService`, `RepoFileService`, `IngestionCoordinator`
Scope: layer-1+

## FR-SUPPORT-010A SessionLog Workspace Stamping

Session log POST shall stamp the resolved workspace ID on every persisted row (parent SessionLog plus all child entities: turns, actions, tags, context items, processing dialog, commits, string-list items) so a POST followed by a GET under the same workspace context returns the same record. When no workspace context is resolved (ingestion / batch import paths), WorkspaceId defaults to empty string and the DbContext-level auto-stamp populates it from `_workspaceId` if available.

**Covered by:** `SessionLogService.StampWorkspaceId`, `McpDbContext.StampWorkspaceId`, `SessionLogControllerTests.WhenPostingThenGetBySessionIdReturnsRecord`
Scope: layer-1+

## FR-SUPPORT-010B SessionLog ProblemDetails Errors

Session log POST shall return RFC 7807 ProblemDetails on body-binding or validation failure. Error responses cite the offending JSON path under `errors`, never the action-parameter name. Content-Type is `application/problem+json`. The accepted top-level shape is documented in the response `detail`.

**Covered by:** `Program.cs` (`InvalidModelStateResponseFactory`), `SessionLogController.SubmitAsync` (`ValidationProblem` calls), `SessionLogControllerTests.WhenPostingMalformedWorkspaceFieldThenReturnsProblemDetailsWithoutDtoKey`
Scope: layer-1+

## FR-SUPPORT-010C SessionLog REST Surface Completion

Session log REST shall expose `GET /mcpserver/sessionlog/{agent}/{sessionId}` (single-record fetch under tenancy) and `POST /mcpserver/sessionlog/{agent}/{sessionId}/turn` (turn-append by RequestId). Unsupported verbs on either route return 405 Method Not Allowed with an `Allow` header.

**Covered by:** `SessionLogController.GetByIdAsync`, `SessionLogController.UpsertTurnAsync`, `SessionLogService.GetAsync`, `SessionLogService.UpsertTurnAsync`
Scope: layer-1+

## FR-SUPPORT-010E Stateless session lifecycle endpoints

The session-log API SHALL expose stateless open/begin/complete/fail lifecycle operations keyed by (agent, sessionId, requestId) requiring no in-process active-session state.
Scope: layer-1+

## FR-SUPPORT-010F Additive partial session-log submits

Whole-session submit SHALL merge additively: omitted session and turn fields never overwrite previously persisted values.
Scope: layer-1+

## FR-SUPPORT-011 SessionLog Workspace Stamping

Session log POST shall stamp the resolved workspace ID on every persisted row (parent SessionLog plus all child entities: turns, actions, tags, context items, processing dialog, commits, string-list items) so a POST followed by a GET under the same workspace context returns the same record. When no workspace context is resolved (ingestion / batch import paths), WorkspaceId defaults to empty string and the DbContext-level auto-stamp populates it from _workspaceId if available.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Session log POST stamps resolved workspace ID on parent and all child entities
- [ ] POST followed by GET under same workspace returns same record with workspace ID preserved
- [ ] When no workspace context is resolved, WorkspaceId defaults to empty string and DbContext auto-stamp populates from _workspaceId if available

## FR-SUPPORT-012 SessionLog ProblemDetails Errors

Session log POST shall return RFC 7807 ProblemDetails on body-binding or validation failure. Error responses cite the offending JSON path under errors, never the action-parameter name. Content-Type is application/problem+json. The accepted top-level shape is documented in the response detail.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Session log POST returns RFC 7807 ProblemDetails on body-binding failure
- [ ] Session log POST returns RFC 7807 ProblemDetails on validation failure
- [ ] Error responses cite offending JSON path under errors, not action-parameter name
- [ ] Content-Type is application/problem+json and accepted top-level shape is documented in response detail

## FR-SUPPORT-013 SessionLog REST Surface Completion

Session log REST shall expose GET /mcpserver/sessionlog/{agent}/{sessionId} (single-record fetch under tenancy) and POST /mcpserver/sessionlog/{agent}/{sessionId}/turn (turn-append by RequestId). Unsupported verbs return 405 Method Not Allowed with Allow header. Terminal-turn audit-evidence gate enforced only for Quad-Brain ACID hosted-agent source type (QBAgent), not standard agents.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] GET /mcpserver/sessionlog/{agent}/{sessionId} returns single-record fetch under tenancy
- [ ] POST /mcpserver/sessionlog/{agent}/{sessionId}/turn appends turn by RequestId
- [ ] Unsupported verbs return 405 Method Not Allowed with Allow header
- [ ] Terminal-turn audit-evidence gate enforced only for QBAgent (ACID hosted-agent), not standard agents

## FR-SUPPORT-014 Stateless session lifecycle endpoints

The session-log API shall expose stateless open/begin/complete/fail lifecycle operations keyed by (agent, sessionId, requestId) requiring no in-process active-session state.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Session-log API exposes stateless open/begin/complete/fail lifecycle operations
- [ ] Lifecycle operations are keyed by (agent, sessionId, requestId) tuple
- [ ] Operations require no in-process active-session state to function

## FR-SUPPORT-015 Additive partial session-log submits

Whole-session submit shall merge additively: omitted session and turn fields never overwrite previously persisted values. This ensures partial updates preserve existing state.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Whole-session submit merges additively without overwriting omitted fields
- [ ] Omitted session fields are never overwritten during additive merge
- [ ] Omitted turn fields are never overwritten during additive merge

## FR-TEST-002 FR-TEST-002

Placeholder requirement backfilled for TODO link FR-TEST-002.
Scope: layer-1+

## FR-TIMER-001 Stop and Dispose take precedence over overlapping Restart

Manager Core and UI.Core timer handles ignore Restart overlapping Stop or Dispose, cancel in-flight callbacks without deadlock, allow a new fresh-token Restart after Stop returns, and never restart after Dispose. Operator approved 2026-10-08 in the Phase 2 rebrand repair.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Restart while Stop or Dispose is in progress cannot create a new callback run or change the stored interval.
- [ ] Stop/Dispose cancel the active token before waiting for a synchronous callback and return without external rescue when that callback cooperates with cancellation.
- [ ] Restart after Stop returns uses a fresh uncanceled token; Dispose is final and repeated stop/dispose calls remain safe.

## FR-TRIAGE-001 Triage dashboard inspection

Users can inspect triage queue contents, grouped report queues, and AI triage run history with result details and current status for Director and MCP Web UI dashboards.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A read-only dashboard contract exposes triage queue, report group queue, and run history without inferring Agent Pool data.
- [ ] Group details include status, title, summary, report count, quiet deadline, created TODO id, last error, linked report summaries, and latest AI run results when available.
- [ ] The API supports workspace-scoped queries so Director and MCP Web can use the active workspace path.

## FR-TRIAGE-002 Triage-created TODO index

Users can query TODO item IDs created by triage, including the datetime each TODO anchor was created, so Director and MCP Web can link triage outcomes to backlog items.
Scope: layer-1+
**Acceptance Criteria:**
- [x] A read-only triage endpoint returns TODO IDs produced by triage and the TODO creation datetime. (evidence: TriageServiceTests.QueryCreatedTodosAsync_ReturnsTodoIdsCreatedAtUtcAndTriageContext)
- [x] The endpoint supports workspace-scoped queries and does not leak TODO IDs across workspaces. (evidence: TriageServiceTests.QueryCreatedTodosAsync_ReturnsTodoIdsCreatedAtUtcAndTriageContext)
- [x] The endpoint includes enough triage context to connect each TODO ID back to its group and research run when available. (evidence: TriageServiceTests.QueryCreatedTodosAsync_ReturnsTodoIdsCreatedAtUtcAndTriageContext)

## FR-WEB-001 Orchestration cockpit in mcp-web

mcp-web SHALL present a single orchestration dashboard that shows the active workspace, agent fleet, TODO bank, live activity, and global controls without requiring a separate terminal per agent.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Opening mcp-web for an authenticated workspace renders fleet, task bank, and header controls on one page.
- [ ] The page does not require the operator to open one terminal window per agent to see status.
- [ ] Refreshing the page restores the same workspace binding and current statuses from MCP APIs.

## FR-WEB-002 Workspace is the mission

mcp-web SHALL treat an MCP workspace as the Prompter Hawk "mission": one named project folder shared by all agents. The operator can bind the dashboard to an existing registered workspace; mcp-web SHALL NOT invent a parallel mission store.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Dashboard title and path equal the bound workspace name and workspacePath from MCP workspace APIs.
- [ ] Switching workspace retargets agent pool, TODOs, and session logs to that workspace only.
- [ ] No .prompter-hawk or other third-party mission directory is required for the dashboard to function.

## FR-WEB-003 Agent fleet lifecycle and status

mcp-web SHALL show each pooled agent as off, idle, working, or waiting-for-feedback, and SHALL start, stop, recycle, start-all, and stop-all through the agent pool API.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Fleet panel lists every configured pooled agent with one of off, idle, working, waiting-for-feedback.
- [ ] Start and Stop on one agent call AgentPool start/stop and the status updates without a full reload.
- [ ] Start All and Stop All act on every listed agent and report per-agent success or failure.
- [ ] Recycle on one agent calls AgentPool recycle, the agent returns to idle or off without requiring a browser reload, and in-flight TODO status is preserved or marked failed according to the pool result.

## FR-WEB-004 TODO task bank lanes

mcp-web SHALL present MCP TODOs in lanes equivalent to Prompter Hawk task categories: tentative, pending, in progress, blocked, feedback-required, recurring, and completed. MCP TODO storage remains the only source of truth.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Every TODO in the bound workspace appears in exactly one lane derived from status and tags.
- [ ] Creating a TODO from the bank uses the MCP TODO API and never writes docs/todo.yaml or TODO.yaml directly.
- [ ] Lane filters by agent assignee and priority match the stored TODO fields.

## FR-WEB-005 Fire-and-forget parallel dispatch

The operator SHALL be able to create or approve TODOs and leave. Eligible idle agents SHALL pick up pending work in parallel. Returning to mcp-web SHALL show current status without the operator babysitting a chat.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Two pending TODOs assigned to two idle agents both enter in_progress without a third operator prompt.
- [ ] Closing the browser does not cancel in-progress pool work.
- [ ] Reopening mcp-web shows those TODOs in their live statuses from the store.

## FR-WEB-006 Recurring scheduled TODOs

mcp-web SHALL let the operator attach a cron-style schedule (hourly, daily, weekly, or custom) to a TODO so MCP recreates or reopens that work on the schedule (daily test+fix, weekly docs, north-star summary).
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A TODO saved with a daily 06:00 UTC schedule appears in the recurring lane.
- [ ] When the schedule fires, a pending TODO exists for that template without a manual click.
- [ ] Disabling the schedule stops further firings and leaves historical TODOs intact.

## FR-WEB-007 Hierarchical context inheritance

Context configured at workspace, then agent, then TODO SHALL merge in that order and travel automatically into the dispatched agent run so the operator does not paste the same instructions into every task.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Workspace context is present in every dispatched run in that workspace.
- [ ] Agent persona/prompt overrides workspace text for that agent only.
- [ ] TODO description is the most specific layer and is included in the run payload.

## FR-WEB-008 One-click retry with preserved context

A failed or completed TODO SHALL be retryable from mcp-web in one action that reuses the original TODO identity, hierarchical context, and prior session linkage. The operator SHALL NOT copy-paste prompts.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Retry on a failed TODO enqueues new work bound to the same TODO id or a recorded retry child linked to it.
- [ ] The retry payload includes the original description plus workspace and agent context.
- [ ] The UI does not require the operator to locate a prior chat transcript to retry.

## FR-WEB-009 Live peek of agent work

mcp-web SHALL show live reasoning, tool calls, model id, and message history for a selected in-progress agent or TODO from the MCP session log and event stream (Prompter Hawk Live Peek).
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Selecting a working agent streams new dialog and tool_call items without a manual refresh.
- [ ] A completed TODO still opens its full message history.
- [ ] Live peek reads session log APIs; it does not scrape terminal windows.

## FR-WEB-010 Token burn and daily progress

mcp-web SHALL chart token burn versus a workspace baseline (color-coded) and show today's lines added/removed, commits, files analyzed, peak parallelism, and TODO completions.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A 24-hour burn chart renders from session-log token counts.
- [ ] Burn rate above the workspace baseline uses a distinct warning color; at or below baseline uses a distinct normal color.
- [ ] Progress metrics include commits, net line change, peak concurrent working agents, and completions for the current UTC day.
- [ ] Progress metrics show lines added and lines removed as separate counts, not only net change.
- [ ] Progress metrics include files analyzed for the current UTC day.

## FR-WEB-011 Human feedback queue

When an agent needs validation, mcp-web SHALL queue a non-blocking feedback request. Other agents SHALL continue. The operator answers on their schedule with structured options plus free text.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A feedback-required TODO appears in the feedback lane while other in_progress TODOs stay in progress.
- [ ] Submitting feedback resumes or fails that TODO through MCP APIs.
- [ ] The request records what to test, an optional command, a question, and response options.

## FR-WEB-012 Idle orchestrator proposes tentative TODOs

An optional orchestrator mode SHALL detect idle agents and create tentative TODOs for operator approval. Tentative items SHALL NOT dispatch until approved (Prompter Hawk Team Captain, mapped to MCP TODOs).
Scope: layer-1+
**Acceptance Criteria:**
- [ ] With orchestrator enabled, an idle agent with an empty pending queue results in at least one tentative TODO.
- [ ] Tentative TODOs are not assigned to running agents until the operator approves.
- [ ] Disabling orchestrator stops new proposals; existing tentative items remain until dismissed or approved.

## FR-WEB-013 Tool and path allow/deny UI

mcp-web SHALL let the operator set per-agent or workspace allow/deny rules for tools (including shell, read, write, edit) and path globs (for example allow src/*, deny .env). Denied actions fail closed.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Saving an allow src/* and deny .env rule persists through the workspace policy API.
- [ ] A denied path or tool is rejected with a visible error on the agent run, not silently ignored.
- [ ] Rules are visible and editable in mcp-web without editing YAML by hand.

## FR-WEB-014 Per-agent multi-provider backends

Each pooled agent SHALL be assignable in mcp-web to a configured backend (Claude, OpenAI, Gemini, Grok, or other already-supported MCP providers) and model id, mixing providers in one workspace.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Two agents in one workspace can show two different providers and models.
- [ ] Changing an agent model persists and is used on the next start.
- [ ] mcp-web does not add a billed proxy; it uses operator-configured provider credentials already known to MCP Server.

## FR-WEB-015 TODO to git commit linkage

When task-to-commit mapping is enabled, completing a TODO SHALL show linked commit SHAs from session-log commit actions on that TODO's card.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A completed TODO with a session-log commit action displays the SHA on the card.
- [ ] Disabling the mapping hides SHAs but does not delete session-log actions.
- [ ] Missing commits render as no-link, not as a fabricated SHA.

## FR-WEB-016 mcp-web local-first privacy

mcp-web SHALL NOT upload prompts, file contents, or diffs to a product analytics host. Code leaves the machine only toward AI providers the operator already configured on MCP Server.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Default mcp-web configuration has no third-party analytics endpoint for prompt or file payloads.
- [ ] Automated tests fail if a dashboard bundle sends prompt text or file bodies to a non-MCP, non-provider host.
- [ ] Operator secrets are not rendered in live peek beyond existing session-log redaction rules.

## FR-WEB-017 Desktop and mobile viewports

The orchestration dashboard SHALL remain usable at 1280px desktop and 390px mobile widths: fleet, bank, and live peek must be reachable without clipped primary controls.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] At 1280x800, fleet and task bank are both visible without horizontal clipping of primary controls.
- [ ] At 390x844, fleet, bank, and peek are each reachable through a documented navigation pattern.
- [ ] Start All / Stop All remain operable at both widths.

## FR-WEB-018 TODO dependencies and blocked lane

A TODO MAY declare prerequisite TODO ids. mcp-web SHALL show it blocked until every prerequisite is done, matching Prompter Hawk prerequisite behavior on MCP TODOs.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A TODO with an incomplete prerequisite appears in the blocked lane and is not auto-dispatched.
- [ ] When the last prerequisite is done, the TODO moves to pending without a manual status edit.
- [ ] Cycles are rejected with a visible validation error.

## FR-WEB-019 Persistent specialized agent prompts

Each agent SHALL have an editable persona/system prompt in mcp-web that survives process restart and is applied to later runs (Prompter Hawk agent context prompts).
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Editing an agent prompt and restarting that agent still uses the new prompt.
- [ ] Prompts are stored through MCP agent/template/memory APIs, not only in browser localStorage.
- [ ] Clearing the prompt reverts to the agent definition default.

## FR-WEB-020 Per-agent spend budgets

mcp-web SHALL expose optional hourly, daily, and monthly USD caps per agent. Exceeding a cap SHALL fail new dispatches for that agent with a visible error.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Saving hourly and daily caps persists on the agent configuration.
- [ ] When the hourly cap is exceeded, a new dispatch for that agent fails closed and the TODO stays pending or failed, not silently running.
- [ ] Clearing caps restores unlimited dispatch for that agent.

## FR-WF-005 FR-WF-005

Placeholder requirement backfilled for TODO link FR-WF-005.
Scope: layer-1+

