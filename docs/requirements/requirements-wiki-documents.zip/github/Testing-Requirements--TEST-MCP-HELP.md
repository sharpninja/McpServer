# TEST-MCP-HELP

[Back to Testing Requirements](Testing-Requirements)

## TEST-MCP-HELP

### TEST-MCP-HELP-001

Help transcript JSONL writer appends one JSON line per entry and reads all entries without overwriting prior lines.


### TEST-MCP-HELP-002

Deterministic inbound guard blocks injection fixtures and allows benign bypass corpora with stable rule IDs.


### TEST-MCP-HELP-003

Guard incident JSON logger persists one incident file per block and filters incidents by session id.


### TEST-MCP-HELP-004

Conversation service terminates sessions on guard violations; options validator rejects invalid AgentHelp configuration.


### TEST-MCP-HELP-005

HTTP integration tests cover session create, synchronous and streaming turns, transcript retrieval, and guardrail evidence persistence.


### TEST-MCP-HELP-006

MCP STDIO tools agent_help_create_session, agent_help_submit_turn, and agent_help_get_status delegate to the conversation service with workspace overrides.


### TEST-MCP-HELP-007

Typed AgentHelpClient methods dispatch to the expected /mcpserver/agent-help REST paths with matching DTO contracts.


### TEST-MCP-HELP-008

REPL contract tests prove workflow.agenthelp.createSession, workflow.agenthelp.submitTurn, and workflow.agenthelp.getStatus dispatch through typed REPL workflow code, build caller-linkage seed metadata, and return standard result/error envelopes.


### TEST-MCP-HELP-009

Independent fixture matrix and shared assertions validate AC-HELP-PATH-01 through 03: strategy defaults, aliases/casing, null/empty/whitespace overrides, and exact explicit path precedence. Correct mocks pass and wrong paths are rejected within green tests before production binding. Production-bound tests capture options from the real conversation service through a fake execution strategy. Live helper smoke test must return a substantive response.

**Acceptance Criteria:**
- [ ] With no nonblank agentPath override, Agent Help supplies a strategy-appropriate executable: codex for codex-cli, copilot for copilot-cli, grok for grok-cli/grok-build, while generic one-shot execution retains cline.
- [ ] A nonblank caller agentPath is preserved exactly and takes precedence over the strategy default.
- [ ] Null, empty and whitespace overrides and case-insensitive strategy names are handled consistently; the codex-cli path must never silently resolve to cline solely because of the generic options default.
