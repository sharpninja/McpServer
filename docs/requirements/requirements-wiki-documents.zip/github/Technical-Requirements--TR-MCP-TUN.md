# TR-MCP-TUN

[Back to Technical Requirements](Technical-Requirements)

## TR-MCP-TUN-001

**Tunnel Strategy Pattern** — DI registration in `Program.cs` reads `Mcp:Tunnel:Provider`, normalizes to uppercase, and uses `ActivatorUtilities.CreateInstance<T>` to instantiate the matching provider (`NgrokTunnelProvider`, `CloudflareTunnelProvider`, or `FrpTunnelProvider`). The provider is registered as both a singleton and an `IHostedService`, conditionally on the provider name being non-empty.
**Covered by:** FR: FR-MCP-015, FR-MCP-059
**Status:** pending
Scope: layer-1+

## TR-MCP-TUN-002

**Tunnel Process Lifecycle** — `Process.Kill()` is wrapped in a try-catch for `InvalidOperationException` to handle races. `WaitForExit(5000)` enforces a 5 s shutdown timeout. FRP config files written to temp storage are deleted on stop. All three providers log start, stop, and error events.
**Covered by:** FR: FR-MCP-015
**Status:** pending
Scope: layer-1+

## TR-MCP-TUN-003

**Ngrok Auth Token Security** — The ngrok auth token is passed via the `NGROK_AUTHTOKEN` environment variable on the child process, rather than as a CLI argument, to prevent exposure in process listings and shell history.
**Covered by:** FR: FR-MCP-015
**Status:** pending
Scope: layer-1+

## TR-MCP-TUN-004

**Tunnel provider inherits the interactive user environment** — Implements FR-MCP-141 and extends TR-MCP-TUN-003, which already establishes that NgrokTunnelProvider manipulates child-process environment variables. NgrokTunnelProvider SHALL take IProcessEnvironmentService and apply the interactive user's USERPROFILE, HOME, APPDATA, and PATH to the ProcessStartInfo of the ngrok child process, so ngrok.yml resolves when the server runs under LocalSystem instead of the provider silently starting with the service account profile. The provider SHALL resolve the ngrok binary through ResolveExecutable against that enriched PATH rather than relying on the literal string ngrok. When the binary cannot be found the provider SHALL log at Warning rather than Error, and the message SHALL name the Windows-service and Store-alias causes and the available remedies. Recovered from origin/claude/busy-dubinsky. Note that develop ships Tunnel Provider empty and Ngrok.Enabled false, so this path is dormant under stock configuration.
**Covered by:** FR: FR-MCP-141; TEST: TEST-MCP-190, TEST-MCP-191
**Status:** pending
Scope: layer-1+

