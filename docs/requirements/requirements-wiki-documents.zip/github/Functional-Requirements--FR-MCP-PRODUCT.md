# FR-MCP-PRODUCT

[Back to Functional Requirements](Functional-Requirements)

## FR-MCP-PRODUCT-001 Product CRUD

A registered workspace can create, get, list (visible), update, and soft-delete products it owns. Key is a PROD-* string matching ^PROD-[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$ (examples PROD-MCPSERVER, PROD-MCP-PLUGIN), unique among non-deleted products. Application API is CQRS only; REST/MCP/REPL/client only dispatch handlers. AC: create returns key + ownerWorkspaceId; invalid key is 400; duplicate key is 409; non-owner update/delete is 403; soft-delete hides from default list.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] create returns key and ownerWorkspaceId
- [ ] invalid key is 400
- [ ] duplicate key is 409
- [ ] non-owner update or delete is 403
- [ ] soft-delete hides product from default list

## FR-MCP-PRODUCT-002 Workspace product membership

A workspace maps to zero or more products. The owner workspace adds and removes members by workspace id. A member may leave itself. Adding a workspace requires that workspace to be registered, enabled, and not soft-deleted. AC: add requires registered enabled workspace; list members returns owner + members; leave removes only the caller; removed member loses product reads.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] add requires registered enabled workspace
- [ ] list members returns owner and members
- [ ] leave removes only the caller
- [ ] removed member loses product reads

## FR-MCP-PRODUCT-003 Shared effective requirements

Member GetEffectiveRequirements unions local effective rows with sibling members' effective rows, provenance-tagged with originWorkspaceId, layer-matched using the origin workspace layer catalog. productScope=local hides siblings; default productScope is product. AC: two workspaces in one product see each other's in-scope FR/TR/TEST/mappings; productScope=local hides siblings; id collision returns two rows with different originWorkspaceId.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] two member workspaces see each others in-scope FR TR TEST and mappings
- [ ] productScope local hides siblings
- [ ] id collision returns two rows with different originWorkspaceId

## FR-MCP-PRODUCT-004 Product isolation

Non-members cannot read product membership or sibling requirements. Local requirement mutations never write sibling rows. A leaked workspace API key cannot list all products or dump non-member workspaces. AC: outsider get-product is 404; outsider effective is local-only; update-fr on sibling id does not change the sibling row.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] outsider get-product is 404
- [ ] outsider effective is local-only
- [ ] update-fr on sibling id does not change the sibling row

## FR-MCP-PRODUCT-005 Product requirement context

Context search/pack can retrieve product-visible requirement text with origin tags. It must not pull sibling source files. Source type product-requirements filters to those chunks. AC: pack for a member includes sibling FR body; pack does not include sibling .cs chunks; source type product-requirements filters to those chunks.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] pack for a member includes sibling FR body
- [ ] pack does not include sibling source file chunks
- [ ] source type product-requirements filters to those chunks

