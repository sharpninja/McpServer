# TR-MCP-QBTOOLS

[Back to Technical Requirements](Technical-Requirements)

## TR-MCP-QBTOOLS-000

**Single core per capability (anti-duplication)** — Each tool capability (edit, bash, git) has exactly one core service carrying path-safety/transaction contracts. The internal plane calls the transaction-gated core directly; the external plane calls the same core via the MCP client. Tool classes contain only transport and JSON-shape adaptation, no business logic.
**Status:** pending
Scope: layer-1+

## TR-MCP-QBTOOLS-001

**External tool surface project and registration** — Agent-side external tools live in src/McpServer.QBAgent.Tools, are built with AIFunctionFactory.Create (non-mcp_ names), and are injected via baseOptions.ChatOptions.Tools into agent.CreateRunOptions; file tools delegate to the MCP client Repo surface.
**Covered by:** FR: FR-MCP-QBTOOLS-001; TEST: TEST-MCP-QBTOOLS-001, TEST-MCP-QBTOOLSINT-001
**Status:** pending
Scope: layer-1+

## TR-MCP-QBTOOLS-002

**run_powershell backed by HostedPowerShellSessionManager** — run_powershell reuses the in-process HostedPowerShellSessionManager runspace and returns captured streams.
**Covered by:** FR: FR-MCP-QBTOOLS-002; TEST: TEST-MCP-QBTOOLS-007
**Status:** pending
Scope: layer-1+

## TR-MCP-QBTOOLS-003

**run_bash via ProcessRunner with PATH resolution** — run_bash resolves bash.exe through IProcessEnvironmentService.ResolveExecutable and runs via ProcessRunner; absent bash yields a structured available=false result.
**Covered by:** FR: FR-MCP-QBTOOLS-003; TEST: TEST-MCP-QBTOOLS-003
**Status:** pending
Scope: layer-1+

## TR-MCP-QBTOOLS-004

**git tool via ProcessRunner with push guard** — git tool builds an argument list per the GitHubCliService pattern and runs via ProcessRunner; a subcommand allowlist gates status/diff/log/branch/add/commit/checkout/push/reset; push is constrained to the origin remote and current branch; an opt-in McpAgentOptions.AllowGitPush defaults off for first ship.
**Covered by:** FR: FR-MCP-QBTOOLS-004; TEST: TEST-MCP-QBTOOLS-002
**Status:** pending
Scope: layer-1+

## TR-MCP-QBTOOLS-005

**Server-side adapter tools mcp_repo_edit/mcp_bash/mcp_git** — McpHostedAgentToolAdapter.CreateFunctions adds mcp_repo_edit, mcp_bash, and mcp_git with mcp_ prefix; mutating variants execute through the transaction-gated core services.
**Covered by:** FR: FR-MCP-QBTOOLS-005; TEST: TEST-MCP-QBTOOLS-006
**Status:** pending
Scope: layer-1+

## TR-MCP-QBTOOLS-006

**RepoFileService.EditAsync semantics** — IRepoFileService.EditAsync(path, oldString, newString, expectedOccurrences?) reuses NormalizeRelative/TryResolveFullPath/IsAllowed/ComputeSha256/PublishChange; missing oldString fails; ambiguous match fails unless replaceAll/expectedOccurrences; returns RepoEditResult.
**Covered by:** FR: FR-MCP-QBTOOLS-006; TEST: TEST-MCP-QBTOOLS-004, TEST-MCP-QBTOOLS-005
**Status:** pending
Scope: layer-1+

## TR-MCP-QBTOOLS-007

**Transaction-gated EditAsync compensation** — TransactionGatedRepoFileService gates EditAsync (operation repo.edit) through ITurnTransactionCoordinator using the IRepoFileCompensation snapshot for rollback on reject; degraded coordinator fails.
**Covered by:** FR: FR-MCP-QBTOOLS-006; TEST: TEST-MCP-QBTOOLS-004, TEST-MCP-QBTOOLS-005
**Status:** pending
Scope: layer-1+

## TR-MCP-QBTOOLS-008

**QBAgent tool/skill DI wiring** — AddQBAgentTools and AddQBAgentSkills register the external tool and skill surfaces; Program.cs composes baseOptions.ChatOptions.Tools from both and injects the skill discovery list into the system prompt.
**Covered by:** FR: FR-MCP-QBTOOLS-007; TEST: TEST-MCP-QBTOOLSINT-001
**Status:** pending
Scope: layer-1+

