# FR-MCP-PLUGINCORE

[Back to Functional Requirements](Functional-Requirements)

## FR-MCP-PLUGINCORE-001 Canonical plugin core with sync and checksum guard

A single canonical plugin core SHALL be distributed into plugin repos by a sync tool that writes a per-file sha256 manifest, and a checksum guard SHALL fail CI when a synced file is edited locally.
Scope: layer-1+

## FR-MCP-PLUGINCORE-002 No-duplication CI guard for plugin lib files

Plugin CI SHALL fail when a lib file is neither covered by the core manifest nor declared as plugin residual.
Scope: layer-1+

## FR-MCP-PLUGINCORE-003 Persistent REPL daemon

A persistent REPL daemon SHALL serve many requests from one long-lived repl child over NDJSON framing, with auto-start, crash-restart, and spawn-per-call fallback.
Scope: layer-1+

## FR-MCP-PLUGINCORE-004 Reliable plugin session-log dialog parsing

Official QBrainAi plugins SHALL parse documented dialogItems and dialog payloads, preserve every item, and reject empty or unparseable appendDialog input instead of reporting a successful no-op.
Scope: layer-1+
**Acceptance Criteria:**
- [x] Documented dialogItems arrays preserve every dialog item and increment auditDialog by the accepted item count. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Empty or unparseable appendDialog payloads return failure with an actionable error instead of a silent successful no-op. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] The canonical parsing fix propagates to every official plugin distribution without checksum drift. (evidence: plugins/core test-fixtures; tests/McpServer.Repl.Core.Tests; overlay G0/G8 Codex extra-high AGREE SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

