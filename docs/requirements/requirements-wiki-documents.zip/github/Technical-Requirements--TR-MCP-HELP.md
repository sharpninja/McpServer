# TR-MCP-HELP

[Back to Technical Requirements](Technical-Requirements)

## TR-MCP-HELP-001

**Agent Help options and startup validation** — AgentHelpOptions binds from the AgentHelp configuration section; AgentHelpOptionsValidator rejects unsupported execution strategies, missing transcript or incident directories, and incomplete API key wiring.
**Covered by:** FR: FR-MCP-HELP-010, FR-MCP-RUNAS-001; TEST: TEST-MCP-HELP-004, TEST-MCP-HELP-009, TEST-MCP-HELP-005, TEST-MCP-RUNAS-001
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-002

**Agent Help HTTP and WebSocket API surface** — AgentHelpController exposes session create, status, synchronous turn, SSE stream, transcript retrieval, and WebSocket turn streaming under /mcpserver/agent-help.
**Covered by:** FR: FR-MCP-HELP-001, FR-MCP-HELP-008; TEST: TEST-MCP-HELP-004, TEST-MCP-HELP-005, TEST-MCP-HELP-SEC-007
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-003

**Help transcript JSONL writer** — HelpTranscriptWriter appends one JSON object per line under the configured transcript directory and reads all entries for a session.
**Covered by:** FR: FR-MCP-HELP-003; TEST: TEST-MCP-HELP-001, TEST-MCP-HELP-005
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-004

**Deterministic inbound guard** — AgentHelpInboundGuard applies stable injection and benign-bypass rules before helper execution.
**Covered by:** FR: FR-MCP-HELP-002; TEST: TEST-MCP-HELP-002, TEST-MCP-HELP-SEC-001, TEST-MCP-HELP-SEC-002, TEST-MCP-HELP-SEC-003, TEST-MCP-HELP-SEC-004, TEST-MCP-HELP-SEC-005, TEST-MCP-HELP-SEC-006
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-005

**Guard incident JSON logger** — AgentHelpIncidentLogger writes one incident file per blocked inbound message and supports session-scoped reads.
**Covered by:** FR: FR-MCP-HELP-004; TEST: TEST-MCP-HELP-003, TEST-MCP-HELP-SEC-006
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-006

**Stub corpus bootstrap** — AgentHelpCorpusService returns a deterministic context pack summary without full indexing when corpus bootstrap is enabled.
**Covered by:** FR: FR-MCP-HELP-005; TEST: TEST-MCP-HELP-004
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-007

**In-memory conversation orchestration** — AgentHelpConversationService maintains the session registry, evaluates inbound guards, executes helper turns, and coordinates transcript and incident persistence.
**Covered by:** FR: FR-MCP-HELP-001, FR-MCP-HELP-010; TEST: TEST-MCP-HELP-004, TEST-MCP-HELP-005, TEST-MCP-HELP-009
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-008

**Outcome analysis recommendations** — AgentHelpOutcomeService derives triage and documentation TODO recommendations from help session transcripts and incidents.
**Covered by:** FR: FR-MCP-HELP-005; TEST: TEST-MCP-HELP-004
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-009

**MCP STDIO and typed client adapters** — FwhMcpTools.AgentHelp exposes agent_help tools; AgentHelpClient and McpServerClient.AgentHelp mirror the REST controller contracts.
**Covered by:** FR: FR-MCP-HELP-006, FR-MCP-HELP-007, FR-MCP-HELP-009; TEST: TEST-MCP-HELP-006, TEST-MCP-HELP-007, TEST-MCP-HELP-008
**Status:** completed
Scope: layer-1+

## TR-MCP-HELP-010

**GrokCliAgentExecutionStrategy one-shot grok invocation** — GrokCliAgentExecutionStrategy SHALL run grok as a one-shot process delivering the prompt via --prompt-file and capturing plain stdout, resolve the grok executable via ProcessEnvironmentService, be registered in AddAgentExecutionStrategies, and be resolvable by name grok-cli with grok-build normalizing to grok-cli; AgentHelpOptions.DefaultExecutionStrategy defaults to grok-cli.
**Covered by:** FR: FR-MCP-HELP-011, FR-MCP-RUNAS-001; TEST: TEST-MCP-HELP-008, TEST-MCP-HELP-004, TEST-MCP-HELP-005, TEST-MCP-RUNAS-001
**Status:** pending
Scope: layer-1+

