# TR-MCP-SKILLS

[Back to Technical Requirements](Technical-Requirements)

## TR-MCP-SKILLS-001

**Use supported plugin MCP bridge paths** — Skill content uses each plugin's supported MCP bridge or wrapper path and forbids raw REST for normal MCP mutations.
**Covered by:** FR: FR-MCP-111; TEST: TEST-MCP-149, TEST-MCP-150, TEST-MCP-151
**Status:** pending
Scope: layer-1+

## TR-MCP-SKILLS-002

**Preserve commit-sync pause acknowledgement contract** — commit-sync skill content preserves the pause-and-acknowledge contract before staging, committing, or pushing.
**Covered by:** FR: FR-MCP-111; TEST: TEST-MCP-149, TEST-MCP-150, TEST-MCP-151
**Status:** pending
Scope: layer-1+

## TR-MCP-SKILLS-003

**Package skills through existing plugin distribution metadata** — Plugin manifests and package metadata expose or package the new skills according to each plugin's existing distribution model.
**Covered by:** FR: FR-MCP-111; TEST: TEST-MCP-149, TEST-MCP-150, TEST-MCP-151
**Status:** pending
Scope: layer-1+

