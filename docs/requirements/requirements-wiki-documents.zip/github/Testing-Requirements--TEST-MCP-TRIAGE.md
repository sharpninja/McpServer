# TEST-MCP-TRIAGE

[Back to Testing Requirements](Testing-Requirements)

## TEST-MCP-TRIAGE

### TEST-MCP-TRIAGE-001

Intake accepts valid reports and rejects invalid reports across REST, client, and REPL.

**Acceptance Criteria:**
- [ ] Unit and integration tests cover valid and invalid report submission through public surfaces.

### TEST-MCP-TRIAGE-002

Deterministic grouping, McpServer workspace routing for core and plugin bugs, and 15-minute quiet-window behavior are verified.

**Acceptance Criteria:**
- [ ] Tests prove grouping keys, workspace isolation, quiet deadline resets, and McpServer core/plugin routing fallback behavior.

### TEST-MCP-TRIAGE-003

Research worker invokes configured direct agent with group JSON and prompt.

**Acceptance Criteria:**
- [ ] Tests verify dispatch input and configured prompt rendering.

### TEST-MCP-TRIAGE-004

Schema-valid research output creates exactly one BUG-TRIAGE-### TODO.

**Acceptance Criteria:**
- [ ] Tests verify idempotent TODO creation from valid research output.

### TEST-MCP-TRIAGE-005

Invalid agent output or failed agent run creates no TODO and leaves inspectable failure state.

**Acceptance Criteria:**
- [ ] Tests verify failed runs preserve output or errors and do not create TODOs.

### TEST-MCP-TRIAGE-006

Multi-workspace isolation prevents cross-workspace grouping and status leakage.

**Acceptance Criteria:**
- [ ] Tests verify query filters and grouping scope never cross workspace boundaries.
