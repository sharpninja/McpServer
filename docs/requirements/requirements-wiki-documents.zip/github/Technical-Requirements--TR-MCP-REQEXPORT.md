# TR-MCP-REQEXPORT

[Back to Technical Requirements](Technical-Requirements)

## TR-MCP-REQEXPORT-001

**Wiki requirement document renderer emits Markdown sections for TEST descriptions and AC** — The requirements wiki renderer shall preserve TEST grouping while emitting each TEST requirement as a heading with description text and a nested Acceptance Criteria checklist generated from the structured acceptanceCriteria field.
**Covered by:** FR: FR-MCP-112; TEST: TEST-MCP-152, TEST-MCP-REQEXPORT-002, TEST-MCP-REQEXPORT-003, TEST-MCP-REQWS-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [x] Wiki testing export output contains per-TEST headings and description paragraphs. (evidence: RequirementsWikiDocumentRenderer now renders grouped TEST entries as Markdown sections headed by TEST requirement IDs.)
- [x] Structured acceptanceCriteria entries render as bullet/checklist list items with evidence when supplied. (evidence: RequirementsDocumentRenderer.AppendAcceptanceCriteria is reused by wiki rendering and focused tests assert checklist output.)

## TR-MCP-REQEXPORT-002

**Wiki generate surfaces real exception, never opaque 500** — The requirements generate endpoint (GET /mcpserver/requirements/generate?format=wiki) SHALL surface the real exception - message, exceptionType, stage, details - as a structured HTTP 500 for any failure outside the pre-existing catch list (RequirementsConflictException/ArgumentException/InvalidOperationException/UnauthorizedAccessException/IOException); no wiki generation failure may reach the global exception middleware and return an opaque internal_server_error. Acceptance Criteria: (AC1) an exception type outside the listed set (e.g. KeyNotFoundException) returns a structured 500 body naming exceptionType and the message; (AC2) successful wiki export still returns the ZIP; (AC3) the existing structured 400/409 paths (config load, transaction, zip assembly) are unchanged. Origin: BUG-TRIAGE-073 (wiki branch had no catch-all; yaml/all path succeeds while wiki/all 500s opaquely in some workspaces). Validated by TEST-MCP-REQEXPORT-002.
**Covered by:** FR: FR-MCP-112; TEST: TEST-MCP-152, TEST-MCP-REQEXPORT-002, TEST-MCP-REQEXPORT-003, TEST-MCP-REQWS-001
**Status:** pending
Scope: layer-1+

## TR-MCP-REQEXPORT-003

**Requirements generateDocument accepts markdown for all non-wiki docTypes** — generateDocument SHALL accept format=markdown for every non-wiki docType (functional, technical, testing, mapping, matrix) at the JSON schema, ReplYamlMessageValidator, and RequirementsWorkflow layers. AC1: a call {format:markdown,docType:matrix} returns markdown content, not a format rejection. AC2: no layer restricts format to {yaml,wiki}. Encodes BUG-TRIAGE-074 (non-reproducing) so a future enum narrowing fails TEST-MCP-REQEXPORT-003.
**Covered by:** FR: FR-MCP-112; TEST: TEST-MCP-152, TEST-MCP-REQEXPORT-002, TEST-MCP-REQEXPORT-003, TEST-MCP-REQWS-001
**Status:** pending
Scope: layer-1+

## TR-MCP-REQEXPORT-004

**Requirements generateDocument honors explicit workspacePath override end-to-end** — generateDocument SHALL honor an explicit workspacePath override end-to-end; a cross-workspace call without that workspace's API key fails 401 and never silently exports the session-bound workspace. AC1: an explicit workspacePath with a valid key returns that workspace's requirements. AC2: an unauthorized cross-workspace call returns 401, not a silent fallback to the session-bound workspace. Guards BUG-TRIAGE-078 via TEST-MCP-REQWS-001.
**Covered by:** FR: FR-MCP-112; TEST: TEST-MCP-152, TEST-MCP-REQEXPORT-002, TEST-MCP-REQEXPORT-003, TEST-MCP-REQWS-001
**Status:** pending
Scope: layer-1+

