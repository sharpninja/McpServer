# TEST-WEB

[Back to Testing Requirements](Testing-Requirements)

## TEST-WEB

### TEST-WEB-001

Unit and UI tests prove FR-WEB-001 cockpit composition and refresh from MCP APIs.

**Acceptance Criteria:**
- [ ] OrchestrationDashboardTests fail before implementation and pass after for fleet+bank+header.
- [ ] Refresh test uses mocked clients, not live HTTP.

### TEST-WEB-002

Tests prove FR-WEB-002 workspace-as-mission binding and isolation.

**Acceptance Criteria:**
- [ ] Switching workspace changes TODO and pool queries' workspace path.
- [ ] No test creates a .prompter-hawk directory as a prerequisite.

### TEST-WEB-003

Tests prove FR-WEB-003 status mapping and start/stop/recycle/all against AgentPoolClient mocks.

**Acceptance Criteria:**
- [ ] Each status enum maps to a visible state.
- [ ] Start All invokes start per agent.
- [ ] Recycle invokes AgentPoolClient.RecycleAgentAsync (or the recycle endpoint) for the selected agent.

### TEST-WEB-004

Tests prove FR-WEB-004 lane derivation and TodoClient usage.

**Acceptance Criteria:**
- [ ] Each lane has a fixture TODO that only appears there.
- [ ] Create path is asserted against TodoClient, not file IO.

### TEST-WEB-005

Tests prove FR-WEB-005 fire-and-forget parallel pickup.

**Acceptance Criteria:**
- [ ] Two idle agents receive two TODOs without a third prompt.
- [ ] A simulated browser close does not call cancel.

### TEST-WEB-006

Tests prove FR-WEB-006 schedule persist and fire while UI is closed.

**Acceptance Criteria:**
- [ ] Scheduler test advances fake time and creates a pending TODO.
- [ ] Disable schedule test asserts no further creates.

### TEST-WEB-007

Tests prove FR-WEB-007 workspace/agent/TODO merge order.

**Acceptance Criteria:**
- [ ] Merge unit test documents order workspace, agent, TODO.
- [ ] Agent override wins over workspace for the same key.

### TEST-WEB-008

Tests prove FR-WEB-008 one-click retry payload.

**Acceptance Criteria:**
- [ ] Retry includes original description and context layers.
- [ ] Retry is one UI action in the test harness.

### TEST-WEB-009

Tests prove FR-WEB-009 session-log streaming.

**Acceptance Criteria:**
- [ ] Fake SSE emits dialog items that appear in the peek panel.
- [ ] Completed TODO history test does not require a live agent.

### TEST-WEB-010

Tests prove FR-WEB-010 charts and daily metrics.

**Acceptance Criteria:**
- [ ] Baseline comparison color is asserted for above and below rates.
- [ ] Peak parallelism is computed from overlapping working intervals.
- [ ] Fixture data asserts lines added, lines removed, and files analyzed as distinct fields.

### TEST-WEB-011

Tests prove FR-WEB-011 non-blocking feedback.

**Acceptance Criteria:**
- [ ] Other agents remain in_progress while one waits for feedback.
- [ ] Submit feedback calls TODO or session API, not a local-only flag.

### TEST-WEB-012

Tests prove FR-WEB-012 idle proposals stay tentative.

**Acceptance Criteria:**
- [ ] Idle + enabled orchestrator creates tentative TODO.
- [ ] Tentative is not dispatched.

### TEST-WEB-013

Tests prove FR-WEB-013 allow/deny fail-closed.

**Acceptance Criteria:**
- [ ] Deny .env is persisted via policy API mock.
- [ ] Denied tool attempt is rejected in the test double.

### TEST-WEB-014

Tests prove FR-WEB-014 per-agent provider/model.

**Acceptance Criteria:**
- [ ] Two agents persist two providers.
- [ ] No markup/proxy configuration is introduced.

### TEST-WEB-015

Tests prove FR-WEB-015 SHA rendering from session-log commit actions.

**Acceptance Criteria:**
- [ ] Fixture commit action renders SHA.
- [ ] Missing action renders no SHA.

### TEST-WEB-016

Tests prove FR-WEB-016 no prompt/file telemetry.

**Acceptance Criteria:**
- [ ] Bundle/config scan fails on analytics prompt sinks.
- [ ] Redaction test covers API key patterns already used in session logs.

### TEST-WEB-017

Tests prove FR-WEB-017 desktop and mobile layout.

**Acceptance Criteria:**
- [ ] 1280px test asserts fleet and bank visible.
- [ ] 390px test asserts primary controls reachable.

### TEST-WEB-018

Tests prove FR-WEB-018 blocked lane and cycle rejection.

**Acceptance Criteria:**
- [ ] Incomplete prereq places TODO in blocked.
- [ ] Cycle create is rejected.

### TEST-WEB-019

Tests prove FR-WEB-019 prompt survives recycle.

**Acceptance Criteria:**
- [ ] Recycle after edit still returns new prompt.
- [ ] Clear restores default.

### TEST-WEB-020

Tests prove FR-WEB-020 server-side cap enforcement.

**Acceptance Criteria:**
- [ ] Exceeded hourly cap fails enqueue in API test, not only UI.
- [ ] Clearing cap allows enqueue.
