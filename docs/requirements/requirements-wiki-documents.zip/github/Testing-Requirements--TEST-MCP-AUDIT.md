# TEST-MCP-AUDIT

[Back to Testing Requirements](Testing-Requirements)

## TEST-MCP-AUDIT

### TEST-MCP-AUDIT-001

AuditPayloadMigrationTests and AuditPayloadProviderMigrationTests apply the real SQLite, PostgreSQL, and SQL Server migrations in scratch databases, verify legacy text reads and all four compressed payload round trips, and confirm the new migration ID is applied.

**Acceptance Criteria:**
- [ ] AuditPayloadMigrationTests and AuditPayloadProviderMigrationTests apply actual migrations in scratch SQLite, PostgreSQL and SQL Server databases; each verifies legacy text reads, all four compressed-payload round trips, and the applied migration ID.

### TEST-MCP-AUDIT-002

DbFkBehaviorTests reject tracked audit updates. SqlServerAuditPayloadMigrationTests assert seven SQL Server runtime-role DENY permissions. AuditPayloadMigrationTests verify AutoMigrate false rejects pending schema and accepts migrated schema.

**Acceptance Criteria:**
- [ ] DbFkBehaviorTests reject tracked audit updates.
- [ ] SqlServerAuditPayloadMigrationTests verify the seven runtime-role DENY permissions.
- [ ] AuditPayloadMigrationTests prove AutoMigrate=false rejects pending schema and accepts migrated schema.

### TEST-MCP-AUDIT-003

AuditReachesHub, AuditRetryIdempotent and AuditBackfillVerified exercise permanent node and hub ledgers. CloneOmitsSecrets verifies project history exclusions; wiki export remains free of operational audit. Preserve exact compression and runtime-role tests in TEST-MCP-AUDIT-001/002.

**Acceptance Criteria:**
- [ ] Given source has100 TODO audit and20 generic audit records, when backfill verifies, then all120 matching hashes and receipts exist at the hub; missing one blocks cutover.
