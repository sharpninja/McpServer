# TEST-MCP-QBTOOLS

[Back to Testing Requirements](Testing-Requirements)

## TEST-MCP-QBTOOLS

### TEST-MCP-QBTOOLS-001

Unit tests asserting read_file/write_file/edit_file/list_files are registered as non-mcp_ external tools and delegate to the MCP client Repo surface (no direct filesystem access).

**Acceptance Criteria:**
- [ ] The four file tools are present, non-mcp_-prefixed, and delegate to the MCP client.
- [ ] A path-traversal request is rejected server-side.

### TEST-MCP-QBTOOLS-002

Unit tests (mock IProcessRunner) asserting git status builds expected args and parses output, push targets origin only, and an unknown subcommand is rejected.

**Acceptance Criteria:**
- [ ] status/diff/log build expected args and parse results.
- [ ] push args never include a non-origin remote; unknown subcommand rejected.

### TEST-MCP-QBTOOLS-003

Unit test (mock ResolveExecutable) asserting run_bash returns available=false when bash.exe is missing and runs the command when present.

**Acceptance Criteria:**
- [ ] bash absent yields available=false without throwing; bash present returns stdout/stderr/exit.

### TEST-MCP-QBTOOLS-004

Unit tests for EditAsync: replace-unique, ambiguous-fails, replace-all, missing-old-fails, traversal-rejected, nonexistent-fails, audit+updated-event.

**Acceptance Criteria:**
- [ ] Unique replace succeeds; missing/ambiguous fail per rules; traversal and nonexistent rejected; audit + change event emitted.

### TEST-MCP-QBTOOLS-005

Unit tests asserting gated EditAsync commits+audits, rolls back to original on transaction reject, and fails under a degraded coordinator.

**Acceptance Criteria:**
- [ ] Commit applies + audits; reject restores original; degraded coordinator fails.

### TEST-MCP-QBTOOLS-006

Unit tests asserting McpHostedAgentToolAdapter exposes mcp_repo_edit, mcp_bash, and mcp_git, and that mutating variants route through the transaction-gated core.

**Acceptance Criteria:**
- [ ] mcp_repo_edit/mcp_bash/mcp_git present; mutating ones transaction-gated.

### TEST-MCP-QBTOOLS-007

Unit tests asserting run_powershell executes a command in a hosted runspace and returns captured output/error streams.

**Acceptance Criteria:**
- [ ] run_powershell runs a command and returns output and error streams from the hosted runspace.
