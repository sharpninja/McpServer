# FR-MCP-TRIAGESTORE

[Back to Functional Requirements](Functional-Requirements)

## FR-MCP-TRIAGESTORE-001 Session-log persist is diagnosable and idempotent

Session-log persist is diagnosable and idempotent on identical action resubmit. Session tags persist and round-trip on query. replace_turn for a missing turn is 404. canceled and cancelled are queryable terminal statuses. Superseded hook turns persist canceled with planFile and todoId None sentinels and no opaque 500.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Session-log persist is diagnosable and idempotent on identical action resubmit. Session tags persist and round-trip on query. replace_turn for a missing turn is 404. canceled and cancelled are queryable terminal statuses. Superseded hook turns persist canceled with planFile and todoId None sentinels and no opaque 500.

## FR-MCP-TRIAGESTORE-002 Storage-only outages fail fast without flipping health liveness

Session-log and triage mutating calls fail within about 5 seconds with a classified storage-unavailable error when SQL is unreachable. GET /health remains process-live and echoes nonce. Failsafe stays queued. After restore the next mutate succeeds.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Session-log and triage mutating calls fail within about 5 seconds with a classified storage-unavailable error when SQL is unreachable. GET /health remains process-live and echoes nonce. Failsafe stays queued. After restore the next mutate succeeds.

