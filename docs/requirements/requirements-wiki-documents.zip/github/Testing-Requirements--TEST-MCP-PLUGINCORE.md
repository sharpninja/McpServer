# TEST-MCP-PLUGINCORE

[Back to Testing Requirements](Testing-Requirements)

## TEST-MCP-PLUGINCORE

### TEST-MCP-PLUGINCORE-001

bats: sync writes manifest+sha256; guard OK after sync; fails on edit; fails on deletion; manifest required; re-sync repairs.


### TEST-MCP-PLUGINCORE-002

core-guard job fails on a seeded undeclared lib file and passes when declared in PLUGIN-RESIDUAL.txt.


### TEST-MCP-PLUGINCORE-003

bats: daemon roundtrip with --- terminator; one child serves N sends; auto-restart after kill; concurrent sends; persistent wrapper threads JSON params and honors fallback.


### TEST-MCP-PLUGINCORE-004

Automated PowerShell runtime and plugin parity tests SHALL cover dictionary-backed multi-item dialog parsing, persistence delegation, empty-payload failure, propagation, and checksum integrity with zero failures and zero skips.

**Acceptance Criteria:**
- [x] A red test reproduces the documented appendDialog silent no-op with ConvertFrom-Yaml dictionary output. (evidence: plugins/core tests; overlay G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Tests prove multi-item delegation and fail-closed empty payload behavior. (evidence: plugins/core tests; overlay G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Canonical and propagated plugin suites complete with zero failures and zero skips. (evidence: plugins/core tests; overlay G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)

### TEST-MCP-PLUGINCORE-005

Validates TR-MCP-PLUGINCORE-005. Doc-presence + parse check (receipt captured 2026-07-16): ConvertFrom-Yaml parses both templates/prompt-templates.yaml and src/McpServer.Support.Mcp/graphrag-global/input/canonical/templates/prompt-templates.yaml; both contain the strings 'same volume as the target' and 'cross-volume move' in the PowerShell.Mcp Command Routing block; the added guidance text contains no em-dashes/en-dashes (pre-existing dashes elsewhere in the template are out of scope).

**Acceptance Criteria:**
- [x] ConvertFrom-Yaml parses both templates/prompt-templates.yaml and the graphrag canonical prompt-templates.yaml. (evidence: plugins/core tests; overlay G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] Both contain the strings same volume as the target and cross-volume move in the PowerShell.Mcp Command Routing block. (evidence: plugins/core tests; overlay G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
- [x] The added guidance text contains no em-dashes or en-dashes. (evidence: plugins/core tests; overlay G8 SHA-256 B652C283B446F2B82832665499811741B71F3C63D29F56E30181158829C596A6)
