# FR-MCP-TRIAGE

[Back to Functional Requirements](Functional-Requirements)

## FR-MCP-TRIAGE-001 Fire-and-forget triage intake

Agents can submit workspace-scoped incidental bug reports without leaving their current task.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] REST, client, REPL, and plugin tool paths all accept the same report contract.
- [ ] Intake persists the report and returns reportId, groupId, status, and quietDeadlineUtc.
- [ ] Intake does not run research or create a TODO synchronously.

## FR-MCP-TRIAGE-002 Async triage grouping and research

Related reports are grouped, MCP Server and MCP Server plugin reports are routed to the registered McpServer workspace when it exists, and groups are researched asynchronously and converted to TODOs.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Groups are deterministic and workspace-isolated.
- [ ] New matching reports reset the 15-minute quiet window.
- [ ] A configured triage agent receives group JSON plus rendered prompt and must return schema-valid JSON.
- [ ] Valid output creates one BUG-TRIAGE-### backlog TODO; invalid output creates no TODO and exposes failure status.
- [ ] MCP Server core and MCP Server plugin bugs are grouped into the registered McpServer workspace when that workspace exists; otherwise they stay in the submitting workspace.

## FR-MCP-TRIAGE-003 REPL triage parity

The REPL exposes the complete triage surface through client passthrough and typed workflow wrappers.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] client.triage.* works through generic passthrough after adding McpServerClient.Triage.
- [ ] workflow.triage.* routes through typed workflow classes and returns deprecated metadata consistent with existing workflow namespaces.
- [ ] YAML validation, error envelopes, and request/response shapes are covered.

## FR-MCP-TRIAGE-004 Plugin triage skills

All plugin distributions teach agents when and how to use triage.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Each plugin skill bundle includes triage guidance.
- [ ] Skills say to use triage for incidental bugs, not for the user active requested fix.
- [ ] Skills explicitly say not to expect immediate resolution and to continue the current task after submission.

