# TEST-MCP-QBEXEC

[Back to Testing Requirements](Testing-Requirements)

## TEST-MCP-QBEXEC

### TEST-MCP-QBEXEC-001

Classifier marks mcp_ tools internal. Interceptor executes every catalog mcp_* tool server-side and strips it. Only non-mcp_ calls remain as OpenAI tool_calls. Failed/unhandled internals are notes. All-internal success is finish_reason stop with result content. Tests use mocks or WebApplicationFactory and do not depend on the Windows service.

**Acceptance Criteria:**
- [x] Tools are classified internal (mcp_ prefix) vs external. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainToolInterceptionTests.cs Classifier_IdentifiesInternalTools)
- [x] Internal tools execute server-side and are stripped; only non-mcp_ calls are emitted. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainToolInterceptionTests.cs Interceptor_CatalogName_IsNotEmittedToAgent)
- [x] Internal-tool failures surface as a note, never as a tool command. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainOpenAiChatServiceTests.cs CompleteAsync_InternalToolFailure_BecomesNoteNotToolCall)
- [x] A theory or explicit list covering every mcp_* name from McpHostedAgentToolAdapter and QBAgentDefinition asserts RemainingToolCalls does not contain that name. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainToolInterceptionTests.cs Interceptor_CatalogName_IsNotEmittedToAgent)
- [x] These tests do not require the McpServer Windows service. (evidence: unit tests with NSubstitute mocks)

### TEST-MCP-QBEXEC-002

Unit tests assert every catalog mcp_* name is handled by QuadBrainInternalToolExecutor through in-process application/CQRS or transaction-gated services (ITodoService, IRepoFileService, session-log, requirements, GraphRAG, desktop, PowerShell, client invoke, mutating git). Unknown catalog-absent mcp_ names return Unhandled. Tests mock those services. Tests do not HTTP-call MCP endpoints and do not depend on the Windows service. OpenAI surface: mcp_todo_query success returns finish_reason stop with the query result in assistant content.

**Acceptance Criteria:**
- [x] Mutating todo/requirements/repo routes go through the transaction-gated services; a catalog-absent mcp_ name returns Unhandled. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs)
- [x] A theory or explicit case exists for every mcp_* name from McpHostedAgentToolAdapter and QBAgentDefinition; each handled name verifies the matching mock service was invoked. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Execute_CatalogName_IsHandled)
- [x] mcp_todo_query (and other reads) go through ITodoService/IRepoFileService/etc, not HttpClient. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainInternalToolExecutorTests.cs Execute_McpTodoQuery_RoutesThroughTodoService; Executor_DoesNotDependOnHttpClient)
- [x] All-internal success (for example mcp_todo_query) returns finish_reason stop and assistant content containing the service result, with tool_calls null. (evidence: tests/McpServer.Support.Mcp.Tests/Services/QuadBrainOpenAiChatServiceTests.cs CompleteAsync_CatalogName_StopsWithoutEmittingToolCall)
- [x] These tests do not start, query, or depend on the McpServer Windows service. (evidence: unit tests with NSubstitute mocks)

### TEST-MCP-QBEXEC-003

Unit tests asserting each brain invocation's full prompt+output is written to the session log under TurnId, AoT reconciliation is logged, and internal-tool executed/failed outcomes are recorded with secrets redacted.

**Acceptance Criteria:**
- [ ] Each brain invocation full prompt+output logged under TurnId; AoT logged; executed/failed outcomes recorded; secrets redacted.
