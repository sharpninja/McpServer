# QBrain.AI User Documentation

This guide is for operators and AI-agent users running `QBrainAi.Support.Mcp`.

## 1) Installation and prerequisites

### Frontier agent setup prompt (draft)

For a frontier coding agent doing interactive intake + install/configure/verify, use the draft prompt at [docs/setup/2026-09-28-frontier-agent-setup-prompt.DRAFT.md](setup/2026-09-28-frontier-agent-setup-prompt.DRAFT.md) (MCP-SETUPPROMPT-001). Hostile-validator overall verdict **AGREE** on 2026-09-28 CT; treat as draft until a live install dry-run closes the remaining open surfaces noted in docs/receipts/hv/hostile-validator-setupprompt-overall-20260928T153330Z.md.

### Supported host environment

- Windows 10/11 or Windows Server
- Linux hosts that publish a self-contained layout (the live box path is `/opt/mcpserver`)
- .NET SDK 10.x for local development (`global.json` pins `10.0.201` with `rollForward: latestFeature`)
- PowerShell 7+
- `gh` CLI for GitHub issue and PR workflows
- Network access to the configured MCP port (default `7147`)

### Prerequisite checks

```powershell
dotnet --version
gh auth status
Invoke-RestMethod http://localhost:7147/health
```

### Install/run options

#### Development run (HTTP + MCP transport)

```powershell
./build.ps1 StartServer --instance default
# or: dotnet run --project src\QBrainAi.Support.Mcp -- --instance default
```

#### STDIO transport

```powershell
dotnet run --project src\QBrainAi.Support.Mcp -- --transport stdio --instance default
```

#### Windows service deployment

```powershell
gsudo pwsh.exe -NoLogo -NoProfile -NonInteractive -File .\build.ps1 UpdateService
Get-Service QBrainAi
```

The default target bumps `GitVersion.yml` `next-version` (patch) and `git add`s that file. Pass `--skip-version-bump` (Nuke `--SkipVersionBump true`) only when you must leave `GitVersion.yml` unchanged.

Nuke `UpdateService` detects Windows or Linux. Windows retains its service registration, launcher, ZIP backup and restore behavior. A deployment receipt applies only to the host that actually ran the target.

#### Linux systemd service update

Run from an elevated PowerShell session at the repository root:

```powershell
./build.ps1 UpdateService --skip-version-bump
```

Linux defaults to the existing `mcpserver.service` unit and `/opt/mcpserver/app`. Override them with `--service-name` and `--install-path`; use `--port` when health checks need a port other than 7147. This target updates an installed service; it does not provision an account or unit. It publishes the Linux x64/arm64 apphost before stopping the service. To use a prepared publish directory, pass `--skip-build --publish-source /absolute/path/to/publish`.

Both platforms preserve live `appsettings.yaml` and its configured `DataFolder`, falling back to `Mcp:DataDirectory`. When data resolves to the install root, the existing legacy runtime folders and database-file patterns are preserved. Linux additionally archives the unit, drop-ins and environment files, retaining Unix ownership, modes, ACLs, extended attributes and symbolic links. Private recovery archives remain under `/var/backups/mcpserver` (override with `--linux-backup-root`). Service arguments, account, environment and boot policy are retained.

The Linux updater requires a direct apphost service with matching working directory and a single base YAML configuration. Configuration overlays, data/instance/content-root overrides, filesystem namespace remapping and unsafe path overlaps fail before stopping. A per-installation lock also prevents concurrent updates through unit aliases. After replacement, live state is restored before service and workspace health verification. Failure retains the archive and restores preserved state when possible; it does not roll back binaries or back up an external SQL database.

### Verify startup

- `GET /health` returns liveness Healthy, echoes a caller nonce when one is supplied, and reports `storage` as `reachable` or `unreachable` (storage outage does not flip liveness off Healthy)
- `GET /swagger` loads the API UI
- `GET /swagger/v1/swagger.json` returns OpenAPI metadata
- marker file `AGENTS-README-FIRST.yaml` exists at workspace root

## 2) Configuration reference (appsettings + marker file)

### appsettings keys (root)

- `DataFolder`
- `Embedding:*` and `VectorIndex:*`
- `Mcp:Port`, `Mcp:DataSource`, `Mcp:DataDirectory`
- `Mcp:Database:*` — canonical database provider, provider connection settings, migration assembly override, and native at-rest encryption settings
- `Mcp:RepoRoot`, `Mcp:RepoAllowlist`
- `Mcp:TodoFilePath`, `Mcp:TodoStorage:*`
- `Mcp:TurnTransactions:*` — coordinator + keyserver. Repo default `Enabled: false`. Live box MCP keeps `Enabled: true` for QuadBrain. Keyserver signing is QuadBrain/brain-slot only (FR-MCP-173); first-party adapters bypass the coordinator.
- `Mcp:GraphRag:*`
- `Mcp:ToolRegistry:*`
- `Mcp:Tunnel:*`
- `Mcp:Parseable:Enabled`, `Mcp:Parseable:Url` — optional Serilog HTTP sink to Parseable; default off (`Enabled: false`). Set `Enabled: true` and `Url` (e.g. `http://localhost:8000`) to enable.
- `Mcp:Workspaces` — informational projection and bootstrap fallback. The database workspace registry is authoritative after startup/bootstrap.
- `Mcp:Instances:{name}:*`
- `VoiceConversation:DefaultExecutionStrategy` (`hosted-agentframework` or `copilot-cli`)
- `VoiceConversation:ModelApiKeyEnvironmentVariableName`
- `GET|PATCH /qbrainai/configuration` (PATCH requires admin role)

Legacy flat keys such as `Mcp:DatabaseProvider`, `Mcp:PostgresConnectionString`,
`Mcp:SqlServerConnectionString`, and `Mcp:DatabaseMigrationsAssembly` remain supported as
fallbacks, but new configuration should prefer the nested `Mcp:Database:*` surface.

### Configuration precedence

1. `PORT` environment variable
2. `Mcp:Instances:{name}:Port`
3. `Mcp:Port`
4. default `7147`

### Marker file (`AGENTS-README-FIRST.yaml`)

Key fields:

- `baseUrl`, `port`
- `apiKey`
- endpoint map (`health`, `swagger`, `todo`, `sessionLog`, etc.)
- `workspacePath`, `workspace`
- `serverStartedAtUtc`, `markerWrittenAtUtc`
- `signature`, including `fields` and `format`, which describe the signed payload itself
- `trust_bootstrap`

The `signature` block is self-describing: `fields` lists the canonical field names in the
exact order they are fed to HMAC-SHA256, and `format` states the encoding (`key=value` per
line, trailing LF on the final line, UTF-8). Verifiers should read that array from the marker
they are checking rather than hard-coding a field list, since it reflects the conditional
`agentPlugins` tail for that specific marker.

Example use:

```powershell
$marker = Get-Content .\AGENTS-README-FIRST.yaml -Raw
$apiKey = ([regex]::Match($marker, 'apiKey:\s*(\S+)')).Groups[1].Value
Invoke-RestMethod -Uri "http://localhost:7147/qbrainai/todo" -Headers @{ "X-Api-Key" = $apiKey }
```

### Database provider configuration

Canonical provider configuration now lives under `Mcp:Database:*`.

Example SQLite configuration:

```yaml
Mcp:
  Database:
    Provider: sqlite
    Sqlite:
      DataSource: mcp.db
```

Example SQL Server configuration:

```yaml
Mcp:
  Database:
    Provider: sqlserver
    SqlServer:
      ConnectionString: "Server=(localdb)\\MSSQLLocalDB;Database=mcp.db;Trusted_Connection=True;TrustServerCertificate=True"
```

Example PostgreSQL configuration:

```yaml
Mcp:
  Database:
    Provider: postgresql
    PostgreSql:
      ConnectionString: "Host=localhost;Port=5432;Database=mcp;Username=postgres;Password=postgres"
```

Supported environment-variable overrides:

- `MCP_DATABASE_PROVIDER`
- `MCP_DATABASE_MIGRATIONS_ASSEMBLY`
- `MCP_SQLITE_DATA_SOURCE`
- `MCP_POSTGRES_CONNECTION_STRING`
- `MCP_SQLSERVER_CONNECTION_STRING`

Provider integration-test notes:

- SQLite clean-database tests create isolated temp database files automatically.
- SQL Server provider and migration tests use per-run LocalDB instances created and deleted by the test harness.
- PostgreSQL provider tests are opt-in and require `MCP_TEST_POSTGRES_CONNECTION_STRING` plus `MCP_TEST_POSTGRES_ADMIN_CONNECTION_STRING`.
- SQL Server LocalDB is not sufficient for TDE validation.

### Native at-rest encryption configuration

Database encryption is configuration-driven and uses only provider-native or provider-extension
facilities:

- SQLite: SQLite SEE
- PostgreSQL: `pg_tde` on Percona Server for PostgreSQL
- SQL Server: native TDE

Canonical appsettings surface:

```yaml
Mcp:
  Database:
    Provider: sqlserver
    SqlServer:
      ConnectionString: "Server=sql01;Database=mcp;Integrated Security=True;TrustServerCertificate=True"
    Encryption:
      Enabled: true
      Sqlite:
        Key: ""
        SeeToolPath: ""
      PostgreSql:
        KeyProvider: ""
        PrincipalKey: ""
      SqlServer:
        CertificateName: "QBrainAiTdeCert"
        DatabaseEncryptionKeyName: "QBrainAiTdeKey"
```

Supported environment-variable overrides:

- `MCP_DATABASE_ENCRYPTION_ENABLED`
- `MCP_SQLITE_ENCRYPTION_KEY`
- `MCP_SQLITE_SEE_TOOL_PATH`
- `MCP_POSTGRES_TDE_KEY_PROVIDER`
- `MCP_POSTGRES_TDE_PRINCIPAL_KEY`
- `MCP_SQLSERVER_TDE_CERTIFICATE`
- `MCP_SQLSERVER_TDE_DATABASE_ENCRYPTION_KEY`

Startup behavior:

- The server now resolves desired provider and encryption state from appsettings and environment variables.
- Provider-owned migrations are applied through the provider migration assemblies.
- After migration, startup validates the live encryption state against configuration.
- If configured encryption and live database state do not match, startup fails with an actionable error instead of silently enabling, disabling, or bypassing encryption.

### Encryption transition procedures

Use these procedures when `Mcp:Database:Encryption:Enabled` changes, or when the provider's
native protection state must be rotated or removed. The server intentionally does not perform
these transitions automatically during normal startup.

Built-in maintenance command:

```powershell
pwsh.exe -NoLogo -NoProfile -NonInteractive -File ./scripts/Invoke-McpDatabaseEncryptionTransition.ps1 -Operation Verify
pwsh.exe -NoLogo -NoProfile -NonInteractive -File ./scripts/Invoke-McpDatabaseEncryptionTransition.ps1 -Operation Enable
pwsh.exe -NoLogo -NoProfile -NonInteractive -File ./scripts/Invoke-McpDatabaseEncryptionTransition.ps1 -Operation Disable
```

Execution notes:

- The PowerShell wrapper calls the built-in `--database-encryption-transition` command in `QBrainAi.Support.Mcp`.
- The default mode is dry-run planning only. Add `-Execute` to mutate the database.
- PostgreSQL and SQL Server execute mode require `-BackupPath` so rollback material exists before encryption state changes.
- SQL Server `-BackupPath` is evaluated by SQL Server on the database host, not by the local client process.
- SQLite disable operations often require `-CurrentKey` because the new disabled configuration no longer carries the old key.
- Use `-Instance` or `MCP_INSTANCE` when the target database settings live under an MCP instance override.
- Invalid maintenance-command usage returns a non-zero process exit code.
- Console output and optional JSON reports redact SQLite key material instead of echoing passphrases.

Example executions:

```powershell
pwsh.exe -NoLogo -NoProfile -NonInteractive -File ./scripts/Invoke-McpDatabaseEncryptionTransition.ps1 `
  -Operation Enable `
  -BackupPath E:\backups\mcp-before-tde.bak `
  -Execute

pwsh.exe -NoLogo -NoProfile -NonInteractive -File ./scripts/Invoke-McpDatabaseEncryptionTransition.ps1 `
  -Operation Disable `
  -CurrentKey "old-sqlite-passphrase" `
  -Execute
```

#### SQLite SEE

1. Stop the MCP server.
2. Run the dry-run transition command first and confirm the backup path, SEE CLI path, and target operation are correct.
3. Execute the transition command. The tool creates a backup copy, creates a working copy, applies SEE `.text-rekey`, forces nonce reservation with `.filectrl reserve_bytes 12` plus `VACUUM` on enable, verifies `PRAGMA integrity_check`, inspects `.dbinfo`, and swaps the verified copy into place only after validation passes.
4. Retain the original backup until post-cutover validation succeeds.
5. Update `Mcp:Database:Encryption:Enabled` and any SQLite encryption key settings, then restart the server.

Current runtime note:

- The server validates the configured SQLite encrypted mode, but an encrypted SQLite deployment still requires a SEE-enabled native SQLite runtime in the host environment. If that runtime is not provisioned, startup fails explicitly.

#### PostgreSQL `pg_tde`

1. Stop the MCP server or otherwise quiesce application writes.
2. Run the dry-run transition command first and confirm the backup path, `pg_dump` path, and target operation are correct.
3. Ensure the target runtime is Percona Server for PostgreSQL with `pg_tde` installed and that the configured key provider and principal key are available.
4. Execute the transition command. The tool runs `pg_dump -Fc`, rewrites each application table to `tde_heap` on enable or back to `heap` on disable, runs `SELECT count(*)` after each rewrite, and then verifies relation state with `pg_tde_is_encrypted(...)`.
5. Retain the backup archive until post-cutover validation succeeds.
6. Update `Mcp:Database:Encryption:Enabled`, `KeyProvider`, and `PrincipalKey` configuration as needed, then restart the server.

#### SQL Server TDE

1. Stop the MCP server or otherwise quiesce writes.
2. Run the dry-run transition command first and confirm the SQL Server backup path and certificate name are correct.
3. Take or retain a backup of the TDE certificate/private key material. The transition command does not remove or export certificates for you.
4. Execute the transition command. The tool runs a copy-only `BACKUP DATABASE`, verifies the configured certificate exists, creates the database encryption key when needed, runs `ALTER DATABASE ... SET ENCRYPTION ON` or `OFF`, and polls `sys.dm_database_encryption_keys` until the target state is reached.
5. Keep certificates and keys long enough to preserve restore and log-backup compatibility.
6. Update `Mcp:Database:Encryption:Enabled`, `CertificateName`, and `DatabaseEncryptionKeyName`, then restart the server.

SQL Server LocalDB note:

- LocalDB is supported for SQL Server provider and migration integration tests only.
- LocalDB cannot validate TDE. Use a separate Developer or Standard SQL Server target for SQL Server encryption validation and transition work.

### PowerShell helper modules (McpSession.psm1 + McpTodo.psm1)

```powershell
$marker = Get-Content .\AGENTS-README-FIRST.yaml -Raw
$apiKey = ([regex]::Match($marker, 'apiKey:\s*(\S+)')).Groups[1].Value
$headers = @{ "X-Api-Key" = $apiKey }

Invoke-RestMethod -Uri "http://localhost:7147/qbrainai/tools/search?keyword=mcp-session-module" -Headers $headers
Invoke-RestMethod -Uri "http://localhost:7147/qbrainai/tools/search?keyword=mcp-todo-module" -Headers $headers

Import-Module .\tools\powershell\McpSession.psm1
Import-Module .\tools\powershell\McpTodo.psm1

Initialize-McpSession -Agent "Codex" -Model "gpt-5.3-codex"
Initialize-McpTodo
```

Bootstrap trust behavior:

- Marker-based initialization now verifies the marker signature before any MCP endpoint is trusted.
- The signature is self-verifiable: the helper modules recompute the marker HMAC-SHA256 by using the workspace API key in `AGENTS-README-FIRST.yaml` as the verifier.
- After signature verification succeeds, the helper modules call `/health` with a random nonce and require the response to echo that exact nonce.
- If signature verification, the `/health` request, or nonce verification fails, the modules emit `MCP_UNTRUSTED`, clear their MCP connection state, and stop before probing any additional MCP endpoints.

Sample session logging flow:

```powershell
$session = New-McpSessionLog -SourceType "Codex" -Title "MCP docs update" -Model "gpt-5.3-codex"
$turn = Add-McpSessionTurn -Session $session -QueryTitle "Update docs" -QueryText "Create user docs" -Status in_progress
Add-McpAction -Turn $turn -Description "Updated docs\\USER-GUIDE.md" -Type edit -FilePath "docs/USER-GUIDE.md"
Set-McpSessionTurn -Session $session -Turn $turn -Response "Docs complete" -Status completed
Update-McpSessionLog -Session $session
```

Public function contract reference for `McpSession.psm1`:

- `Initialize-McpSession` configures module-scoped connection state, verifies the marker signature when a marker file is used, performs the `/health` nonce handshake, and returns only a `System.String` session slug. It does not create a session-log record and it does not return a session object.
- `New-McpSessionLogSlug` returns only a formatted session ID string. It does not write local files and it does not call the server.
- `New-McpSessionLog` creates the actual session object, posts it immediately to `/qbrainai/sessionlog`, persists it locally, and returns that session object.
- `Update-McpSessionLog` pushes the full current session payload to the server. If `-Session` is omitted, it resolves the current persisted session from local state. It does not return a value.
- `Get-McpSessionLog` performs a read-only query for recent session-log records and returns the deserialized API response, including paging metadata and the `items` collection.
- `Add-McpSessionTurn` appends one new turn object to a session and returns that new turn object. If `-NoPush` is not supplied, it also persists the updated session immediately.
- `Set-McpSessionTurn` updates scalar fields on an existing turn and appends new values to list-valued fields such as `tags`, `contextList`, `designDecisions`, `requirementsDiscovered`, `filesModified`, and `blockers`. It does not replace those collections wholesale, and it does not return a value.
- `Add-McpAction` appends one structured action object to `Turn.actions`, assigns the next sequential `order`, and returns the new action object.
- `Add-McpTurnDetail` appends one non-empty string to a supported list-valued turn field and ignores null or whitespace-only values. It does not return a value.
- `Send-McpDialog` posts one dialog item to the turn dialog endpoint. It does not update the local turn object and it does not return a value.

Sample TODO progress flow:

```powershell
$todo = Get-McpTodo -Id "MCP-USERDOCS-001"
$tasks = @(
  @{ task = "Write Installation & Prerequisites guide"; done = $true },
  @{ task = "Write Configuration reference (appsettings + marker file)"; done = $true }
)
Update-McpTodo -Id $todo.id -ImplementationTasks $tasks
```

## 3) REST API reference (all controllers)

Base URL: `http://<host>:7147`

Authentication:

- include `X-Api-Key` for `/qbrainai/*`
- include `X-Workspace-Path` for explicit workspace targeting
- OpenAPI: `GET /swagger/v1/swagger.json`

### AuthConfig controller (`/auth/*`)

- `GET /auth/config`
- `POST /auth/device`
- `POST /auth/token`
- `GET /auth/ui/{path}`
- `POST /auth/ui/{path}`

### AgentPool controller (`/qbrainai/agent-pool/*`)

- `GET /qbrainai/agent-pool/agents`
- `POST /qbrainai/agent-pool/agents/{agentName}/start|stop|connect|recycle`
- `POST /qbrainai/agent-pool/connect`
- `GET /qbrainai/agent-pool/queue`
- `POST /qbrainai/agent-pool/queue/one-shot`
- `POST /qbrainai/agent-pool/queue/resolve`
- `POST /qbrainai/agent-pool/queue/{jobId}/cancel|move-up|move-down`
- `DELETE /qbrainai/agent-pool/queue/{jobId}`
- `GET /qbrainai/agent-pool/notifications`
- `GET /qbrainai/agent-pool/jobs/{jobId}/stream`

### Agent controller (`/qbrainai/agents*`)

- `GET /qbrainai/agents`
- `GET|POST|DELETE /qbrainai/agents/{agentId}`
- `POST /qbrainai/agents/{agentId}/ban|unban|launch|stop`
- `GET|POST /qbrainai/agents/{agentId}/events`
- `GET /qbrainai/agents/{agentId}/process-status`
- `GET /qbrainai/agents/running`
- `GET|POST /qbrainai/agents/definitions`
- `GET|DELETE /qbrainai/agents/definitions/{agentType}`
- `POST /qbrainai/agents/definitions/seed`
- `GET /qbrainai/agents/validate`

### Configuration controller (`/qbrainai/configuration`)

- `GET /qbrainai/configuration`
- `PATCH /qbrainai/configuration`

### Context controller (`/qbrainai/context/*`)

- `POST /qbrainai/context/search`
- `POST /qbrainai/context/pack`
- `GET /qbrainai/context/sources`
- `POST /qbrainai/context/rebuild-index`
- `POST /qbrainai/context/ingest-website`
- `POST /qbrainai/context/ingest-website/stream`

Search request example:

```json
{
  "query": "workspace routing",
  "limit": 10,
  "sourceType": "repo"
}
```

Response example:

```json
{
  "chunks": [
    {
      "sourceKey": "docs/context/api-capabilities.md",
      "score": 0.91,
      "text": "Workspace resolution priority..."
    }
  ]
}
```

### Desktop controller (`/qbrainai/desktop/*`)

- `POST /qbrainai/desktop/launch` — requires normal workspace authentication plus the
  privileged `X-Desktop-Launch-Token` header, and the target executable must match
  `Mcp:DesktopLaunch:AllowedExecutables` while `Mcp:DesktopLaunch:Enabled` is `true`.

### Diagnostic controller (`/qbrainai/diagnostic/*`)

- `GET /qbrainai/diagnostic/execution-path`
- `GET /qbrainai/diagnostic/appsettings-path`

### EventStream controller (`/qbrainai/events`)

- `GET /qbrainai/events`

### GitHub controller (`/qbrainai/gh/*`)

- `GET|POST /qbrainai/gh/issues`
- `GET|PUT /qbrainai/gh/issues/{number}`
- `POST /qbrainai/gh/issues/{number}/close|reopen|sync`
- `POST /qbrainai/gh/issues/{id}/comments`
- `POST /qbrainai/gh/issues/sync/from-github`
- `POST /qbrainai/gh/issues/sync/to-github`
- `GET /qbrainai/gh/labels`
- `GET /qbrainai/gh/pulls`
- `POST /qbrainai/gh/pulls/{id}/comments`
- `GET /qbrainai/gh/auth/status`
- `PUT|DELETE /qbrainai/gh/auth/token`
- `GET /qbrainai/gh/oauth/config`
- `GET /qbrainai/gh/oauth/authorize-url`
- `GET /qbrainai/gh/actions/runs`
- `GET /qbrainai/gh/actions/runs/{runId}`
- `POST /qbrainai/gh/actions/runs/{runId}/rerun|cancel`

### GraphRag controller (`/qbrainai/graphrag/*`)

- `GET /qbrainai/graphrag/status`
- `POST /qbrainai/graphrag/index`
- `POST /qbrainai/graphrag/query`

### Memory controller (`/qbrainai/memory*`)

Compat CRUD (workspace Effective visibility; `X-Api-Key` required; optional `X-Workspace-Path`):

- `GET /qbrainai/memory` — list (`scope` = `Effective` default, `Global`, or `Workspace`; optional `category`, `keyword`)
- `GET /qbrainai/memory/{id}`
- `POST /qbrainai/memory` — add (`text`, `category`, optional `id`, `scope`, `updatedBy`)
- `PUT /qbrainai/memory/{id}` — update provided fields only
- `DELETE /qbrainai/memory/{id}`

Additive CQRS verbs (MCP-MEMORY-002):

- `POST /qbrainai/memory/remember` — persist a multi-layer memory (`content` required; optional title/summary/type/tags/confidence/source/scope)
- `POST /qbrainai/memory/recall` — ranked recall by meaning or keyword (`query`; optional `minScore`, `topN`, `tags`, `type`, `scope`)
- `POST /qbrainai/memory/explore` — neighborhood from `seedId` or query seed (Hebbian off by default)
- `POST /qbrainai/memory/consolidate` — dry-run merge plan by default; set `dryRun: false` to apply
- `POST /qbrainai/memory/promote` — promote a `sessionlog` or `context` source into memory (operator-explicit)
- `GET /qbrainai/memory/{id}/versions`
- `POST /qbrainai/memory/{id}/revert` — restore snapshot `versionNumber` (appends history)

`Idempotency-Key` is not supported. A duplicate remember creates a second row. Foreign or soft-deleted ids fail closed. See `docs/context/memory.md`.

### PromptTemplate controller (`/qbrainai/templates*`)

- `GET|POST /qbrainai/templates`
- `GET|PUT|DELETE /qbrainai/templates/{id}`
- `POST /qbrainai/templates/{id}/resolve`
- `POST /qbrainai/templates/{id}/test`
- `POST /qbrainai/templates/test`

### Repo controller (`/qbrainai/repo/*`)

- `GET /qbrainai/repo/file`
- `POST /qbrainai/repo/file`
- `GET /qbrainai/repo/list`

### Requirements controller (`/qbrainai/requirements/*`)

- `GET /qbrainai/requirements/generate`
- `GET|POST /qbrainai/requirements/fr`
- `GET|PUT|DELETE /qbrainai/requirements/fr/{id}`
- `GET|POST /qbrainai/requirements/tr`
- `GET|PUT|DELETE /qbrainai/requirements/tr/{id}`
- `GET|POST /qbrainai/requirements/test`
- `GET|PUT|DELETE /qbrainai/requirements/test/{id}`
- `GET /qbrainai/requirements/mapping`
- `GET|PUT|DELETE /qbrainai/requirements/mapping/{frId}`
- `POST /qbrainai/requirements/ingest`

### SessionLog controller (`/qbrainai/sessionlog*`)

- `GET /qbrainai/sessionlog` (optional `planFile` and `todoId` filters)
- `POST /qbrainai/sessionlog`
- `POST /qbrainai/sessionlog/{agent}/{sessionId}/{requestId}/begin` (requires `planFile` and `todoId`; use `None` when none)
- `POST /qbrainai/sessionlog/{agent}/{sessionId}/{requestId}/dialog` (incremental dialog; does not require a full-session upsert)

Query and GET responses are sanitized outbound (`Mcp:SessionLogSanitization`). Stored rows stay raw.

### Todo controller (`/qbrainai/todo*`)

- `GET|POST /qbrainai/todo`
- `GET|PUT|DELETE /qbrainai/todo/{id}`
- `POST /qbrainai/todo/{id}/move`
- `POST /qbrainai/todo/{id}/requirements`
- `GET /qbrainai/todo/{id}/prompt/implement|plan|status`
- `POST /qbrainai/todo/{id}/prompt/implement/queue`
- `POST /qbrainai/todo/{id}/prompt/plan/queue`
- `POST /qbrainai/todo/{id}/prompt/status/queue`

Update request example:

```json
{
  "implementationTasks": [
    { "task": "Write Installation & Prerequisites guide", "done": true },
    { "task": "Write Configuration reference (appsettings + marker file)", "done": true }
  ]
}
```

### ToolRegistry controller (`/qbrainai/tools*`)

- `GET|POST /qbrainai/tools`
- `GET|PUT|DELETE /qbrainai/tools/{id}`
- `GET /qbrainai/tools/search`
- `GET|POST /qbrainai/tools/buckets`
- `DELETE /qbrainai/tools/buckets/{name}`
- `GET /qbrainai/tools/buckets/{name}/browse`
- `POST /qbrainai/tools/buckets/{name}/install`
- `POST /qbrainai/tools/buckets/{name}/sync`

### Tunnel controller (`/qbrainai/tunnel/*`)

- `GET /qbrainai/tunnel/list`
- `GET /qbrainai/tunnel/{name}/status`
- `POST /qbrainai/tunnel/{name}/start|stop|restart|enable|disable`

### Voice controller (`/qbrainai/voice/*`)

- `GET|POST /qbrainai/voice/session`
- `GET|DELETE /qbrainai/voice/session/{sessionId}`
- `POST /qbrainai/voice/session/{sessionId}/turn`
- `POST /qbrainai/voice/session/{sessionId}/turn/stream`
- `POST /qbrainai/voice/session/{sessionId}/interrupt`
- `POST /qbrainai/voice/session/{sessionId}/escape`
- `GET /qbrainai/voice/session/{sessionId}/transcript`

### Workspace controller (`/qbrainai/workspace*`)

- `GET|POST /qbrainai/workspace`
- `GET|PUT|DELETE /qbrainai/workspace/{key}`
- `POST /qbrainai/workspace/{key}/init|start|stop`
- `GET /qbrainai/workspace/{key}/status`
- `GET|PUT /qbrainai/workspace/prompt`
- `POST /qbrainai/workspace/policy`

### Runtime utility endpoints (non-controller)

- `GET /health`
- `GET /swagger`
- `GET /swagger/v1/swagger.json`
- `POST /mcp-transport`

### Complete endpoint inventory (OpenAPI snapshot)

```text
GET /auth/config
POST /auth/device
POST /auth/token
GET /auth/ui/{path}
POST /auth/ui/{path}
GET /qbrainai/agent-pool/agents
POST /qbrainai/agent-pool/agents/{agentName}/connect
POST /qbrainai/agent-pool/agents/{agentName}/recycle
POST /qbrainai/agent-pool/agents/{agentName}/start
POST /qbrainai/agent-pool/agents/{agentName}/stop
POST /qbrainai/agent-pool/connect
GET /qbrainai/agent-pool/jobs/{jobId}/stream
GET /qbrainai/agent-pool/notifications
GET /qbrainai/agent-pool/queue
DELETE /qbrainai/agent-pool/queue/{jobId}
POST /qbrainai/agent-pool/queue/{jobId}/cancel
POST /qbrainai/agent-pool/queue/{jobId}/move-down
POST /qbrainai/agent-pool/queue/{jobId}/move-up
POST /qbrainai/agent-pool/queue/one-shot
POST /qbrainai/agent-pool/queue/resolve
GET /qbrainai/agents
DELETE /qbrainai/agents/{agentId}
GET /qbrainai/agents/{agentId}
POST /qbrainai/agents/{agentId}
POST /qbrainai/agents/{agentId}/ban
GET /qbrainai/agents/{agentId}/events
POST /qbrainai/agents/{agentId}/events
POST /qbrainai/agents/{agentId}/launch
GET /qbrainai/agents/{agentId}/process-status
POST /qbrainai/agents/{agentId}/stop
POST /qbrainai/agents/{agentId}/unban
GET /qbrainai/agents/definitions
POST /qbrainai/agents/definitions
DELETE /qbrainai/agents/definitions/{agentType}
GET /qbrainai/agents/definitions/{agentType}
POST /qbrainai/agents/definitions/seed
GET /qbrainai/agents/running
GET /qbrainai/agents/validate
GET /qbrainai/configuration
PATCH /qbrainai/configuration
POST /qbrainai/context/ingest-website
POST /qbrainai/context/ingest-website/stream
POST /qbrainai/context/pack
POST /qbrainai/context/rebuild-index
POST /qbrainai/context/search
GET /qbrainai/context/sources
POST /qbrainai/desktop/launch  # also requires X-Desktop-Launch-Token when enabled
GET /qbrainai/events
GET /qbrainai/gh/actions/runs
GET /qbrainai/gh/actions/runs/{runId}
POST /qbrainai/gh/actions/runs/{runId}/cancel
POST /qbrainai/gh/actions/runs/{runId}/rerun
GET /qbrainai/gh/auth/status
DELETE /qbrainai/gh/auth/token
PUT /qbrainai/gh/auth/token
GET /qbrainai/gh/issues
POST /qbrainai/gh/issues
POST /qbrainai/gh/issues/{id}/comments
GET /qbrainai/gh/issues/{number}
PUT /qbrainai/gh/issues/{number}
POST /qbrainai/gh/issues/{number}/close
POST /qbrainai/gh/issues/{number}/reopen
POST /qbrainai/gh/issues/{number}/sync
POST /qbrainai/gh/issues/sync/from-github
POST /qbrainai/gh/issues/sync/to-github
GET /qbrainai/gh/labels
GET /qbrainai/gh/oauth/authorize-url
GET /qbrainai/gh/oauth/config
GET /qbrainai/gh/pulls
POST /qbrainai/gh/pulls/{id}/comments
POST /qbrainai/graphrag/index
POST /qbrainai/graphrag/query
GET /qbrainai/graphrag/status
GET /qbrainai/repo/file
POST /qbrainai/repo/file
GET /qbrainai/repo/list
GET /qbrainai/requirements/fr
POST /qbrainai/requirements/fr
DELETE /qbrainai/requirements/fr/{id}
GET /qbrainai/requirements/fr/{id}
PUT /qbrainai/requirements/fr/{id}
GET /qbrainai/requirements/generate
POST /qbrainai/requirements/ingest
GET /qbrainai/requirements/mapping
DELETE /qbrainai/requirements/mapping/{frId}
GET /qbrainai/requirements/mapping/{frId}
PUT /qbrainai/requirements/mapping/{frId}
GET /qbrainai/requirements/test
POST /qbrainai/requirements/test
DELETE /qbrainai/requirements/test/{id}
GET /qbrainai/requirements/test/{id}
PUT /qbrainai/requirements/test/{id}
GET /qbrainai/requirements/tr
POST /qbrainai/requirements/tr
DELETE /qbrainai/requirements/tr/{id}
GET /qbrainai/requirements/tr/{id}
PUT /qbrainai/requirements/tr/{id}
GET /qbrainai/sessionlog
POST /qbrainai/sessionlog
POST /qbrainai/sessionlog/{agent}/{sessionId}/{requestId}/dialog
GET /qbrainai/templates
POST /qbrainai/templates
DELETE /qbrainai/templates/{id}
GET /qbrainai/templates/{id}
PUT /qbrainai/templates/{id}
POST /qbrainai/templates/{id}/resolve
POST /qbrainai/templates/{id}/test
POST /qbrainai/templates/test
GET /qbrainai/todo
POST /qbrainai/todo
DELETE /qbrainai/todo/{id}
GET /qbrainai/todo/{id}
PUT /qbrainai/todo/{id}
POST /qbrainai/todo/{id}/move
GET /qbrainai/todo/{id}/prompt/implement
POST /qbrainai/todo/{id}/prompt/implement/queue
GET /qbrainai/todo/{id}/prompt/plan
POST /qbrainai/todo/{id}/prompt/plan/queue
GET /qbrainai/todo/{id}/prompt/status
POST /qbrainai/todo/{id}/prompt/status/queue
POST /qbrainai/todo/{id}/requirements
GET /qbrainai/tools
POST /qbrainai/tools
DELETE /qbrainai/tools/{id}
GET /qbrainai/tools/{id}
PUT /qbrainai/tools/{id}
GET /qbrainai/tools/buckets
POST /qbrainai/tools/buckets
DELETE /qbrainai/tools/buckets/{name}
GET /qbrainai/tools/buckets/{name}/browse
POST /qbrainai/tools/buckets/{name}/install
POST /qbrainai/tools/buckets/{name}/sync
GET /qbrainai/tools/search
POST /qbrainai/tunnel/{name}/disable
POST /qbrainai/tunnel/{name}/enable
POST /qbrainai/tunnel/{name}/restart
POST /qbrainai/tunnel/{name}/start
GET /qbrainai/tunnel/{name}/status
POST /qbrainai/tunnel/{name}/stop
GET /qbrainai/tunnel/list
GET /qbrainai/voice/session
POST /qbrainai/voice/session
DELETE /qbrainai/voice/session/{sessionId}
GET /qbrainai/voice/session/{sessionId}
POST /qbrainai/voice/session/{sessionId}/escape
POST /qbrainai/voice/session/{sessionId}/interrupt
GET /qbrainai/voice/session/{sessionId}/transcript
POST /qbrainai/voice/session/{sessionId}/turn
POST /qbrainai/voice/session/{sessionId}/turn/stream
GET /qbrainai/workspace
POST /qbrainai/workspace
DELETE /qbrainai/workspace/{key}
GET /qbrainai/workspace/{key}
PUT /qbrainai/workspace/{key}
POST /qbrainai/workspace/{key}/init
POST /qbrainai/workspace/{key}/start
GET /qbrainai/workspace/{key}/status
POST /qbrainai/workspace/{key}/stop
POST /qbrainai/workspace/policy
GET /qbrainai/workspace/prompt
PUT /qbrainai/workspace/prompt

```

## 4) MCP tool catalog (STDIO tools)

Source: `src/QBrainAi.Support.Mcp/McpStdio/McpServerMcpTools.cs`

Current surface area: STDIO tools in `docs/stdio-tool-contract.json` (includes the memory surface below).

### Workspace policy

- `workspace_policy_apply`

### Context and GraphRAG

- `context_search`, `context_pack`, `context_sources`, `context_ingest_website`
- `graphrag_status`, `graphrag_index`, `graphrag_query`

### Repo and sync

- `repo_read`, `repo_list`, `repo_write`, `sync_run`, `sync_status`

### TODO workflow

- `todo_list`, `todo_get`, `todo_create`, `todo_update`, `todo_delete`, `todo_move`
- `todo_plan`, `todo_implement`, `todo_status`
- `handoff_ingest`, `handoff_get`, `handoff_approve` (see `docs/Handoff-Ingestion.md`)

### Requirements

- `requirements_list`, `requirements_generate`, `requirements_create`, `requirements_update`, `requirements_delete`

### Memory

- Compat: `memory_list`, `memory_get`, `memory_add`, `memory_update`, `memory_remove`
- Competitive: `memory_remember`, `memory_recall`, `memory_explore`, `memory_consolidate`, `memory_promote`, `memory_revert`
- Prefer the required plugin or REPL `workflow.memory.*` over raw REST. Injection contract: `docs/context/memory.md`.

### Session logs

- `sessionlog_open`, `sessionlog_begin_turn`, `sessionlog_submit`, `sessionlog_query`, `sessionlog_dialog`, `sessionlog_complete_turn`, `sessionlog_fail_turn`
- `sessionlog_begin_turn` requires `planFile` and `todoId` (`None` when none)

### GitHub

- `github_list_issues`, `github_list_pulls`, `github_create_issue`, `github_comment_issue`, `github_comment_pull`

### Prompt templates and desktop

- `prompt_template_list`, `prompt_template_get`, `prompt_template_create`, `prompt_template_update`, `prompt_template_delete`, `prompt_template_test`
- `desktop_launch`

## 5) GraphRAG setup and usage

### Enable GraphRAG

Set `Mcp:GraphRag:Enabled` to `true` and configure:

- `RootPath`
- `DefaultQueryMode` (`local`, `global`, `drift`)
- `DefaultMaxChunks`
- `IndexTimeoutSeconds`, `QueryTimeoutSeconds`
- `MaxConcurrentIndexJobsPerWorkspace`

Example:

```yaml
Mcp:
  GraphRag:
    Enabled: true
    RootPath: mcp-data/graphrag
    DefaultQueryMode: local
    DefaultMaxChunks: 20
    IndexTimeoutSeconds: 900
    QueryTimeoutSeconds: 120
```

### Index workflow

1. Start server.
2. `POST /qbrainai/graphrag/index` (or MCP tool `graphrag_index`).
3. Monitor with `GET /qbrainai/graphrag/status`.
4. Query with `POST /qbrainai/graphrag/query`.

### Rollout checklist

- [ ] Confirm embedding/vector dimensions
- [ ] Ensure write permissions on `mcp-data/graphrag`
- [ ] Run first index in non-production
- [ ] Validate latency and answer quality
- [ ] Track coverage with `context_sources`
- [ ] Define rebuild cadence (`sync_run` + `graphrag_index`)
- [ ] Add alerting for failed index/query jobs

## 6) Agent Pool and workspace multi-tenancy

### Agent Pool setup

- inspect workers via `/qbrainai/agent-pool/agents`
- queue ad-hoc jobs via `/qbrainai/agent-pool/queue/one-shot`
- resolve queued orchestrations via `/qbrainai/agent-pool/queue/resolve`
- stream progress via `/qbrainai/agent-pool/jobs/{jobId}/stream`

Queue one-shot example:

```json
{
  "prompt": "Summarize recent TODO changes",
  "model": "gpt-5.3-codex"
}
```

### Multi-tenant workspace model

- one server port hosts all configured workspaces
- resolution order:
  1. `X-Workspace-Path`
  2. API-key reverse lookup
  3. primary workspace fallback
- workspaces are configured under `Mcp:Workspaces`
- each workspace uses scoped marker metadata and keys

## 7) Troubleshooting and FAQ

### 401 Unauthorized on `/qbrainai/*`

- refresh `apiKey` from `AGENTS-README-FIRST.yaml`
- verify `X-Workspace-Path` targets a registered workspace
- use full workspace key for non-TODO write operations

### Workspace not found or wrong data set

- send explicit `X-Workspace-Path`
- check registrations via `GET /qbrainai/workspace`

### MCP transport handshake issues

- ensure client uses `/mcp-transport`
- include `Accept: application/json, text/event-stream`

### GraphRAG returns empty or weak answers

- confirm GraphRAG is enabled and indexed
- verify ingestion (`sync_run`) and source coverage
- validate embedding/vector compatibility

### Tool registry or GitHub actions fail

- run `gh auth status`
- validate `Mcp:ToolRegistry` settings
- verify token status at `GET /qbrainai/gh/auth/status`

### Windows service deployment concerns

- always use the Nuke target: `gsudo pwsh.exe -NoLogo -NoProfile -NonInteractive -File .\build.ps1 UpdateService`
- do not run `scripts\Update-McpService.ps1` directly for service redeployments
- do not manually overwrite `C:\ProgramData\QBrainAi`
- Linux updates also use `UpdateService`; see the existing-systemd requirements and recovery limits above

### Keyserver errors on TODO, session-log, or requirements writes

- First-party mutations (TODO, session-log including QBAgent, requirements, memory, repo, tools, GitHub, GraphRAG, federation apply/control) persist without the keyserver when `TurnTransactionKeyserverScope` is shipped
- Keep `Mcp:TurnTransactions:Enabled=true` on a live QuadBrain box; do not flip that flag off as the fix
- Keyserver signing remains only for QuadBrain `brain-slot.invoke` / `brain-slot.weight-update` (publisher prefix `brain-slot:` or operation prefix `brain-slot.` / `quadbrain.`)
- Workspace-stamp repair (`RepairWorkspaceStampsAsync`) stays fail-closed

## 7b) Use cases (FR/TR traceability modeling)

Use cases are workspace-scoped domain records with actors, flows, steps, FR links (default `Realizes`), approval/product hooks, and diagrams.

### REST

- Base: `GET/POST /qbrainai/usecases` (requires `X-Api-Key`, optional `X-Workspace-Path`)
- Aggregate: `GET/PUT/DELETE /qbrainai/usecases/{id}`
- Structure: `POST .../flows`, `POST .../flows/{flowId}/steps`, `POST .../actors`, `POST/DELETE .../links`
- Diagrams:
  - Sequence (from flows/steps): `GET .../diagram?kind=sequence&format=mermaid|plantuml`
  - UML use-case graph export: `GET .../diagram?kind=usecase&format=mermaid|plantuml`
  - Canvas graph: `GET/PUT .../diagram-graph` (JSON schema v1; see `docs/context/usecase-diagram-mermaid-schema-v1.md`)
- Coverage: `GET /qbrainai/usecases/coverage`
- Approval / product: `POST .../approval`, `POST .../product`, `GET .../by-product/{productKey}`

### First-party UI

- Served at `http://localhost:7147/usecases/` after deploy via Nuke `UpdateService`
- **Primary diagram UI:** UML use-case canvas (palette + free canvas + drag/move/rename + Save/Load graph)
- Secondary: structure forms (actors/flows/steps/FR links) and sequence diagram render
- UI uses REST only; provide API key and workspace path in the form fields

### MCP tools

Tools such as `usecase_list`, `usecase_create`, `usecase_diagram`, `usecase_coverage`, and graph-related tools are registered on Streamable HTTP / STDIO when the use-case surface is enabled. Prefer plugin/REPL `client.UseCases.*` when available.

### Deploy note

Canvas and graph persistence require a service build that includes the latest `wwwroot/usecases/*` and the `DiagramGraphJson` migration. Redeploy only with elevated:

```powershell
.\build.ps1 UpdateService --SkipVersionBump true
```

## 7c) Products (shared requirements across workspaces)

A Product groups workspaces on the same host so members can read each other's FR/TR/TEST/layers without copying rows. Keys look like `PROD-MCPSERVER` (uppercase `PROD-` prefix). TODOs, session logs, and sibling source files are not shared.

### REST

- `POST /qbrainai/products` body `{ "key": "PROD-MCPSERVER", "name": "QBrainAi" }` (caller becomes owner)
- `GET /qbrainai/products` and `GET /qbrainai/products/{key}`
- `PATCH /qbrainai/products/{key}` (owner) and `DELETE /qbrainai/products/{key}` (owner soft-delete)
- Members: `GET/PUT/DELETE /qbrainai/products/{key}/members/{workspaceId}`
- Effective requirements: `GET /qbrainai/requirements/effective?productScope=product|local` (default `product`)

All routes require `X-Api-Key`. Invalid keys are 400; duplicate keys 409; non-owner mutate 403; outsider get 404.

### MCP and REPL

- Tools: `product_create`, `product_list`, `product_get`, `product_update`, `product_delete`, `product_list_members`, `product_add_member`, `product_remove_member`
- Effective union: `requirements_effective` with `productScope=product` (default) or `local`
- Typed client: `client.Products`
- Context source `product-requirements` returns sibling FR/TR/TEST text tagged with `originWorkspaceId`, not sibling `.cs` files

## 7d) Agent memory (remember / recall / promote / consolidate)

MCP memories are the shared, workspace-scoped store for durable operator guidance. Agent-local memory files are caches only. Full contract: `docs/context/memory.md`.

### Verbs

- `memory_remember` / `POST /qbrainai/memory/remember` — persist a fact, decision, preference, procedure, or entity. `content` is the raw text that later injection uses.
- `memory_recall` / `POST /qbrainai/memory/recall` — ranked guidance by meaning or keyword. Results stay in the caller Effective set.
- `memory_promote` / `POST /qbrainai/memory/promote` — copy an operator-selected session-log or context source into memory (`sourceKind` + `sourceRef`).
- `memory_consolidate` / `POST /qbrainai/memory/consolidate` — sleep/merge near-duplicates. Default is dry-run; apply only when `dryRun` is false.
- `memory_explore` / `POST /qbrainai/memory/explore` — neighborhood walk from a seed id or the top recall hit. Hebbian co-retrieved edges stay off unless `Mcp:Memory:Hebbian:Enabled` or the request override is true.
- `memory_revert` / `POST /qbrainai/memory/{id}/revert` — restore snapshot N and append history.
- Compat CRUD remains: `memory_add`, `memory_list`, `memory_update`, `memory_remove`.

REPL: `workflow.memory.remember|recall|explore|consolidate|promote|revert` plus the same compat names. Typed client: `QBrainAiClient.Memory`.

### REQUIRED MEMORIES injection

All eight official plugins (claude-code, claude-cowork, cline, cline-v2, grok, copilot, codex, opencode) render Effective memories at host-supported request boundaries using raw `Content` (or legacy `Text`) only. Each plugin ships `skills/memory/SKILL.md` plus root `memory-descriptor.json`, with always-on injection on the host path (`hooks/scripts/memory-context.ps1` and/or `src/memory-context.ts`). Title, summary, confidence, and tags never appear in the block. Production renderer (`MemoryRequiredMemoriesRenderer`):

```
REQUIRED MEMORIES
- <raw content>
```

An empty Effective set still renders:

```
REQUIRED MEMORIES
- None
```

Do not summarize or rewrite injected text.

### Memory UI (active-workspace governance)

`/memory/` is the first-party static UI for search, open, edit, and version/revert of Effective memories in the active workspace.

REST used by the UI:

- List: `GET /qbrainai/memory?scope=Effective` (requires `X-Api-Key`, optional `X-Workspace-Path`)
- Get / update: `GET/PUT /qbrainai/memory/{id}`
- Remember: `POST /qbrainai/memory/remember`
- Recall: `POST /qbrainai/memory/recall`
- Versions / revert: `GET /qbrainai/memory/{id}/versions`, `POST /qbrainai/memory/{id}/revert`

The UI calls only those public REST routes. Foreign or unknown ids fail closed (403/404). Soft-deleted rows stay hidden because the default list omits them.

### First-party UI and ship path

- Served at `http://localhost:7147/memory/` after deploy via Nuke `UpdateService`
- Deep link `/memory/{id}` opens detail or fail-closed for unknown ids
- Static assets live in `wwwroot/memory` and are included in publish output and the Linux service package
- Auth is the same API-key cookie/header bridge as other `/mcpserver` pages (`X-Api-Key`)
- Redeploy only with elevated Nuke:

```powershell
.\build.ps1 UpdateService --SkipVersionBump true
```

Do not run UpdateService in this slice unless an operator asks.

## 7e) Memory plugin efficacy check

The standard with/without memory pack is `docs/benchmarks/memory-prompt-pack-v1.yaml` (smoke/regression).
The real efficiency + correctness bench is `docs/benchmarks/memory-prompt-pack-v2-multiturn.yaml` (multi-turn jobs; success-gated tokens_total).
See `docs/benchmarks/README.md` for the token-primary bench (pass/fail is correctness/safety only).
Run `./build.ps1 BenchMemory` for the default Grok lane. After H7a `agree:true` (`docs/benchmarks/h7a-value-gate.json`), `./build.ps1 BenchMemory -Plugin all` runs all eight recorded/stub adapters. S7b/H7b landed on develop (PR #50).

Eight-plugin token-primary v2 results: `docs/benchmarks/results/memory-bench-multiturn-20260919T091800Z.md`. Live Grok subscription-context v2 remains `docs/benchmarks/live/grok-subscription-cloud-agent-v2-multiturn.json` (summary `memory-bench-multiturn-20260919T090341Z.md`). Do not treat v1 `memory-bench-*.md` artifacts as the efficiency claim.

## 7f) QuadBrain-only keyserver (PLAN-TXNKEYSERVER-001)

Shipped on `develop` (`8f30caf` / `facbb3a6`) and live on the Linux box MCP after a publish/swap to `/opt/mcpserver`. The box TODO store has PLAN-TXNKEYSERVER-001 `Done=true`. This guide does not claim a Windows Legion `UpdateService` run.

`TurnTransactionKeyserverScope` requires keyserver signing only when the publisher party id starts with `brain-slot:` or the operation name starts with `brain-slot.` or `quadbrain.`. Every other first-party mutation adapter bypasses `ITurnTransactionCoordinator` and the keyserver even when `Mcp:TurnTransactions:Enabled=true` and `RequiredForMutations=true`.

Still coordinator-gated:

- `brain-slot.invoke`
- `brain-slot.weight-update`

Bypass (persist without keyserver):

- TODO, requirements (including ingest), session-log for every source type including QBAgent
- memory, repo, prompt templates, tool registry/buckets
- GraphRAG, GitHub CLI, GitHub token store, issue-todo-sync
- voice, agent pool, federation apply/control, context rebuild
- REPL `TransactionalTodoWorkflow`

Still fail-closed: uncompensated workspace-stamp repair.

Do not disable live `TurnTransactions.Enabled` to make general-agent writes succeed. Repo `appsettings` may keep `Enabled: false`; the live box keeps it `true` for QuadBrain.

Requirements (store restored on the box; markdown projections may lag until generateDocument): FR-MCP-173, TR-MCP-TXNKEY-001, TEST-MCP-221, FR-MCP-120 carve-out, TEST-MCP-161 retargeted to QuadBrain/brain-slot coordinator tests.

Cited unit-suite HV AGREEs remain `docs/receipts/hostile-validator-20260917T174749Z.md` and `docs/receipts/hostile-validator-20260917T184144Z.md`. Box deploy: `docs/receipts/implementer-txnkeyserver-box-deploy-20260919T154640Z.md`. Done-claim HV AGREE Accuracy 99 Completeness 98: `docs/receipts/hostile-validator-20260919T162808Z.md` (json twin + `docs/receipts/hv/20260919T162808Z-txnkeyserver-box-deploy-done-claim.*.jsonl`). Prior DISAGREE kept as history: `docs/receipts/hostile-validator-20260919T161130Z.md`. Integration, Validation, and Review suites were not run (operator policy).

## 8) Wire docs into README index and docs folder

This user guide is wired into:

- repository README (`README.md`)
- docs index (`docs/README.md`)
- docs navigation (`docs/toc.yml`)
- memory contract (`docs/context/memory.md`)
- memory benchmarks (`docs/benchmarks/README.md`)

## Reference links

- `MCP-SERVER.md`
- `AGENT-PLUGIN-AVAILABILITY.md`
- `REPL-USER-GUIDE.md`
- `REPL-AGENT-GUIDE.md`
- `context/federation.md`
- `context/memory.md`
- `benchmarks/README.md`
- `README.md`
- `FAQ.md`
- `context/`
- `Operations/`
